#!/usr/bin/env python3
"""Validate the Animus v2.1 Executable Baseline package."""
from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

import yaml
from jsonschema import Draft202012Validator
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "schemas"
FIXTURES = ROOT / "tests" / "fixtures"


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def build_registry():
    registry = Registry()
    schemas = {}
    for path in sorted(SCHEMAS.glob("*.schema.json")):
        data = load_json(path)
        Draft202012Validator.check_schema(data)
        schemas[path.name] = data
        registry = registry.with_resource(data["$id"], Resource.from_contents(data))
    return schemas, registry


def validate_fixtures(schemas, registry):
    errors = []
    positives = list((FIXTURES / "positive").glob("*.json"))
    negatives = list((FIXTURES / "negative").glob("*.json"))

    for path in positives:
        obj = load_json(path)
        schema_name = (
            f'{obj["artifact_type"]}.schema.json'
            if "artifact_type" in obj
            else f'{path.stem}.schema.json'
        )
        validator = Draft202012Validator(schemas[schema_name], registry=registry)
        found = sorted(validator.iter_errors(obj), key=lambda e: list(e.path))
        if found:
            errors.append(f"Positive fixture {path.name} failed: {found[0].message}")

    for path in negatives:
        wrapper = load_json(path)
        validator = Draft202012Validator(schemas[wrapper["schema"]], registry=registry)
        found = list(validator.iter_errors(wrapper["object"]))
        if not found:
            errors.append(f"Negative fixture {path.name} was incorrectly accepted")

    return errors, len(positives), len(negatives)


def validate_adrs():
    index = yaml.safe_load((ROOT / "adrs" / "index.yaml").read_text(encoding="utf-8"))
    errors = []
    ids = set()
    for item in index["decisions"]:
        if item["id"] in ids:
            errors.append(f"Duplicate ADR id: {item['id']}")
        ids.add(item["id"])
        if not (ROOT / "adrs" / item["file"]).exists():
            errors.append(f"Missing ADR file: {item['file']}")
    if len(ids) < 15:
        errors.append("Expected at least 15 accepted ADRs")
    return errors, len(ids)


def validate_coverage():
    path = ROOT / "tests" / "coverage_matrix.csv"
    with path.open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    errors = []
    ids = set()
    for row in rows:
        rid = row["requirement_id"]
        if rid in ids:
            errors.append(f"Duplicate requirement id: {rid}")
        ids.add(rid)
        for field in ("area", "requirement", "authority", "verification", "severity"):
            if not row.get(field):
                errors.append(f"{rid} missing {field}")
    if len(rows) < 50:
        errors.append("Coverage matrix must contain at least 50 requirements")
    return errors, len(rows)


def validate_manifests():
    errors = []
    manifest = yaml.safe_load((ROOT / "source_manifest.yaml").read_text(encoding="utf-8"))
    for source in manifest.get("sources", []):
        value = source.get("sha256")
        if not isinstance(value, str) or len(value) != 64:
            errors.append(f"Source {source.get('source_id')} lacks a valid SHA-256")
        if source.get("status") not in {"active", "superseded", "historical", "deprecated"}:
            errors.append(f"Source {source.get('source_id')} has unknown status")
    policy = yaml.safe_load((ROOT / "policies" / "policy_registry.yaml").read_text(encoding="utf-8"))
    if policy.get("default_effect") != "deny":
        errors.append("Policy default must be deny")
    return errors, len(manifest.get("sources", []))


def main():
    errors = []
    schemas, registry = build_registry()
    fixture_errors, positive_count, negative_count = validate_fixtures(schemas, registry)
    adr_errors, adr_count = validate_adrs()
    coverage_errors, requirement_count = validate_coverage()
    manifest_errors, source_count = validate_manifests()
    errors.extend(fixture_errors + adr_errors + coverage_errors + manifest_errors)

    print(f"Schemas compiled: {len(schemas)}")
    print(f"Positive fixtures passed: {positive_count}")
    print(f"Negative fixtures rejected: {negative_count}")
    print(f"ADRs indexed: {adr_count}")
    print(f"Requirements covered: {requirement_count}")
    print(f"Source records hashed: {source_count}")

    if errors:
        print("\nVALIDATION FAILED", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1

    print("\nVALIDATION PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
