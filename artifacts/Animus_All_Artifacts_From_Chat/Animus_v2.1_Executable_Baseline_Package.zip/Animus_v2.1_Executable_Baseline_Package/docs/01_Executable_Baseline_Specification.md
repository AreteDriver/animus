# Animus v2.1 Executable Baseline Specification

**Version:** 2.1.0  
**Status:** Canonical implementation contract  
**Effective date:** June 16, 2026

## 1. Scope

This specification defines the minimum architecture that may be implemented under the Animus name. It reconciles the Mind vision, Context Spine, Memory Architecture, Intelligence Swarm, Architecture Book, True System Design documents, and canonical v2 into one executable baseline.

The baseline is intentionally narrower than the full vision. It establishes a trustworthy durable core before adding broad autonomous behavior.

## 2. System definition

Animus is a governed, persistent personal intelligence system for one sovereign human owner. It combines:

- Durable, source-grounded context.
- Memory with candidate validation and temporal history.
- Retrieval and graph-assisted context assembly.
- Deliberative agents with explicit contracts and budgets.
- Secure tools exposed through a policy-enforced gateway.
- Intelligence workflows that distinguish signals, patterns, hypotheses, assessments, and forecasts.
- Complete tracing, evaluation, recovery, export, and deletion controls.

## 3. Architectural invariants

The following are release-blocking invariants:

1. Every canonical object validates against a versioned schema.
2. Every accepted state change has a ledger event and current projection committed atomically.
3. Every consequential output is traceable to inputs, retrieval, model calls, policy decisions, and tools.
4. Every high-impact action has a valid approval receipt.
5. No credential or encryption key enters model context.
6. Generated views cannot become canonical through write-back without a separate validated proposal.
7. Contradictions are linked and preserved; they are not silently overwritten.
8. Consequential facts use valid time and transaction time.
9. Model, prompt, provider, tool, and source lineage are recorded.
10. Capability promotion requires passing measurable gates.
11. Deletion propagates to active stores and derived indexes within defined targets.
12. One human owner remains the highest authorization principal.

## 4. Architecture model

### 4.1 Mind faculties

Faculties describe cognitive purpose:

- Perception
- Memory
- Understanding
- Reasoning
- Foresight
- Judgment
- Agency
- Self-governance
- Reflection

They are conceptual capabilities, not services or storage locations.

### 4.2 Technical planes

- Experience plane
- Orchestration plane
- Context plane
- Intelligence plane
- Action plane
- Governance plane
- Observability plane
- Infrastructure plane

Planes group responsibilities. Runtime modules may participate in several planes but must expose clear interfaces.

### 4.3 Runtime modules

The executable baseline contains:

- Identity and session service
- Policy decision and enforcement points
- Object registry
- Event ledger and transactional outbox
- Source ingestion and normalization service
- Retrieval and Context Envelope service
- Memory candidate service
- Agent runtime
- MCP gateway
- Evaluation and release-gate service
- Trace and audit service
- Export, deletion, and recovery services
- Rebuildable search, graph, and generated-view projections

### 4.4 Context coordinates

Canonical objects are classified through independent fields:

| Coordinate | Values | Meaning |
|---|---|---|
| subject_domain | self, world, project, operations | What area the object concerns |
| artifact_type | source through lesson | What kind of epistemic or operational object it is |
| cognitive_role | memory, knowledge, intelligence, none | How it functions cognitively |
| workflow_status | candidate, approved, rejected, not_applicable | Review status |
| epistemic_status | unverified, supported, disputed, refuted, not_applicable | Evidential standing |
| lifecycle_status | active, superseded, deprecated, archived, deleted | Operational lifecycle |
| storage_tier | hot, warm, cold | Physical retention tier |
| presentation | canonical, generated_view | Authority of representation |

No coordinate substitutes for another. Folder paths and dashboards are generated projections over these values.

## 5. Durable data model

### 5.1 Ownership

Animus has one `owner_id`. The owner may create isolated `workspace_id` scopes for personal, family, legal, health, career, research, or project data. Workspaces have separate policies and encryption keys but do not create separate sovereign tenants.

### 5.2 Object identity

Every canonical object has:

- Stable object identifier.
- Monotonic version.
- Schema identifier and schema version.
- Owner and workspace.
- Context coordinates.
- Valid-time interval.
- Transaction-time interval.
- Provenance links.
- Sensitivity classification.
- Integrity hash.
- Lifecycle metadata.

### 5.3 Event and projection transaction

For each accepted change, one relational transaction writes:

1. An immutable event record.
2. The new versioned object state.
3. The current-object projection.
4. An outbox entry for downstream indexing, graph updates, notifications, and evaluation.

The transaction commits only if all four writes succeed. Consumers use event and idempotency identifiers to prevent duplicate side effects. Search and graph systems are projections and may be rebuilt.

### 5.4 Bitemporal semantics

`valid_from` and `valid_to` represent when the content applies in the modeled world. `recorded_at` and `superseded_at` represent when Animus knew or stored it. Corrections create a new version; they do not erase prior knowledge history unless deletion policy requires content removal.

## 6. Retrieval and Context Envelope

The retrieval service accepts purpose, workspace, time, subject domains, sensitivity ceiling, token budget, and required artifact types. It returns a Context Envelope containing:

- Direct evidence.
- Accepted memories.
- Applicable knowledge.
- Current intelligence.
- Contradictions and dissent.
- Freshness and confidence.
- Omitted-result reasons.
- Provenance and retrieval trace.
- Budget consumption.

Retrieval tests must address relevance, temporal correctness, access control, contradiction coverage, stale evidence, and leakage.

## 7. Memory pipeline

1. Detect a memory-worthy event or receive an explicit proposal.
2. Create a `memory_candidate`.
3. Resolve duplicate and semantic-near-duplicate candidates.
4. Search for contradictory active memories.
5. Validate source, confidence, scope, time, and sensitivity.
6. Determine approval requirement.
7. Obtain approval when required.
8. Commit accepted memory and event atomically.
9. Update projections through the outbox.
10. Run post-write verification and evaluation.

The model may propose a memory; it cannot bypass validation or approval policy.

## 8. Agent runtime

Each agent execution requires:

- Agent contract and version.
- Objective and completion criteria.
- Allowed inputs and tools.
- Data classification ceiling.
- Time, token, cost, and recursion budgets.
- Cancellation token.
- Required output schema.
- Escalation policy.
- Trace parent.
- Model and prompt lineage.

A coordinator may delegate, but delegated permissions cannot exceed the parent scope. Agent disagreement must be preserved in the synthesis when material.

## 9. Intelligence and forecasting

The intelligence chain is:

`source -> observation -> signal -> pattern -> hypothesis -> assessment -> forecast -> decision -> action -> outcome -> lesson`

Skipping stages requires an explicit justification. Evidence independence is calculated from origin and derivation graphs, not agent count. Forecasts require a resolution rule, horizon, probability, assumptions, alternatives, and scoring record.

## 10. Tools and MCP gateway

Risk classes:

- R0: read-only public or non-sensitive data
- R1: read-only private data
- R2: reversible internal write
- R3: consequential or externally visible write
- R4: irreversible, privileged, financial, legal, medical, identity, or destructive action

R0 and selected R1 calls may operate under standing policy. R2 requires bounded authorization and idempotency. R3 and R4 require fresh scoped approval unless an owner-approved policy explicitly permits a narrow recurring action.

Every tool call produces an action receipt even when denied.

## 11. Security architecture

- Default deny.
- Least privilege.
- Short-lived credentials.
- Device-bound sessions.
- Workspace-scoped keys.
- Provider routing by classification.
- Secrets broker outside model context.
- Signed policies and schema versions.
- Sandboxed connectors.
- Rate, cost, and egress limits.
- Emergency kill switches independent of the agent runtime.

Detailed requirements are in `docs/03_Security_Identity_Keys_Deletion.md`.

## 12. Observability and evaluation

Every run receives a trace identifier. Trace spans cover retrieval, model calls, tools, policy decisions, writes, queue events, and generated views. Logs must be structured and redact restricted payloads by default.

Promotion environments:

- Development
- Evaluation
- Shadow
- Limited
- General

Promotion requires the gates in `tests/acceptance_criteria.yaml`. A failed critical gate blocks release automatically.

## 13. Reliability and recovery

The numerical targets in `operations/slo_registry.yaml` and `operations/recovery_registry.yaml` are normative. Restore tests are required quarterly. Search and graph projections must be rebuildable from canonical state. High-impact workflows require resumable checkpoints and explicit compensation steps.

## 14. Source authority and migration

Earlier documents remain historical sources. Their concepts are mapped through `migrations/v2_to_v2_1_mapping.yaml`. They may explain intent but may not override this baseline.

## 15. First implementation slice

The first admitted capability analyzes Animus's own architecture corpus. It exercises ingestion, claims, contradictions, retrieval, agents, synthesis, approval, memory, transactionality, tracing, export, deletion dry-run, restore, and replay without external action. See `docs/04_Vertical_Slice_Architecture_Corpus.md`.

## 16. Definition of done

The baseline is executable when:

- The package validator passes.
- All canonical schemas compile.
- The object transaction is implemented and fault-injection tested.
- The architecture-corpus slice passes every critical acceptance criterion.
- A backup is restored into a clean environment.
- One trace is reproduced from captured inputs.
- An unauthorized R3/R4 action is denied under adversarial testing.
- A deletion exercise satisfies the active-store and backup policy.
- The owner can export canonical data and verify integrity hashes.
