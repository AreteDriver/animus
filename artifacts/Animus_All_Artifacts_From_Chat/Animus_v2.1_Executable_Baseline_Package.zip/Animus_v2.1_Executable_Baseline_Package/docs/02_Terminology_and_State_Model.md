# Terminology and State Model

## 1. Why v2.1 changes the model

Earlier Animus documents grouped subject areas, cognitive functions, generated views, and storage states under one domain list. That made ownership ambiguous. v2.1 replaces that list with independent coordinates.

## 2. Context coordinates

### Subject domain

- `self` — the owner’s identity, biography, preferences, health, relationships, goals, and personal state.
- `world` — external people, entities, events, public facts, environments, and conditions.
- `project` — bounded efforts with objectives, plans, artifacts, decisions, and outcomes.
- `operations` — recurring workflows, service health, tasks, procedures, and system administration.

### Artifact type

- `source` — captured origin material.
- `observation` — a bounded description of what was seen, read, heard, or measured.
- `claim` — a proposition that can be supported, disputed, or refuted.
- `entity` — a durable identity record.
- `event` — something that occurred or is expected to occur at a time.
- `signal` — an observation judged potentially relevant.
- `pattern` — a repeated or structured relationship across signals.
- `hypothesis` — a testable explanatory proposition.
- `assessment` — a synthesized judgment over evidence and alternatives.
- `forecast` — a probabilistic statement with a resolution rule and horizon.
- `decision` — an authorized choice among alternatives.
- `action` — an intended or executed intervention.
- `outcome` — an observed result of action or events.
- `lesson` — a generalized, evidence-linked learning.

### Cognitive role

- `memory` — owner- or system-specific durable context useful across time.
- `knowledge` — generalized, reusable understanding not dependent on a current analytic cycle.
- `intelligence` — time-sensitive analysis intended to reduce uncertainty for a decision.
- `none` — operational or source material without an assigned cognitive role.

### Workflow status

- `candidate` — awaiting validation or approval.
- `approved` — admitted under governing policy.
- `rejected` — explicitly denied.
- `not_applicable` — the object does not pass through a review workflow.

### Epistemic status

- `unverified` — not adequately supported.
- `supported` — evidence currently supports the proposition.
- `disputed` — material contrary evidence or unresolved disagreement exists.
- `refuted` — evidence currently defeats the proposition.
- `not_applicable` — the object is not truth-apt, such as an action request.

### Lifecycle status

- `active` — current and available for ordinary use.
- `superseded` — replaced by a newer version or decision.
- `deprecated` — retained but should not be used for new work.
- `archived` — removed from active use and placed in cold retention.
- `deleted` — content removed under deletion policy; only a minimal tombstone may remain.

### Storage tier

- `hot` — frequently accessed canonical state.
- `warm` — less frequent but directly accessible state.
- `cold` — archive or backup retention with slower access.

### Presentation

- `canonical` — authoritative object governed by schema, provenance, and lifecycle.
- `generated_view` — rebuildable projection, dashboard, summary, report, folder, or index.

## 3. State composition

The state of an object is a tuple, not a single enum:

```text
(workflow_status, epistemic_status, lifecycle_status, storage_tier, presentation)
```

Examples:

- A claim may be `(approved, disputed, active, hot, canonical)`.
- A rejected memory candidate may be `(rejected, unverified, archived, cold, canonical)`.
- A dashboard may be `(not_applicable, not_applicable, active, hot, generated_view)`.
- A deleted restricted claim may be represented by a tombstone with `(approved, not_applicable, deleted, cold, canonical)` and no sensitive payload.

## 4. Allowed transitions

### Workflow

```text
candidate -> approved
candidate -> rejected
rejected -> candidate     only through a new proposal/version
approved -> candidate     only for a proposed replacement
```

### Epistemic

```text
unverified <-> supported
unverified <-> disputed
supported <-> disputed
supported -> refuted
disputed -> refuted
refuted -> supported      only with new material evidence and a new version
```

### Lifecycle

```text
active -> superseded
active -> deprecated
active -> archived
superseded -> archived
deprecated -> archived
archived -> active        only through an authorized restoration/new version
any retained state -> deleted
```

Transitions create events. Silent mutation is prohibited.

## 5. Ownership rules

- Every canonical object has exactly one `owner_id`.
- Every canonical object belongs to exactly one `workspace_id`.
- Cross-workspace references require explicit policy and are recorded in provenance.
- Generated views may aggregate across workspaces only when the owner authorizes that view and the least permissive source policy governs.
- A workspace is not a tenant and cannot acquire independent sovereignty.

## 6. Contradictions

Contradictions are first-class edges with:

- Source object identifiers.
- Contradiction type.
- Scope.
- Detection method.
- Confidence.
- Status.
- Resolution decision, if any.
- Effective time.

A contradiction does not automatically refute either object. Material disagreement remains visible until evidence or an authorized decision resolves its operational use.

## 7. Versioning

Object identity remains stable across versions. Every accepted update creates:

- A new monotonic object version.
- A ledger event.
- A new integrity hash.
- Updated transaction-time bounds.
- A link to the prior version.
- A reason code.

Corrections and supersessions do not erase history. Deletion follows the separate deletion protocol.
