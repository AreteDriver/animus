# Security, Identity, Keys, Providers, and Deletion

## 1. Security objective

Protect the sovereign owner from unauthorized disclosure, manipulation, action, persistence, and loss while preserving inspectability and recoverability.

## 2. Principal model

Principal types:

- `owner` — the sole sovereign human.
- `device` — an enrolled owner-controlled endpoint.
- `service` — a narrowly scoped runtime component.
- `agent` — an ephemeral delegated reasoning process.
- `connector` — an integration with an external system.

Each principal has a stable identifier, status, credential type, scopes, workspace restrictions, assurance level, and revocation record. Agents never receive standing credentials; they request constrained capabilities from policy-enforced services.

## 3. Authentication and sessions

- Owner authentication requires phishing-resistant MFA where supported.
- New devices require explicit enrollment.
- Device sessions are bound to device identity and expire.
- Sensitive actions require step-up authentication.
- Session and approval lifetimes are separate.
- Revocation propagates to gateways and secret brokers immediately.
- Break-glass recovery uses offline recovery material and generates a high-severity event.

## 4. Authorization

Authorization is evaluated from:

- Principal.
- Workspace.
- Action.
- Resource and classification.
- Purpose.
- Time.
- Device assurance.
- Approval receipt.
- Budget.
- Environmental conditions.

Model text is not an authorization source. Policy enforcement points fail closed.

## 5. Data classification

- `public` — safe for public disclosure.
- `internal` — ordinary owner data with limited harm from disclosure.
- `confidential` — sensitive personal, business, family, or project information.
- `restricted` — health, legal, financial, credentials, intimate identity, biometric, or similarly high-impact data.

The highest classification of any source governs a derived object unless a declassification decision proves the derivative contains no protected content.

## 6. Key hierarchy

```text
Offline recovery root
  -> workspace master key
      -> collection key
          -> object/data encryption key
```

- Recovery material is stored outside the ordinary runtime.
- Workspace master keys are rotatable.
- Data encryption keys are envelope-encrypted.
- Key identifiers, not key material, may appear in metadata.
- Key use is audited.
- Restricted workspaces may use local-only keys.
- Crypto-shredding is available by destroying the relevant wrapping key after policy checks.

## 7. Secrets

- Secrets reside in a dedicated secret broker or platform keystore.
- Services receive short-lived credentials.
- Connectors use the narrowest supported scopes.
- Secrets are redacted from logs, traces, prompts, and error messages.
- Secret scanning is a release gate.
- Prompt injection cannot cause direct secret retrieval because the model has no secret-broker permission.

## 8. Provider routing

Every model or external processing provider has an entry in `policies/provider_registry.example.yaml` describing:

- Approved data classifications.
- Retention behavior.
- Training-use terms.
- Geographic restrictions.
- Supported encryption.
- Contract status.
- Model identifiers.
- Logging policy.
- Current approval status.

Restricted content defaults to local processing. A provider may be used only when classification, owner policy, and task purpose all permit it.

## 9. Tool isolation

- MCP connectors execute behind a gateway.
- Inputs and outputs validate against schemas.
- Network egress is allow-listed.
- Filesystem access is sandboxed.
- Tool scopes are narrower than agent objectives.
- R2-R4 operations require idempotency keys.
- R3-R4 operations require approval receipts and precondition rechecks.
- Side effects are recorded even when execution fails partway.
- Compensation actions are defined for reversible writes.

## 10. Threat controls

### Prompt injection

Treat all retrieved content as untrusted data. Separate instructions from evidence, strip active content where possible, label source boundaries, and require policy checks outside the model.

### Data exfiltration

Enforce classification-aware egress, output scanning, provider routing, rate limits, and destination allow-lists.

### Confused deputy

Bind every tool request to a principal, purpose, workspace, resource, policy version, and approval scope.

### Memory poisoning

Require source provenance, duplicate checks, contradiction search, confidence thresholds, and approval for consequential personal memory.

### Agent runaway

Enforce token, time, recursion, tool, cost, and side-effect budgets with independent cancellation.

### Supply chain

Pin dependencies, generate an SBOM, scan artifacts, verify signatures, isolate build and runtime secrets, and maintain rollback artifacts.

## 11. Deletion protocol

A deletion request creates an authorized deletion job with a scope manifest.

The job:

1. Freezes new writes for the target scope when required.
2. Enumerates canonical objects, versions, sources, embeddings, indexes, caches, generated views, traces, exports under system control, and encryption keys.
3. Removes active-store payloads.
4. Removes or rebuilds derived indexes.
5. Deletes generated views containing the content.
6. Revokes or destroys keys when crypto-erasure is used.
7. Writes a non-sensitive tombstone and deletion receipt.
8. Verifies absence from active systems.
9. Registers backup expiry deadlines.
10. Reports external-provider or user-export limitations.

Targets:

- Active canonical stores: 24 hours.
- Search, graph, vector, cache, and generated-view projections: 4 hours after canonical deletion.
- Provider-controlled transient copies: per approved provider contract, recorded in the receipt.
- Encrypted backups: inaccessible through key destruction when supported; physical backup expiry no later than 35 days.
- Owner-created exports outside Animus control: disclosed as outside guaranteed deletion scope.

The tombstone may retain object identifier, version range, deletion time, policy, authorizing principal, and integrity proof. It may not retain sensitive payload or reversible derived text.

## 12. Incident response

High-severity conditions include:

- Unauthorized R3/R4 attempt.
- Suspected key or credential compromise.
- Restricted-data egress.
- Ledger/projection divergence.
- Untraceable side effect.
- Backup restore failure.
- Hidden or unexplained policy modification.

Emergency controls must disable connectors, model providers, memory commits, or all external actions without depending on the agent runtime.
