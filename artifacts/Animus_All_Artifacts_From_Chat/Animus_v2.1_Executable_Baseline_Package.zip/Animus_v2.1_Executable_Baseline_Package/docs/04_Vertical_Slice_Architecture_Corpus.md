# Vertical Slice: Architecture Corpus Reconciliation

## 1. Objective

Demonstrate the minimum trustworthy Animus loop by analyzing Animus's own architecture source corpus. The slice must convert heterogeneous design documents into traceable sources, claims, contradictions, assessments, decisions, and approved memory without performing an external side effect.

## 2. Inputs

The initial corpus contains:

- Mind Vision
- Context Spine
- Intelligence Swarm
- Memory Architecture
- True System Design Book
- Architecture Book v1
- System Design Documents v1
- Canonical Architecture v2 Reconciled
- This v2.1 package

Every file receives a source object, cryptographic hash, capture time, authority status, version label, and extraction record.

## 3. Required flow

1. **Register sources** — create source records and source-manifest entries.
2. **Extract observations** — preserve page, section, and line/segment anchors.
3. **Normalize claims** — classify claims by subject domain, cognitive role, and epistemic status.
4. **Detect conflicts** — find direct contradictions, terminology collisions, duplicate authority, and unresolved decisions.
5. **Build Context Envelope** — retrieve evidence for the question: “What is the current executable Animus architecture?”
6. **Run deliberation** — Researcher produces a supported interpretation; Critic attacks omissions, ambiguity, and false agreement.
7. **Synthesize** — preserve material dissent and confidence dimensions.
8. **Propose decisions** — create decision and memory candidates.
9. **Request approval** — owner approves, rejects, or edits each consequential proposal.
10. **Commit** — write event, object version/current projection, and outbox atomically.
11. **Project** — update search, graph, generated report, and requirement coverage.
12. **Evaluate** — execute schema, retrieval, contradiction, trace, policy, and replay tests.
13. **Exercise governance** — export the slice, run a deletion dry-run, restore from backup, and reproduce one trace.

## 4. Required known conflicts

The test corpus must include and detect at least these issues:

- Mixed use of domains for subject, cognition, presentation, and storage.
- Overlapping ownership of preferences and decisions.
- Single-state lifecycle mixing review, epistemic, lifecycle, and retention concerns.
- Mind Vision versus a formal Mind Charter.
- Object registry versus event ledger authority.
- Deletion versus immutable history and backups.
- Multiple agents versus genuinely independent evidence.
- Qualitative recovery language versus numeric recovery targets.

## 5. Agent contracts

### Researcher

Inputs: Context Envelope, source authority rules, claim schema.  
Tools: read-only corpus retrieval.  
Output: assessment with claim-to-source coverage, alternatives, uncertainty, and proposed decisions.  
Prohibited: memory writes, external tools, source-authority changes.

### Critic

Inputs: Researcher assessment and same evidence set plus omitted-result metadata.  
Objective: identify unsupported claims, category errors, correlated evidence, missing counterevidence, and policy violations.  
Output: structured critique with severity and required corrections.

### Synthesizer

Inputs: Researcher assessment, Critic output, provenance graph.  
Output: final assessment preserving unresolved dissent.  
Prohibited: representing consensus when a material objection remains unresolved.

## 6. Acceptance criteria

The slice passes only when:

- 100% of source files have hashes and authority status.
- 100% of normalized claims retain source anchors.
- All required known conflicts are detected.
- Retrieval has zero cross-workspace or classification leakage.
- Contradiction coverage is at least 95% on the labeled test set.
- No consequential memory is committed before approval.
- A forced failure between event and projection writes produces no partial commit.
- Replaying outbox entries creates no duplicate projection or side effect.
- The final report is reproducible from the captured trace.
- A clean restore satisfies the declared RPO and RTO.
- Export integrity hashes verify.
- Deletion dry-run enumerates every canonical and derived location.
- The validator and all critical release gates pass.

## 7. Deliberate fault injection

Test at minimum:

- Database failure after event insertion but before projection update.
- Duplicate outbox delivery.
- Stale approval receipt.
- Prompt-injected source text asking for tool execution.
- Missing source anchor.
- Correlated articles presented as independent sources.
- Conflicting valid-time intervals.
- Restricted source routed toward an unapproved provider.
- Interrupted restore.
- Deleted object still present in a vector index.

## 8. Produced artifacts

- Source and extraction objects.
- Claim and contradiction graph.
- Context Envelope.
- Researcher assessment.
- Critic assessment.
- Synthesis with dissent.
- Decision proposals.
- Approval receipts.
- Accepted memory objects.
- Ledger events.
- Trace bundle.
- Evaluation report.
- Architecture reconciliation report.
- Export archive and integrity manifest.
- Deletion dry-run report.
- Restore report.

## 9. Exclusions

This slice does not send messages, modify calendars, spend money, publish content, change external systems, or take physical-world action. Tool access is read-only except for writes to the isolated evaluation workspace.
