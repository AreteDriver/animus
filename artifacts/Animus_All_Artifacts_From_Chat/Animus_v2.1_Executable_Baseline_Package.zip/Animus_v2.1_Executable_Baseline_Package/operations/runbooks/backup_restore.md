# Runbook: Backup and Restore

## Trigger

Scheduled backup, quarterly restore exercise, incident recovery, pre-release verification, or owner-requested portability test.

## Backup procedure

1. Confirm backup target identity, encryption status, available capacity, and retention policy.
2. Record the current schema, policy, application, and key-metadata versions.
3. Create a consistent database checkpoint.
4. Capture canonical database changes and immutable source objects.
5. Store checksums and a signed manifest separately from payload objects.
6. Verify that revoked credentials and plaintext key material are absent.
7. Copy the encrypted backup to the configured separate failure domain.
8. Run automated integrity verification.
9. Write a backup event and operational receipt.
10. Alert on missed schedule, checksum failure, unencrypted content, or retention violation.

## Restore procedure

1. Declare the recovery point and target RPO/RTO.
2. Isolate the target environment from external connectors.
3. Provision clean infrastructure with no inherited credentials.
4. Restore key metadata and obtain required recovery authorization.
5. Restore the canonical relational database.
6. Verify ledger sequence, object versions, integrity hashes, and policy signatures.
7. Restore source objects and verify the source manifest.
8. Rebuild search, vector, graph, and generated-view projections from the outbox/ledger.
9. Reapply revocations and verify no expired approval is active.
10. Reproduce a reference trace.
11. Measure actual recovery point and elapsed restoration time.
12. Produce a restore report and obtain owner acceptance before reconnecting external tools.

## Abort conditions

- Integrity mismatch.
- Missing key authorization.
- Ledger gap or divergent projection.
- Revoked principal becomes active.
- Restricted data appears unencrypted.
- Recovery point cannot be established.

## Evidence

Retain backup and restore receipts, manifest hashes, measured RPO/RTO, test results, and remediation decisions.
