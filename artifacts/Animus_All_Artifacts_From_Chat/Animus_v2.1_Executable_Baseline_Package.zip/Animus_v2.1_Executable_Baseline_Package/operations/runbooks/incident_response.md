# Runbook: Security and Integrity Incident

## Severity 1 triggers

- Unauthorized or unexplained R3/R4 action.
- Restricted-data disclosure or unapproved provider routing.
- Credential or key compromise.
- Ledger/projection divergence affecting accepted state.
- Untraceable side effect.
- Charter or policy modification without valid approval.
- Backup or restore integrity failure affecting recoverability.

## Immediate containment

1. Activate the external-action kill switch.
2. Revoke affected principal, device, connector, and provider sessions.
3. Freeze memory and canonical writes if state integrity is uncertain.
4. Preserve structured metadata, hashes, and relevant logs without expanding sensitive-data exposure.
5. Isolate compromised devices or services.
6. Notify the sovereign owner with known facts, uncertainty, and current containment.

## Investigation

1. Establish the first known affected event and trace.
2. Compare ledger, projection, outbox, and tool receipts.
3. Identify the authorization and policy path.
4. Determine data scope, side effects, and provider exposure.
5. Test whether prompt injection, secret leakage, dependency compromise, or operator error contributed.
6. Preserve dissent and unknowns in the assessment.

## Recovery

1. Restore or repair canonical state through an authorized decision.
2. Rotate credentials and keys as required.
3. Rebuild derived projections.
4. Reconcile external side effects and execute compensation where safe.
5. Re-test critical gates and reproduce affected traces.
6. Re-enable capabilities incrementally through shadow and limited modes.

## Closure

Create an incident assessment, root-cause analysis, corrective decisions, lessons, updated tests, and evidence that the failure cannot silently recur.
