# Runbook: Deletion

## Trigger

Owner-approved deletion request, workspace retirement, legal requirement, expired retention, or compromised data scope.

## Procedure

1. Authenticate the owner and perform step-up verification for restricted or broad scopes.
2. Create a deletion job with immutable scope, reason, policy, and target deadlines.
3. Resolve the dependency graph: canonical versions, source captures, derivatives, embeddings, graph edges, caches, reports, traces, exports under system control, provider requests, and keys.
4. Present the dry-run inventory and limitations.
5. After approval, block or queue conflicting new writes.
6. Remove payload from active canonical stores while preserving only allowed tombstone metadata.
7. Destroy relevant wrapping keys when cryptographic erasure is selected.
8. Publish deletion events without sensitive payload.
9. Rebuild or purge search, vector, graph, cache, and generated-view projections.
10. Submit provider deletion requests where applicable and record contractual deadlines.
11. Register backup expiry and cryptographic inaccessibility state.
12. Verify absence using identifiers, content fingerprints, and projection scans.
13. Produce a deletion receipt listing completed, pending, external, and out-of-scope locations.
14. Escalate any target breach as a security incident.

## Required controls

- The job is idempotent.
- Failure resumes from a durable checkpoint.
- Tombstones cannot reconstruct deleted content.
- Audit records contain process evidence, not the sensitive payload.
- Owner-created exports outside Animus control are clearly disclosed.

## Completion

Active stores must complete within 24 hours. Derived indexes must complete within four hours after canonical deletion. Backup physical expiry must occur within 35 days unless law requires a documented exception.
