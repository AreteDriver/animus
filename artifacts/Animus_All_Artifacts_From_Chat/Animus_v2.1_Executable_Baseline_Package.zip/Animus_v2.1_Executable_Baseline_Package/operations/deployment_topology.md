# Deployment Topology and Trust Boundaries

## Baseline topology

```text
Owner devices
    |
    | device-bound authenticated session
    v
Experience interface
    |
    v
Identity + Policy Enforcement  ---- emergency control plane
    |
    +---- Context / Memory / Agent APIs
    |           |
    |           +---- Relational durable core
    |           |       - object versions/current projection
    |           |       - append-only event records
    |           |       - transactional outbox
    |           |
    |           +---- Rebuildable projections
    |                   - full-text search
    |                   - vector index
    |                   - knowledge/claim graph
    |
    +---- MCP Gateway ---- sandboxed connectors ---- external systems
    |
    +---- Provider Router ---- local models
                         \---- approved external models

Encrypted backup target in a separate failure domain
```

## Trust boundaries

1. **Owner device boundary** — local UI state and device credentials.
2. **Core boundary** — canonical data, policy, identity, event ledger, and keys metadata.
3. **Model boundary** — models receive only purpose-minimized context and no credentials.
4. **Connector boundary** — every external system is untrusted until gateway policy permits a specific request.
5. **Provider boundary** — external inference providers are separate data processors governed by the provider registry.
6. **Backup boundary** — encrypted copies use separate credentials and failure domains.

## Deployment profiles

### Local development

- Single owner workstation.
- SQLite durable core.
- Local object storage.
- Local model preferred.
- Connectors disabled by default.
- Synthetic or public fixtures.

### Evaluation

- Isolated workspace.
- PostgreSQL-compatible transaction tests.
- Recorded providers or approved test models.
- Fault injection enabled.
- No production external writes.

### Limited personal deployment

- PostgreSQL or validated local database.
- Encrypted backups.
- Device enrollment and MFA.
- R0-R2 connectors only unless individually approved.
- Restricted data routes local by default.

### General personal deployment

Requires all critical gates, successful restore, incident drill, deletion exercise, and explicit owner decision.
