# ADR-011: Use orthogonal context coordinates

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

The v2 domain list mixed subject areas, cognitive roles, generated views, and lifecycle/storage states.

## Decision

Classify objects independently by subject domain, artifact type, cognitive role, workflow, epistemic standing, lifecycle, storage tier, and presentation.

## Positive consequences

- Eliminates ownership collisions.
- Supports generated folders and views without ontology distortion.

## Costs and risks

- Migration requires ambiguity review.
- More fields must be populated and validated.

## Rejected alternatives

- Retaining SELF/WORLD/PROJECTS/MEMORY/VIEWS/ARCHIVE as peer domains.
- Encoding ontology in folder paths.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
