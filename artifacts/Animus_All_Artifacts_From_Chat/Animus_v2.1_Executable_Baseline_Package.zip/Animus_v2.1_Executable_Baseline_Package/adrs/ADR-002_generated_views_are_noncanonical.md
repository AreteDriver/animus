# ADR-002: Generated views are noncanonical

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Folders, dashboards, summaries, and indexes are useful but can silently become competing sources of truth.

## Decision

All views are rebuildable projections over canonical objects. View write-back must create a separately validated proposal.

## Positive consequences

- Prevents convenience layers from corrupting canonical state.
- Allows indexes and dashboards to be replaced or rebuilt.

## Costs and risks

- Projection lag must be visible.
- View-specific annotations need an explicit canonical home.

## Rejected alternatives

- Allowing direct edits to derived dashboards.
- Making folders the primary ontology.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
