# ADR-005: Tool security is enforced outside the model

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Prompt-level instructions are not a reliable security boundary.

## Decision

All tool access passes through policy decision and enforcement points that validate identity, scope, classification, approval, budget, and schemas.

## Positive consequences

- Prompt injection cannot directly expand authority.
- Denials and side effects become auditable.

## Costs and risks

- Gateway availability becomes critical.
- Connectors require explicit contracts and sandboxing.

## Rejected alternatives

- Trusting system prompts to prevent harmful actions.
- Giving agents standing broad credentials.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
