# ADR-010: Preserve material dissent

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Agent synthesis can erase meaningful disagreement and manufacture consensus.

## Decision

Critiques and alternative judgments remain attached to assessments until resolved or explicitly accepted as tension.

## Positive consequences

- Improves epistemic honesty.
- Provides evidence for later review and recalibration.

## Costs and risks

- Outputs may be less tidy.
- Requires materiality rules to avoid noise.

## Rejected alternatives

- Majority vote among agents.
- Synthesizer silently choosing one answer.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
