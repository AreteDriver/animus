# ADR-004: Memory begins as a candidate

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Direct model writes create poisoning, duplication, identity distortion, and weak provenance.

## Decision

Models and detectors create memory candidates. Validation, contradiction search, policy, and owner approval where required precede commit.

## Positive consequences

- Preserves human sovereignty and memory quality.
- Creates measurable precision and rejection behavior.

## Costs and risks

- Adds latency and review burden.
- Low-risk automatic acceptance needs carefully bounded policy.

## Rejected alternatives

- Direct LLM-to-memory writes.
- Treating conversation history as automatically durable memory.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
