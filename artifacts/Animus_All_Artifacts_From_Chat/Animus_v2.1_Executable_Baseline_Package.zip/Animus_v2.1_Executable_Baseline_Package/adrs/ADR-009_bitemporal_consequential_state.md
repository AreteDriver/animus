# ADR-009: Bitemporal consequential state

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Animus must distinguish when a fact was true from when it learned or recorded it.

## Decision

Consequential objects carry valid-time and transaction-time intervals. Corrections create versions and do not rewrite historical knowledge state.

## Positive consequences

- Supports historical reconstruction and temporal retrieval.
- Prevents present facts from leaking into past analyses.

## Costs and risks

- Queries and migrations are more complex.
- Unknown time must be represented explicitly.

## Rejected alternatives

- Single created/updated timestamp.
- Overwriting prior values.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
