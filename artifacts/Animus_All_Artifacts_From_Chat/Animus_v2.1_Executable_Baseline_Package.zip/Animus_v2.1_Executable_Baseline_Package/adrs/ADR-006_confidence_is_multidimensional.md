# ADR-006: Confidence is multidimensional

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

A single confidence score hides whether uncertainty comes from evidence, reasoning, prediction, or actionability.

## Decision

Assessments record separate evidence, reasoning, prediction, and action confidence. Forecast probabilities remain distinct.

## Positive consequences

- Improves calibration and decision quality.
- Allows strong evidence with weak actionability to be represented honestly.

## Costs and risks

- Interfaces and evaluations become more complex.
- Users need clear explanations of dimensions.

## Rejected alternatives

- One opaque confidence number.
- Converting model log probabilities directly into decision confidence.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
