# ADR-014: Envelope encryption, cryptographic erasure, and bounded backup expiry

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Deletion must coexist with audit history, projections, external providers, and backups.

## Decision

Use workspace/collection envelope encryption, remove active and derived content promptly, retain minimal tombstones, and expire encrypted backups within 35 days. Destroy wrapping keys when crypto-erasure is appropriate.

## Positive consequences

- Makes deletion operationally defined.
- Limits residual sensitive content.

## Costs and risks

- Key loss can cause irreversible data loss.
- Provider limitations must be disclosed.

## Rejected alternatives

- Indefinite backups.
- Tombstones containing recoverable payload.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
