# ADR-013: Single sovereign owner with isolated workspaces

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

The v2 `tenant` field implied a conventional multi-tenant platform that conflicts with the personal Mind goal and increases attack surface.

## Decision

Use one owner identity and multiple isolated workspaces. Devices, services, agents, and connectors are subordinate principals.

## Positive consequences

- Matches the product purpose.
- Simplifies sovereignty and authorization.
- Preserves compartmentalization.

## Costs and risks

- Collaboration requires explicit sharing mechanisms later.
- Workspace aggregation must obey the least permissive policy.

## Rejected alternatives

- Conventional SaaS tenancy in the baseline.
- Multiple equal sovereign principals.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
