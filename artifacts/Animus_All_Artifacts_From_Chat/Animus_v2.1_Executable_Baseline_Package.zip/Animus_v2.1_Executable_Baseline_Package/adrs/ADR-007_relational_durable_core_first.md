# ADR-007: Relational durable core first

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

The architecture could be implemented with multiple specialized databases, but premature distribution increases failure modes.

## Decision

Use SQLite for local development and PostgreSQL for shared or production deployment as the canonical relational core. Vector, graph, and search systems are rebuildable projections.

## Positive consequences

- Strong transactions, mature backup, simple operations.
- Supports bitemporal and relational constraints.

## Costs and risks

- Specialized query performance may require later projections.
- Migration between SQLite and PostgreSQL needs compatibility tests.

## Rejected alternatives

- Graph database as canonical truth.
- Multiple independently writable stores.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
