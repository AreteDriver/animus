# ADR-015: Evidence independence must be demonstrated

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Multiple agents, models, or articles can share the same origin and correlated errors.

## Decision

Track source origin, derivation, syndication, model provider, model family, and prompt lineage. Compute independence from the dependency graph and require genuinely separate support for high-confidence pattern claims.

## Positive consequences

- Reduces manufactured confidence.
- Improves pattern and forecast validity.

## Costs and risks

- Dependency detection is imperfect.
- Diversity can increase cost and latency.

## Rejected alternatives

- Counting agents as independent votes.
- Counting syndicated articles as separate confirmation.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
