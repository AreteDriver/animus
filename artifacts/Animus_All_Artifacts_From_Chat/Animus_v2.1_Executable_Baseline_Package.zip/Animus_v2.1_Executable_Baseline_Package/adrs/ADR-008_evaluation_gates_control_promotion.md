# ADR-008: Evaluation gates control promotion

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Model demonstrations do not prove reliable capability.

## Decision

Capabilities advance through development, evaluation, shadow, limited, and general stages only when critical metric gates pass.

## Positive consequences

- Prevents anecdotal promotion.
- Makes regressions and risk explicit.

## Costs and risks

- Requires labeled sets and ongoing maintenance.
- Metrics can be gamed if not tied to real outcomes.

## Rejected alternatives

- Calendar-based rollout.
- Manual optimism as the release criterion.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
