# ADR-012: Separate review, epistemic, lifecycle, and storage state

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

The universal v2 state machine treated candidate, disputed, active, archived, and deleted as mutually exclusive.

## Decision

Use independent workflow_status, epistemic_status, lifecycle_status, and storage_tier fields with separate transition rules.

## Positive consequences

- Objects can be active and disputed or approved and archived without contradiction.
- State transitions become testable.

## Costs and risks

- Cross-field constraints need validation.
- Reporting must display the relevant dimensions.

## Rejected alternatives

- One mega-state enum.
- Implicit state encoded only in tables or folders.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
