# ADR-001: Separate faculties, planes, and modules

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

Earlier designs used cognitive ideas, technical architecture, and deployable components interchangeably.

## Decision

Represent Mind faculties as conceptual capabilities, technical planes as responsibility groupings, and runtime modules as deployable services with explicit interfaces.

## Positive consequences

- Keeps philosophy stable while implementations change.
- Enables service ownership and testing without reducing the Mind vision to microservices.

## Costs and risks

- Requires mappings between conceptual and operational models.
- Documentation must label which layer each term belongs to.

## Rejected alternatives

- Treating every faculty as a service.
- Using one undifferentiated architecture diagram.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
