# ADR-003: Transactional ledger, object projection, and outbox

**Status:** Accepted  
**Decision date:** June 16, 2026  
**Baseline:** 2.1.0

## Context

v2 named both an event ledger and an object registry without deciding authority or partial-failure behavior.

## Decision

Use one relational transaction to write the immutable event, versioned object state/current projection, and outbox entry. The ledger is authoritative for accepted change history; the object registry is authoritative for current and versioned reads.

## Positive consequences

- No partial accepted state.
- Deterministic downstream rebuilds.
- Supports idempotent consumers and audit history.

## Costs and risks

- Requires strict transaction boundaries and replay tooling.
- The event history is not a license to retain deleted sensitive payloads.

## Rejected alternatives

- Independent dual writes.
- Distributed event streaming before the relational core is proven.

## Enforcement

- Relevant schemas and policies must encode this decision where possible.
- The coverage matrix must contain at least one verification method.
- A superseding ADR is required to change the decision.
- Exceptions require an owner-approved decision with scope and expiry.

## Review triggers

Review this ADR when a material implementation constraint, security incident, measured failure, or change in system purpose invalidates its assumptions.
