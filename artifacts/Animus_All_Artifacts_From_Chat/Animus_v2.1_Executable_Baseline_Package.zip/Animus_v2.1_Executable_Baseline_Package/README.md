# Animus v2.1 Executable Baseline

**Version:** 2.1.0  
**Status:** Canonical executable baseline  
**Effective date:** June 16, 2026  
**Owner model:** One sovereign human owner with isolated workspaces

This package converts the reconciled v2 architecture into an implementation contract. It defines the system's governing charter, orthogonal context model, object schemas, architectural decisions, security boundaries, measurable service objectives, recovery requirements, evaluation gates, diagrams, fixtures, and the first end-to-end vertical slice.

## Authority

The order of authority is:

1. `docs/00_Mind_Charter_v1.md`
2. `docs/01_Executable_Baseline_Specification.md`
3. Machine-readable schemas, policies, registries, and ADRs in this package
4. Approved project-level specifications derived from this baseline
5. Earlier Animus documents, retained only as historical design sources

Where prose and machine-readable rules conflict, the stricter enforceable rule governs until an ADR resolves the conflict.

## Core decisions

- Animus is a governed, persistent personal intelligence system—not an autonomous sovereign actor.
- The human owner remains the final authority over values, identity, permissions, consequential memory, and high-impact actions.
- Context is represented with orthogonal coordinates rather than mixed folder categories.
- Consequential knowledge uses bitemporal validity.
- Memory writes begin as candidates and require policy-governed validation.
- Tool permissions are enforced outside the language model.
- The append-only event record, object projection, and outbox are written in one relational transaction.
- Agent count is not evidence independence.
- Capabilities are admitted only after measurable acceptance gates pass.
- Generated views are rebuildable and never become canonical merely because they are convenient.

## Package map

- `docs/` — charter and normative specifications
- `schemas/` — JSON Schema contracts for canonical objects and runtime artifacts
- `policies/` — data handling, provider routing, and approval rules
- `adrs/` — accepted architectural decisions and consequences
- `operations/` — service catalog, SLOs, recovery targets, topology, and runbooks
- `diagrams/` — editable Mermaid source
- `tests/` — coverage matrix, acceptance gates, fixtures, and validator
- `migrations/` — deterministic mapping from v2 vocabulary to v2.1 coordinates
- `source_manifest.yaml` — provenance and authority status for source documents

## Validation

Run:

```bash
python tests/validate_baseline.py
```

A baseline release is valid only when schema compilation, positive fixtures, negative fixtures, cross-file identifiers, ADR index checks, and requirement coverage checks pass.
