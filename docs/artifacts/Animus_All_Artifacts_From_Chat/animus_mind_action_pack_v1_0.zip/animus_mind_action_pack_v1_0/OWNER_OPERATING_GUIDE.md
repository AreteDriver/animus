# Owner Operating Guide

## Your role

You are defining the constitutional boundaries of a system that may eventually observe, infer, recommend, and act across important parts of your life.

Your highest-value decisions are:

- what Animus may know;
- what it may infer;
- what it may retain;
- what it may recommend;
- what it may execute;
- what requires fresh approval;
- what it must never do.

## Weekly operating cadence

### Select one outcome

Choose one complete trust loop, not several subsystems.

Good:

> Ingest a calendar event, create a sourced commitment, detect a conflict, prepare a proposed reschedule, and require approval before changing anything.

Bad:

> Build memory, agents, a graph, and a dashboard.

### Review the chain

Ask Claude to demonstrate:

1. source received;
2. observation stored;
3. claim derived;
4. epistemic status assigned;
5. confidence and source reliability recorded;
6. policy evaluated;
7. action prepared;
8. approval checked;
9. result verified;
10. ledger and trace displayed;
11. failure recovery tested.

### Accept evidence, not claims

A capability is accepted only with:

- passing test output;
- a ledger record or control-surface view;
- migration and rollback notes;
- updated contracts and ADRs;
- a known-limitations list;
- a disable path.

## Questions before granting autonomy

- Can it be reversed?
- Who is affected besides me?
- What evidence justifies action?
- What happens if the model is confidently wrong?
- Can malicious content trigger it?
- Does approval apply to this exact target and scope?
- Will I understand the action later?
- Does this increase my capacity or only remove effort?
- Can I disable it immediately?
- What data leaves my control?

## Recommended initial domains

Start with low-consequence work:

- project documentation;
- repository issue preparation;
- read-only calendar conflict detection;
- research collection;
- drafts that cannot send.

Do not begin with health treatment, money movement, legal submissions, employment communications, home access, destructive file operations, or communication on your behalf.

## Acceptance statement

```text
I accept capability <name> at maturity level <L#>.
Permitted domains:
Permitted actions:
Approval requirements:
Data scope:
Known limitations:
Review date:
Emergency disable path:
```
