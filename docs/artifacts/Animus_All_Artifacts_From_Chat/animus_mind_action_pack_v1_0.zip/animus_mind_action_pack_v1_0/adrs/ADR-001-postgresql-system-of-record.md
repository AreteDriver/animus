# ADR-001: PostgreSQL as the Authoritative Operational Store

## Status

Proposed

## Context

Animus requires transactional records for claims, evidence metadata, permissions, actions, policy decisions, and audit history. A vector store alone cannot express authority, temporal validity, or relational integrity.

## Decision

Use PostgreSQL as the authoritative operational store. Treat vector, graph, search, and analytical stores as derived projections.

## Consequences

- Strong consistency and migrations become central.
- Derived stores require rebuild procedures.
- Sensitive access can use roles, schemas, and row-level controls.
- Operational discipline is required for backup and restore.
