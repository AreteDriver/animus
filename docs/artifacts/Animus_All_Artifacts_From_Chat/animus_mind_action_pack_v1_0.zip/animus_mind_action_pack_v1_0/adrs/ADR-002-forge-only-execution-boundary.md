# ADR-002: Forge as the Sole External Execution Boundary

## Status

Proposed

## Decision

All external effects pass through Forge. Core and Swarm may propose actions but may not invoke effectors directly.

## Rationale

A single boundary enables policy, approval, idempotency, verification, compensation, telemetry, and emergency shutdown.

## Consequences

Tool integrations must implement Forge capability contracts. Bypass paths are critical defects.
