# ADR-003: Deterministic Policy Outside Model Generation

## Status

Proposed

## Decision

Models may explain policy or propose policy drafts but do not issue authoritative permission decisions. A deterministic policy layer evaluates structured inputs.

## Consequences

Policy inputs and decisions become auditable. Model prompt changes cannot silently expand authority.
