# ADR-005: Control Surfaces Before Increased Autonomy

## Status

Proposed

## Decision

A capability cannot advance in authority unless the owner can inspect, disable, revoke, and recover it.

## Consequences

Interface and observability work are part of the feature definition.
