# ADR-004: Admit Event Bus and Workflow Engine Only After Measured Need

## Status

Proposed

## Decision

Begin with in-process or database-backed events. Pilot NATS JetStream when replayable multi-consumer distribution is required. Pilot Temporal when long-running workflows, timers, retries, and compensation exceed the current implementation.

## Consequences

The system avoids premature distributed complexity while preserving adapter boundaries.
