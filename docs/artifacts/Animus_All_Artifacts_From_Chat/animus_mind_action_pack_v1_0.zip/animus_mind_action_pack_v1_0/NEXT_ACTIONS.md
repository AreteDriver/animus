# Next Actions

## Today

1. Fill in `contracts/project_manifest.yaml`.
2. Confirm names and locations of the public-kernel and private-application repositories.
3. Reconcile ADR-001 through ADR-005 with existing canonical architecture.
4. Select one low-risk first vertical slice.
5. Install Claude assets into a branch, not the default branch.
6. Run package quality gates.
7. Use `/repo-recon` and `/vertical-slice`.

## Recommended first slice

**Capability:** Evidence-backed project commitment tracker.

Flow:

1. Ingest a synthetic project note.
2. Preserve the raw note as evidence.
3. Create a claim that a commitment exists.
4. Store due date as valid time.
5. Detect a missed or conflicting commitment.
6. Prepare a reminder action.
7. Policy permits drafting but requires approval for external sending.
8. Show claim, evidence, policy result, and proposed action in a ledger view.
9. Simulate execution; do not contact a real person.
10. Test prompt injection, duplicate events, stale approvals, and rollback.

## Do not start yet

- unrestricted email sending;
- browser or computer control;
- financial transactions;
- health recommendations that alter treatment;
- legal filing;
- broad sensor ingestion;
- self-modifying policies;
- autonomous Swarm execution;
- a new graph database.

## Owner decisions required

- Repository paths
- First private domain
- Default retention windows
- Emergency authority: initially none
- Whether approval is per action or session-bound
- Which source classes may create claims automatically
- Monthly model and infrastructure budget
- Local-only data classes
