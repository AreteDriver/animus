# Technology Admission Prompt

```text
Evaluate whether Animus should adopt <TECHNOLOGY> now.

Use `templates/technology_admission.md`.

Reject adoption unless there is a measured workload or reliability problem the current stack cannot reasonably solve.

Include:
- benefits;
- new failure modes;
- public/private impact;
- provenance impact;
- operational cost;
- migration and exit plan;
- a time-boxed spike with acceptance metrics;
- keep, defer, or reject recommendation.
```
