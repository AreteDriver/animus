# Vertical Slice Prompt

```text
Design the smallest complete vertical slice for:
<CAPABILITY>

Maximum authority: <L0-L7>
External effects enabled: <YES/NO>

The slice must include:
source -> evidence -> claim -> context/memory -> plan -> policy -> approval -> Forge -> effect or simulation -> verification -> ledger -> recovery

Return a completed `templates/vertical_slice_charter.md`.
Do not write code until the charter is internally consistent and owner decisions are identified.
```
