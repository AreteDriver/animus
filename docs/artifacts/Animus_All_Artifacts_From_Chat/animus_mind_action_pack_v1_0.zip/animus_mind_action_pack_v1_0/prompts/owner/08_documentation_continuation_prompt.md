# Documentation Continuation Prompt

```text
Continue the Animus Mind documentation from the current canonical pack.

Before adding a document:
1. identify the unresolved implementation question it answers;
2. prove it is not already covered;
3. identify whether it belongs in public kernel or private application;
4. state which contract, ADR, test, or workflow will consume it.

Prefer executable documentation: schemas, examples, acceptance tests, decision tables, and operating procedures.
Do not add philosophy without an implementation consequence.
```
