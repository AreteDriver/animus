# Acceptance Review Prompt

```text
Run a capability acceptance review for <CAPABILITY>.

Do not accept claims of completion without evidence.

Inspect:
- contracts;
- authority and approval;
- tests;
- adversarial cases;
- privacy scan;
- provenance chain;
- action verification;
- compensation or rollback;
- telemetry and ledger;
- disable path;
- known limitations.

Complete `templates/capability_acceptance.md` and recommend:
ACCEPT, ACCEPT WITH RESTRICTIONS, or REJECT.
```
