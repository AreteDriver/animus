# Architecture Reconciliation Prompt

```text
Compare this Mind Action Pack with the current canonical Animus architecture and repository state.

Do not assume this pack overrides existing canon.

Return:
- agreements;
- direct conflicts;
- terminology conflicts;
- duplicated mechanisms;
- missing contracts;
- public/private placement changes;
- ADRs to accept, revise, or reject;
- a proposed precedence order;
- a migration plan that preserves working behavior;
- decisions that require the owner.

Cite repository files and exact sections.
```
