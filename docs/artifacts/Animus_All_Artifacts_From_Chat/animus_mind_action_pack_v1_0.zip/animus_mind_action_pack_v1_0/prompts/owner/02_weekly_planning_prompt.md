# Weekly Planning Prompt

```text
Review the current Animus roadmap, open work, recent evidence, failed tests, and unresolved decisions.

Produce one recommended vertical slice for this week.

Constraints:
- It must be small enough to complete and evaluate this week.
- It must pass through the full evidence-policy-action-recovery loop.
- It must not increase authority unless the control surface and recovery are ready.
- Prefer closing a trust gap over adding a new agent or integration.

Return:
1. recommended slice;
2. why it is the highest-leverage next step;
3. repository placement;
4. dependencies;
5. authority and risk;
6. acceptance evidence;
7. owner decisions;
8. explicit work not to do this week.
```
