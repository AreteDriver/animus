# Independent Review Prompt

```text
Review the implementation of <CAPABILITY> without assuming the author is correct.

Check:
- contract compliance;
- public/private placement;
- policy and approval bypass;
- evidence and provenance;
- temporal correctness;
- idempotency;
- verification;
- compensation;
- telemetry leakage;
- missing tests;
- undocumented behavior.

Return blocking, high, medium, and low findings with evidence.
```
