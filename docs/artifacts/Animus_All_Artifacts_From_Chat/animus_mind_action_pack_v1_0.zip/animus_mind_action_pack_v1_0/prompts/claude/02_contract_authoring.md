# Contract Authoring Prompt

```text
Author or revise the contract for <RECORD OR INTERFACE>.

Define:
- purpose;
- fields and types;
- invariants;
- temporal semantics;
- sensitivity and consent;
- provenance;
- lifecycle states;
- invalid examples;
- versioning and migration;
- public synthetic examples;
- unit and contract tests.

Reject unknown consequential fields by default.
Do not implement orchestration until the contract is reviewed.
```
