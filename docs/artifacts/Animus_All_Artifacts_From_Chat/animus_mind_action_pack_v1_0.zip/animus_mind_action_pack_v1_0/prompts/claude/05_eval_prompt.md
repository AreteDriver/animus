# Evaluation Prompt

```text
Build or run the evaluation suite for <CAPABILITY>.

Include deterministic, integration, adversarial, privacy, failure, and recovery cases.
Record fixture hashes, model/provider versions when applicable, policy version, environment, failures, and reproducibility instructions.

Do not average critical policy or privacy failures into a passing aggregate score.
```
