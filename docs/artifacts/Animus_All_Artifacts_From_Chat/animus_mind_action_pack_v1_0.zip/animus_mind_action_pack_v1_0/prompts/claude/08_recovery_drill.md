# Recovery Drill Prompt

```text
Design and execute a safe recovery drill for <CAPABILITY> using synthetic data.

Simulate:
- process crash;
- duplicate event;
- timeout after uncertain external result;
- stale approval;
- corrupted derived index;
- policy service unavailable;
- model provider unavailable;
- backup restore.

Demonstrate safe state, detection, owner notification, recovery steps, and ledger evidence.
```
