# Implementation Prompt

```text
Implement the approved vertical-slice charter for <CAPABILITY>.

Follow CLAUDE.md and AGENTS.md.
Modify only required files.
Do not expand authority or scope.
Use deterministic validation around model output.
Route every effect through Forge.
Add tests, telemetry, ledger events, migration, rollback, and documentation.

At completion return the required completion report with exact test output and residual risk.
```
