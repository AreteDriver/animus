# Documentation Reconciliation Prompt

```text
Reconcile code, contracts, ADRs, examples, tests, and documentation for <CAPABILITY>.

Find discrepancies in field names, lifecycle states, authority levels, event subjects, repository placement, and acceptance criteria.

Update only after identifying which artifact is canonical.
Return unresolved conflicts instead of guessing.
```
