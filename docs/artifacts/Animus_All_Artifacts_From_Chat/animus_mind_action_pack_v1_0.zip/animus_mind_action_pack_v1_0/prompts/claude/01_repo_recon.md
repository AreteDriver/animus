# Repository Reconnaissance Prompt

```text
Inspect the repository without modifying it.

Map:
- architecture and module boundaries;
- current canonical documents;
- Core, Forge, Swarm, memory, policy, eval, and control-surface implementations;
- databases and migrations;
- effectors and MCP integrations;
- tests and CI gates;
- secrets and private-data boundaries;
- unresolved TODOs and drift.

Return evidence by path and line or symbol, conflicts with the Mind Action Pack, and the smallest safe integration point.
```
