# Public/Private Audit Prompt

```text
Audit the repository for public/private boundary violations.

Inspect:
- names, emails, locations, health, legal, employment, family, financial, and credential data;
- real documents in tests and fixtures;
- logs, traces, snapshots, prompts, examples, screenshots, and generated files;
- Git history references where available;
- private endpoints and repository names.

Classify findings and propose synthetic replacements.
Do not expose the sensitive values in the report; redact them.
```
