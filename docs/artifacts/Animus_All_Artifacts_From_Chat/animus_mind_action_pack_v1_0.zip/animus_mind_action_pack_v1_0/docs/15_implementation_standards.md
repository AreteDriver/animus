# Implementation Standards

## Contract-first development

Define record shape, invariants, failure states, and examples before orchestration code.

## Data standards

- UTC internally; preserve source timezone.
- Stable sortable IDs.
- Explicit sensitivity and consent metadata.
- Immutable raw evidence or content hash.
- Append-only history for consequential records.
- Derived indexes are rebuildable.

## Code standards

- Type checking for public contracts.
- Strict validation at boundaries.
- Deterministic fixtures.
- Provider-neutral interfaces.
- No secrets in source, logs, traces, tests, or prompts.
- Dependency pinning and update review.
- Feature flags for new effectors.

## Test standards

Every capability includes:

- unit tests;
- contract tests;
- integration tests;
- policy tests;
- adversarial tests;
- privacy tests;
- failure and recovery tests;
- evidence capture.

## Migration standards

Every migration includes:

- preconditions;
- backup;
- forward step;
- validation;
- rollback or compensation;
- data-loss analysis.

## Pull request gate

A PR cannot merge unless docs, contracts, tests, telemetry, rollback, and privacy review are current.
