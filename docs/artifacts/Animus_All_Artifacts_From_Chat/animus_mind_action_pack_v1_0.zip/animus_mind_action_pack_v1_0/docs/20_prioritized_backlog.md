# Prioritized Backlog

## P0 — Constitutional and trust-loop foundation

- Repository boundary manifest
- Claim and evidence contracts
- Action envelope and state machine
- Policy decision contract
- Approval binding
- Ledger events
- Public/private audit
- Emergency effect disable
- First vertical slice

## P1 — Memory and context

- Memory classes and lifecycle
- Temporal validity
- Correction and supersession
- Revocation and deletion
- Retrieval authorization
- Owner-visible memory use

## P2 — Observability and control

- OpenTelemetry correlation
- Claim/evidence views
- Authority dashboard
- Action dashboard
- Evaluation dashboard
- Backup and recovery drill

## P3 — Durable orchestration

- NATS JetStream spike
- Temporal spike
- Long-running approval wait
- Workflow compensation
- Replay and deduplication

## P4 — World intelligence

- DuckDB and Parquet analytical store
- Source registry
- Competing hypotheses
- Scenario generation
- Prediction calibration
- Pattern backtesting

## Deferred

- Broad physical sensors
- High-autonomy Swarm
- Graph database
- A2A federation
- SPIFFE/SPIRE
- Self-modifying policy
- Emergency authority
