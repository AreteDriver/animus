# Target Technology Architecture

## Design posture

Use the smallest infrastructure that proves the trust loop. Add distribution only after a single-node implementation is correct.

## Build now

### PostgreSQL

Authoritative store for entities, claims, evidence metadata, memory, permissions, actions, policy decisions, ledger events, and workflow references.

### pgvector

Derived semantic index. Never authoritative. Rebuildable from canonical records.

### OpenTelemetry

Trace intent, retrieval, claims, plan, policy, approval, Forge, effect, verification, and memory. Do not record sensitive payloads by default.

### DuckDB and Parquet

Use for historical analysis, evaluation datasets, world-data snapshots, backtesting, and pattern detection.

### Cedar policy spike

Create an adapter and compare Cedar with the existing policy mechanism. Do not bind core contracts to one engine.

## Pilot after trust-loop completion

### NATS JetStream

Pilot when more than one durable consumer needs replay or independent recovery.

### Temporal

Pilot when workflows span minutes or days and require timers, retries, approval waits, or compensation.

## Defer

- Neo4j until measured multi-hop workloads justify it.
- Apache Iceberg until the analytical lake is large or multi-writer.
- A2A until external agent interoperability is required.
- SPIFFE/SPIRE until distributed workload identity is necessary.

## Technology admission test

Ask which measured problem the technology solves, why the current stack cannot solve it, what new failure modes appear, what data becomes duplicated, how provenance is preserved, how it is removed, and what acceptance benchmark applies.
