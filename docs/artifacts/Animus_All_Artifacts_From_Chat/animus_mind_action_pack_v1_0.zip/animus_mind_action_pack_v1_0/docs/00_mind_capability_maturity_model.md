# Mind Capability Maturity Model

## Purpose

The phrase “personal Mind” must be testable. This model defines what Animus can claim at each maturity level.

## L0 — Tool collection

The system has models, prompts, scripts, and integrations but no durable trust loop.

Exit criteria:

- capabilities are inventoried;
- public/private boundaries are known;
- tools have owners and risk classes;
- no autonomy claim is made.

## L1 — Reactive assistant

Animus responds to explicit requests and produces grounded outputs.

Required:

- source citation;
- contract validation;
- no hidden action;
- clear distinction between answer and effect.

## L2 — Contextual partner

Animus uses durable, inspectable context to understand the owner’s actual goal and constraints.

Required:

- typed memory;
- temporal validity;
- contradiction handling;
- owner-visible context use;
- correction and deletion paths.

## L3 — Anticipatory advisor

Animus detects risks, opportunities, conflicts, or commitments before being asked.

Required:

- intervention doctrine;
- interruption budget;
- false-positive evaluation;
- confidence thresholds;
- owner-configured domains.

## L4 — Delegated operator

Animus performs approved, reversible actions through Forge.

Required:

- action envelope;
- deterministic policy;
- approval binding;
- idempotency;
- verification;
- compensation or rollback;
- complete ledger.

## L5 — Strategic steward

Animus coordinates multi-step work across time while protecting mission integrity and owner agency.

Required:

- durable workflows;
- world and self models;
- competing hypotheses;
- long-horizon evaluation;
- developmental assistance;
- constitutional refusal;
- continuity and disaster recovery.

## L6 — Bounded physical-world operator

Animus interacts with sensors or physical systems under strict domain controls.

Required:

- physical hazard analysis;
- fail-safe state;
- local manual override;
- independent sensing and verification;
- narrow, tested authority.

This level is intentionally deferred.

## Promotion rule

Promotion is per capability and per domain, not global. Animus can be L4 for project documentation and L1 for health.

## Required scorecard

For each capability record:

- domain;
- maturity level;
- evidence;
- source coverage;
- authority level;
- reversibility;
- evaluation results;
- residual risk;
- review date;
- disable path.
