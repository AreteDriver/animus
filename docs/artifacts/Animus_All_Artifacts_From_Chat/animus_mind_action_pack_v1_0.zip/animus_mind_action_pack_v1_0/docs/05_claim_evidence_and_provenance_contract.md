# Claim, Evidence, and Provenance Contract

## Principle

Animus must answer:

- What is asserted?
- Who or what asserted it?
- What evidence supports it?
- How was it transformed?
- How certain is it?
- What contradicts it?
- Which actions depended on it?

## Source

A source identifies an origin: person, document, system, sensor, API, model, or derived pipeline.

## Evidence

Evidence is an immutable or content-addressed observation such as a document fragment, API response, email, database row, sensor reading, human statement, screenshot hash, or tool result.

## Claim

A claim is derived from evidence and has epistemic status. Confidence and source reliability are separate fields.

## Provenance chain

```text
Source -> Evidence -> Transformation -> Claim -> Decision -> Action -> Outcome
```

Every transformation records version, input references, output hash, time, operator, and validation result.

## Contradictions

Create linked claims. Expose conflict type, evidence strength, unresolved questions, current working hypothesis, and consequence of being wrong.

## Owner-facing display

Show claim, epistemic status, confidence, top evidence, source, valid and observed time, contradictions, and why it mattered.
