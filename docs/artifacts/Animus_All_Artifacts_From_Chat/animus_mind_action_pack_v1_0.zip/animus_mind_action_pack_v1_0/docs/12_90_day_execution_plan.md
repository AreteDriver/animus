# 90-Day Execution Plan

## Outcome

At day 90, Animus demonstrates one trusted, low-risk delegated capability through the complete evidence-policy-action-recovery loop.

## Week 1 — Reconciliation and baseline

Deliver project manifest, repository boundary map, canonical precedence list, ADR decisions, baseline tests, and first vertical-slice charter.

## Weeks 2–3 — Contracts and storage

Deliver Source, Evidence, Claim, Memory, Action, PolicyDecision, and LedgerEvent models; PostgreSQL migrations; synthetic fixtures; schema validation; provenance query; correction and contradiction behavior.

## Weeks 4–5 — Memory and world-model slice

Deliver project and commitment records, memory proposal and review lifecycle, temporal validity, stale and revoked filtering, and owner-visible context explanation.

## Weeks 6–7 — Authority and Forge

Deliver authority levels, policy adapter, approval token binding, action state machine, idempotency, simulated effect, verification, and compensation.

## Weeks 8–9 — Observability and control surface

Deliver trace correlation, activity ledger, claim/evidence view, policy explanation, action cancel/disable control, and privacy-safe logging.

## Weeks 10–11 — Adversarial and durability work

Deliver prompt-injection corpus, memory-poisoning tests, public/private scan, crash and retry tests, infrastructure spike only if required, and backup/restore drill.

## Week 12 — Acceptance

Deliver evaluation report, residual-risk register, operating guide, accepted capability record, next-domain recommendation, and updated roadmap.

## Scope discipline

One production-quality vertical slice is worth more than ten partially integrated agents.
