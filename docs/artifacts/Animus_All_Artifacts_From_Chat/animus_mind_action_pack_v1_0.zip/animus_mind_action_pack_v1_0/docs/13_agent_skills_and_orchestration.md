# Agent Skills and Orchestration

## Distinction

- **CLAUDE.md and rules:** facts and constraints needed every session.
- **Skills:** reusable procedures invoked by the owner or Claude.
- **Subagents:** isolated specialists with limited tools and context.
- **Hooks:** deterministic enforcement at lifecycle events.
- **Scripts:** repeatable validation and scaffolding outside model judgment.

## Included skills

- `/repo-recon`
- `/vertical-slice`
- `/contract-author`
- `/provenance-review`
- `/authority-review`
- `/threat-model`
- `/eval-gate`
- `/memory-curation`
- `/public-private-audit`
- `/recovery-plan`
- `/acceptance-review`

## Included subagents

- animus-coordinator
- mind-architect
- implementation-worker
- contract-engineer
- provenance-analyst
- policy-guardian
- threat-modeler
- eval-engineer
- recovery-engineer
- documentation-steward
- repository-boundary-guardian

## Recommended orchestration

1. Coordinator receives the owner outcome.
2. Mind architect maps architecture and conflicts.
3. Boundary guardian classifies placement.
4. Contract engineer defines records and interfaces.
5. Policy guardian identifies authority behavior.
6. Threat modeler generates abuse cases.
7. Implementation worker builds the smallest slice.
8. Eval engineer creates deterministic and adversarial tests.
9. Provenance analyst checks evidence chain.
10. Recovery engineer tests failure and rollback.
11. Documentation steward reconciles docs.
12. Owner runs acceptance review.

## Separation of duties

A writer cannot be the only reviewer. A policy proposer cannot approve its own policy. An implementation agent cannot declare owner acceptance. Read-only agents must not write through Bash or MCP.
