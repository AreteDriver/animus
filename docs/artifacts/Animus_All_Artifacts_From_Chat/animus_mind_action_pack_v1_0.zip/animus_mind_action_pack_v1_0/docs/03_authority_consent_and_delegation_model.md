# Authority, Consent, and Delegation Model

## Principle

Capability is not authority. Access to a tool does not grant permission to use it for any purpose.

## Authority levels

- **L0 — No access:** cannot observe.
- **L1 — Observe:** read explicitly permitted data.
- **L2 — Analyze:** transform or infer without external effect.
- **L3 — Recommend:** propose and explain an action.
- **L4 — Prepare:** create a draft or pending change.
- **L5 — Execute reversible action:** bounded effect with tested reversal.
- **L6 — Consequential action with fresh approval:** send, publish, delete, purchase, alter access, contact third parties, or change important records.
- **L7 — Emergency authority:** narrow and time-bound. Default disabled.

## Policy inputs

- principal;
- capability;
- action;
- target;
- purpose;
- domain;
- data scope;
- sensitivity;
- reversibility;
- consequence class;
- approval token;
- approval expiry;
- environment;
- policy version.

## Approval binding

Approval binds to:

- exact action class;
- exact target or bounded target set;
- exact scope;
- maximum cost or consequence;
- expiry;
- number of executions;
- content hash when content matters;
- policy version.

## Delegation

A delegating principal may grant only authority it already possesses and may narrow but not widen scope.

## Policy result

Return:

- permit, deny, or require_approval;
- reason code;
- human explanation;
- obligations;
- policy version;
- evaluated input hash.

## Default deny

Unknown tools, unknown targets, schema failures, expired approvals, conflicting policy, or missing provenance default to deny or prepare-only.
