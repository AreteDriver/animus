# Personal World Model Ontology

## Objective

Create a coherent, temporal, evidence-backed representation of the owner’s world without collapsing observations, reports, inferences, and predictions into one memory pool.

## Core entity classes

- Person
- Organization
- Project
- Goal
- Commitment
- Decision
- Event
- Document
- Location
- Asset
- Account
- Device
- Capability
- Policy
- Risk
- Opportunity
- Claim
- Evidence
- Prediction
- Action
- Workflow

## Core relations

- owns
- participates_in
- depends_on
- blocks
- supports
- contradicts
- supersedes
- caused_by
- correlated_with
- authorized_by
- evidenced_by
- affects
- located_at
- committed_to
- decided_by
- derived_from

Relations are first-class records with time and provenance, not anonymous graph edges.

## Claim model

A claim contains:

- subject;
- predicate;
- object or value;
- epistemic status;
- confidence;
- valid time;
- observed time;
- source and evidence;
- source reliability;
- sensitivity;
- consent scope;
- contradiction or supersession links.

## Time model

Store at least:

- **valid time:** when the assertion is true in the modeled world;
- **observed time:** when Animus learned it;
- **recorded time:** when it entered the system;
- **expiry or review time:** when it must be revalidated.

## Epistemic statuses

- `observed`
- `reported`
- `inferred`
- `predicted`
- `disputed`
- `unknown`

Status changes produce a new version or linked claim; they do not rewrite history.

## Identity resolution

Use deterministic identifiers where possible. Sensitive or consequential merges require owner confirmation and a reversible merge record.

## Projection strategy

PostgreSQL remains authoritative. Other representations are projections:

- pgvector for semantic retrieval;
- DuckDB and Parquet for analytical history;
- optional graph projection after workload evidence;
- search index for full text.

## Initial implementation

Implement only:

- Source
- Evidence
- Claim
- Project
- Commitment
- Action
- PolicyDecision
- LedgerEvent

Expand only when a vertical slice requires it.
