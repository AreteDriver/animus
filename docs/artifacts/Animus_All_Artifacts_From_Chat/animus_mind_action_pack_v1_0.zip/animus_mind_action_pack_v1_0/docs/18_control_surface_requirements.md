# Control Surface Requirements

## Principle

No increase in autonomy without a corresponding increase in owner visibility and control.

## Minimum views

### Claims and evidence

Show claim, status, confidence, source, evidence, contradictions, validity, and affected actions.

### Memory

Show type, source, lifecycle state, sensitivity, consent scope, last use, correction, and deletion controls.

### Authority

Show principals, capabilities, scopes, expiry, approval requirements, and revocation.

### Actions

Show state, target, purpose, policy decision, approval, execution, verification, and compensation.

### Sources

Show source trust class, connection health, last ingestion, schema drift, and disable control.

### Evaluations

Show current gates, failures, regression history, and capability maturity.

## Emergency controls

- disable all effects;
- pause workflows;
- revoke a tool;
- revoke a principal;
- enter read-only mode;
- export ledger;
- start recovery procedure.

## Explanation standard

The owner should understand an important intervention or action without reading raw chain-of-thought or source code.
