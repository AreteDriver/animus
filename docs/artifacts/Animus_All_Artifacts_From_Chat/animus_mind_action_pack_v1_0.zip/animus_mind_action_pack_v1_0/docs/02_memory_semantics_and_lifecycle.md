# Memory Semantics and Lifecycle

## Principle

Memory is governed state, not a vector database. Embeddings help retrieve memory; they do not define truth, permission, or retention.

## Memory classes

- **Episodic:** events and interactions.
- **Semantic:** durable facts and concepts.
- **Procedural:** how tasks are performed.
- **Commitment:** promises, obligations, and deadlines.
- **Preference:** owner choices with context, strength, and expiry.
- **Strategic:** goals, plans, assumptions, and unresolved questions.
- **Relational:** people, roles, trust, and boundaries.
- **Reflective:** lessons, corrections, and changed beliefs.

## Lifecycle states

- proposed
- quarantined
- accepted
- active
- stale
- superseded
- disputed
- revoked
- deleted or tombstoned

## Write rules

Automatic writes are allowed only for low-risk observations whose source and scope are clear.

Require owner review for:

- sensitive traits;
- relationship judgments;
- health, legal, financial, or employment inference;
- identity merges;
- durable preferences inferred from limited evidence;
- negative judgments about a person;
- policies or authority changes.

## Retrieval order

1. authorization and consent;
2. validity and freshness;
3. domain relevance;
4. source reliability;
5. semantic similarity;
6. confidence.

Never retrieve data the acting principal is not authorized to see.

## Correction

Corrections create a new record and a supersession link. Record reason, source, and affected downstream actions.

## Deletion modes

- index removal;
- logical revocation;
- cryptographic deletion where supported;
- physical deletion;
- legal hold;
- privacy-preserving tombstone.

## Evaluation

Test correct retrieval, stale exclusion, revoked-data denial, contradiction visibility, correction propagation, and sensitive-data isolation.
