# Sovereignty, Continuity, and Recovery

## Objective

Animus must remain usable, inspectable, exportable, and recoverable if a provider, model, integration, or host fails.

## Sovereignty requirements

- owner controls encryption keys where practical;
- canonical data has documented export formats;
- provider adapters are replaceable;
- policy and audit records are not vendor-trapped;
- local-only data classes are enforceable;
- reduced mode can operate without cloud models;
- effects can be disabled without losing read access.

## Degraded modes

### Read-only safe mode

No external effects; policies, evidence, claims, and ledger remain readable.

### Local model mode

Lower capability, no sensitive cloud egress, explicit limitations.

### Offline continuity mode

Essential documents, policies, recovery contacts, latest verified state, and manual procedures.

## Emergency stop

Provide global effect disable, domain disable, tool disable, agent disable, workflow pause, credential revocation, and event-consumer stop.

## Exit test

The owner can export core records, replace a model provider, restore from backup, and disable all effects without losing the ability to understand what happened.
