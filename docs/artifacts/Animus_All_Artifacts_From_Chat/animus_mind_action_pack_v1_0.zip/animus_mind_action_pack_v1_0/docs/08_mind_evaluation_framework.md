# Mind Evaluation Framework

## Evaluation layers

### Contract correctness

Schema acceptance and rejection, migration compatibility, deterministic serialization, and unknown-field handling.

### Retrieval and memory

Precision, recall, stale exclusion, contradiction visibility, authorization filtering, correction propagation, and deletion behavior.

### Epistemic discipline

Fact versus inference classification, confidence calibration, source reliability handling, unsupported claim rate, citation correctness, and competing hypotheses.

### Authority and action

Default deny, approval scope, expired approval rejection, duplicate execution resistance, consequence classification, recovery success, and bypass resistance.

### Security

Prompt injection, indirect injection, malicious tool output, memory poisoning, secret leakage, cross-agent escalation, and public/private leakage.

### Intervention

Useful intervention rate, false positives, missed critical events, interruption burden, challenge appropriateness, and owner-agency impact.

### Long horizon

Goal consistency, mission drift, strategy revision, recurring workflow durability, provider substitution, and outage recovery.

## Required gates

A capability cannot advance beyond prepare-only unless:

- contract tests pass;
- policy tests pass;
- adversarial tests pass;
- privacy scan passes;
- verification is demonstrated;
- compensation is tested;
- ledger evidence is complete;
- owner acceptance is recorded.

## Metrics

Maintain a dashboard rather than a single trust score.
