# Animus Mind Threat Model

## Assets

- owner identity and private records;
- credentials and tokens;
- policies and authority grants;
- memory and world model;
- action channels;
- source registry;
- model and prompt configuration;
- audit and provenance records;
- public project reputation;
- private application integrity.

## Primary threats

### Prompt injection

Controls: content/instruction separation, no authority from retrieved content, tool allowlists, policy outside model, injection tests.

### Memory poisoning

Controls: quarantine, provenance, source reliability, owner review for sensitive inference, contradiction preservation, write limits.

### Privilege escalation

Controls: explicit principal identity, default deny, non-transitive grants, approval binding, policy audit, no self-modifying authority.

### Confused deputy

Controls: bind purpose, caller, target, and scope; do not reuse approval tokens across contexts; validate delegation chain.

### Tool impersonation or supply-chain compromise

Controls: pinned dependencies, tool registry, endpoint identity, schema validation, sandboxing, provenance.

### Data exfiltration

Controls: redaction, local-only classes, private/public scan, secret detection, telemetry minimization, egress policy.

### Autonomous feedback loop

Controls: loop counters, independent verification, source diversity, human checkpoints, budget and time limits, competing hypotheses.

### Recovery sabotage

Controls: immutable backup, restore tests, separate credentials, append-only audit export, offline emergency procedure.

## Required review

Every capability documents assets, actors, entry points, authority, abuse cases, detection, prevention, recovery, residual risk, and owner decision.
