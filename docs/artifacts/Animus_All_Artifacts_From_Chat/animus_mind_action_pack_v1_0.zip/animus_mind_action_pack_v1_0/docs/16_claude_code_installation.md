# Claude Code Installation Guide

## Project memory

Place repository-wide constraints in `CLAUDE.md`. Keep it short enough to remain useful. Move detailed procedures into skills and detailed architecture into versioned docs.

## Rules

Place path-scoped or topic-scoped constraints in `.claude/rules/`.

Recommended files:

- `architecture.md`
- `security.md`
- `contracts.md`
- `evidence.md`

## Skills

Each skill lives at `.claude/skills/<skill-name>/SKILL.md` and contains a specific repeatable workflow. Use skills rather than copying long prompts repeatedly.

## Subagents

Each subagent lives at `.claude/agents/<agent-name>.md`. Give the narrowest practical tools and a structured result format.

## Hooks

Use hooks only for deterministic enforcement, such as protected-path blocking, secret scanning, and automatic validation. Hooks do not replace policy enforcement in Animus itself.

## Adoption sequence

1. Create a branch.
2. Copy root and `.claude` files.
3. Adjust repository-specific paths.
4. Review every hook.
5. Run validation scripts.
6. Test with synthetic data.
7. Merge only after the repository owner approves the diff.
