# Action Execution and Compensation Contract

## Principle

An action is a governed state machine, not a model tool call.

## Lifecycle

1. proposed
2. validated
3. policy_pending
4. approval_pending
5. authorized
6. prepared
7. executing
8. verification_pending
9. succeeded, failed, uncertain, or compensated
10. closed

## Action envelope

Required fields:

- actor;
- requested action;
- purpose;
- target;
- domain;
- data scope;
- risk class;
- reversibility;
- idempotency key;
- timeout;
- policy decision;
- approval;
- supporting claims and evidence;
- expected outcome;
- verification method;
- compensation action;
- telemetry correlation ID.

## Forge responsibilities

- schema validation;
- capability lookup;
- policy evaluation;
- approval validation;
- execution isolation;
- timeout and retry;
- idempotency;
- result capture;
- verification;
- compensation;
- ledger emission.

## Verification

A successful API response is not sufficient proof. Verify using the best independent signal available.

## Compensation

Compensation may be exact reversal, corrective action, notification and manual recovery, quarantine, restoration from backup, or policy lockout.

If an action cannot be reversed, it is consequential even when technically simple.
