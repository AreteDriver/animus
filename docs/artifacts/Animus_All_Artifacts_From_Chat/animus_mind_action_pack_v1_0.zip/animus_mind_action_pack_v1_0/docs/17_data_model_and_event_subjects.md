# Data Model and Event Subjects

## Minimal records

- Source
- Evidence
- Claim
- Memory
- PolicyDecision
- Approval
- ActionEnvelope
- ActionOutcome
- LedgerEvent

## Event subject convention

Use nouns and past-tense state changes.

```text
source.registered
observation.received
evidence.recorded
claim.proposed
claim.accepted
claim.contradicted
memory.proposed
memory.accepted
memory.revoked
policy.evaluated
approval.requested
approval.granted
action.proposed
action.authorized
action.started
action.succeeded
action.failed
action.compensated
verification.completed
intervention.proposed
intervention.dismissed
evaluation.failed
```

## Event requirements

Every event records:

- event ID;
- event type and version;
- occurred time;
- recorded time;
- actor;
- correlation ID;
- causation ID;
- source record references;
- sensitivity;
- payload schema version.

## Replay

Consumers must be idempotent. Replaying an event must not duplicate external effects.
