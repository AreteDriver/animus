# Prompt Operating Manual

## Prompt hierarchy

Use the smallest durable mechanism:

- permanent project facts belong in `CLAUDE.md` or path-scoped rules;
- repeatable procedures belong in skills;
- isolated specialist work belongs in subagents;
- non-negotiable enforcement belongs in hooks;
- one-time objectives belong in owner prompts;
- repeatable validation belongs in scripts.

## Strong prompt anatomy

A strong task prompt includes:

1. outcome;
2. repository;
3. scope and exclusions;
4. authority level;
5. sensitive data classes;
6. governing documents;
7. required evidence;
8. tests;
9. rollback;
10. owner decisions.

## Anti-patterns

Avoid:

- “make Animus smarter”;
- “build the whole architecture”;
- unspecified autonomy;
- mixing public and private work;
- asking the model to invent policy;
- accepting code without tests or evidence;
- asking one agent to implement and approve its own work.

## Iteration method

1. Start with `/repo-recon`.
2. Use `/vertical-slice` to produce a charter.
3. Run specialist reviews before implementation.
4. Build.
5. Run `/eval-gate`, `/provenance-review`, and `/recovery-plan`.
6. Run `/acceptance-review` only when evidence exists.
