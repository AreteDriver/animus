# First Vertical Slice Specification

## Capability

Evidence-backed project commitment tracker.

## Goal

Demonstrate the full trust loop without contacting a third party or changing an external system.

## Scenario

A synthetic project note states:

> Prepare the public-kernel boundary review by Friday and do not publish private application details.

Animus must:

1. register the note source;
2. store the exact note as evidence;
3. create a reported claim about the commitment;
4. extract valid due time;
5. create a project and commitment record;
6. detect if the commitment is overdue or conflicts with another deadline;
7. propose a reminder;
8. evaluate policy;
9. permit an internal draft but deny external sending without approval;
10. simulate execution through Forge;
11. verify that a draft record exists;
12. display the complete chain in the ledger;
13. compensate by deleting or revoking the draft in a failure drill.

## Authority

Maximum L4: prepare only.

## Required tests

- schema validation;
- exact evidence hash;
- fact/inference classification;
- stale due-date behavior;
- duplicate event replay;
- prompt injection inside the project note;
- external-send denial;
- expired approval rejection;
- draft compensation;
- public/private leakage scan;
- trace and ledger completeness.

## Definition of done

The owner can inspect evidence, claim, policy, action, verification, and recovery from one control-surface flow.
