# Sensor and Data Source Registry

## Principle

A source is not trusted merely because it is connected. Every source has a contract, purpose, risk class, and owner.

## Registry fields

- source ID;
- name;
- type;
- owner;
- domain;
- connection method;
- data classes;
- sensitivity;
- authorization;
- ingestion cadence;
- valid-time semantics;
- expected latency;
- source reliability;
- retention;
- allowed transformations;
- allowed consumers;
- prompt-injection exposure;
- health checks;
- disable path.

## Trust classes

- T0 untrusted public content
- T1 authenticated but not authoritative
- T2 domain-reliable source
- T3 authoritative system of record
- T4 owner-attested record

## Initial sources

Begin with synthetic and low-risk sources: local project notes, repository events, test calendar feeds, public documentation, and manually entered commitments.

Defer full email ingestion, health records, finance, browser history, continuous location, microphones, cameras, and home access controls.
