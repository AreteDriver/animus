# Policy Examples

## Prepare internal project draft

Permit when:

- principal is `agent:project-steward`;
- action is `create_internal_reminder_draft`;
- domain is `project-management`;
- authority level is at most L4;
- data sensitivity is internal or lower;
- no third party is contacted.

## External send

Require fresh approval when:

- any message leaves Animus;
- any person or organization is contacted;
- the content contains confidential or restricted data;
- the target or content differs from the approved hash.

## Default deny

Deny when:

- action schema is invalid;
- target is unknown;
- approval is expired;
- policy version changed after approval;
- source evidence is missing for a factual premise;
- action attempts to modify policy or authority.
