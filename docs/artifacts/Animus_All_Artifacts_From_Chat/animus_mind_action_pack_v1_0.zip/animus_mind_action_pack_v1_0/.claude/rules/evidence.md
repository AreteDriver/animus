# Evidence Rules

1. Separate raw evidence from derived claims.
2. Use explicit epistemic status.
3. Confidence is not source reliability.
4. A model output alone cannot become durable fact.
5. Durable claims reference evidence or record its absence.
6. Contradictions remain visible.
7. Preserve transformation lineage.
8. Verify action outcomes independently when possible.
9. Acceptance requires a reproducible evidence chain.
