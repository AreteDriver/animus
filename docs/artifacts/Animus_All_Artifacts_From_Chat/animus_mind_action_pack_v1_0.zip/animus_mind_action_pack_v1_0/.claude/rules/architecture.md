# Architecture Rules

1. Public kernel and private application are separate security domains.
2. Core never communicates directly with Swarm.
3. Forge is the sole execution and delegation bridge.
4. No external effect may bypass an action envelope and policy decision.
5. Models propose; deterministic code validates contracts and authority.
6. PostgreSQL is the proposed authoritative operational store.
7. Vector indexes, graphs, caches, and analytical projections are derived and rebuildable.
8. New infrastructure requires an ADR with measured trigger, migration, and exit plan.
9. Control-surface support is part of every capability.
10. Build complete vertical slices before horizontal expansion.
