# Contract Rules

1. Validate records at every boundary.
2. Reject unknown consequential fields by default.
3. Preserve IDs, valid time, observed time, source, provenance, sensitivity, and consent.
4. Do not mutate historical facts in place; supersede or contradict.
5. Every action has idempotency, timeout, verification, and recovery semantics.
6. Schema changes require migration, compatibility analysis, examples, and tests.
7. Model output is a proposal until deterministic validation succeeds.
8. Store policy input, version, decision, reason, and obligations.
9. Use synthetic examples in public code.
