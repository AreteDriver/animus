---
name: acceptance-review
description: Decide whether a capability is ready for its claimed maturity and authority.
---

# Capability Acceptance Review


Verify contracts, policy, tests, adversarial results, provenance, verification, recovery, control surface, disable path, limitations, and owner acceptance. Recommend ACCEPT, ACCEPT WITH RESTRICTIONS, or REJECT.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
