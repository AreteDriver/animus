---
name: repo-recon
description: Inspect the repository and produce an evidence-backed architecture and risk map before changes.
---

# Repository Reconnaissance


1. Read `CLAUDE.md`, `AGENTS.md`, canonical docs, package manifests, and ADRs.
2. Inspect repository tree, dependency files, migrations, tests, CI, and deployment configuration.
3. Locate Core, Forge, Swarm, memory, policy, evaluation, observability, and control-surface code.
4. Identify public/private boundaries and possible leaks.
5. Compare implementation to current canon.
6. Return paths, symbols, conflicts, unknowns, and the safest integration point.

Do not modify files.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
