---
name: contract-author
description: Create strict versioned records and interfaces before implementation.
---

# Contract Author


Define fields, invariants, lifecycle, temporal semantics, sensitivity, consent, provenance, invalid examples, migration, and tests. Use synthetic public examples. Reject unknown consequential fields by default.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
