---
name: provenance-review
description: Verify the full source-to-outcome evidence chain.
---

# Provenance Review


Trace Source -> Evidence -> Transformation -> Claim -> Decision -> Action -> Outcome. Flag unsupported claims, missing hashes, silent transformations, hidden contradictions, and actions that cannot be reconstructed.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
