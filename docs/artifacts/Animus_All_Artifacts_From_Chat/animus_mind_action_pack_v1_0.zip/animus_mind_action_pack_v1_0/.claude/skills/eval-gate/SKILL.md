---
name: eval-gate
description: Run or design the required deterministic and adversarial evaluation gates.
---

# Evaluation Gate


Do not issue a single aggregate pass when a critical policy, privacy, or recovery case fails. Return reproducible evidence and a blocking decision.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
