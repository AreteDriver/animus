---
name: public-private-audit
description: Detect owner-specific or secret material in public artifacts.
---

# Public Private Audit


Scan source, docs, tests, fixtures, logs, traces, prompts, snapshots, and generated artifacts. Redact findings and propose synthetic replacements.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
