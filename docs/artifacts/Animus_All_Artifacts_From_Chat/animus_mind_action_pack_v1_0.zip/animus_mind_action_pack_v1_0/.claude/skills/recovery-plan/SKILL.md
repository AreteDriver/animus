---
name: recovery-plan
description: Define crash, retry, compensation, backup, and emergency-disable behavior.
---

# Recovery Planner


For each failure stage, state detection, safe state, retry, idempotency, compensation, owner notification, ledger evidence, and manual procedure.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
