---
name: threat-model
description: Generate concrete abuse cases, controls, tests, and recovery for a capability.
---

# Threat Model


Use `templates/threat_scenario.md`. Cover prompt injection, memory poisoning, privilege escalation, confused deputy, exfiltration, replay, feedback loops, and recovery sabotage.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
