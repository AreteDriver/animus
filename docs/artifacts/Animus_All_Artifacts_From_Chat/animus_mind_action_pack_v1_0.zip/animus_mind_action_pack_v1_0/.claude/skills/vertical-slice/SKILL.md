---
name: vertical-slice
description: Turn one owner outcome into a complete evidence-policy-action-recovery charter.
---

# Vertical Slice Designer


1. Parse the requested capability and maximum authority.
2. Identify source, evidence, claim, memory, policy, action, verification, ledger, and recovery steps.
3. Identify repository placement and sensitive data.
4. List explicit exclusions.
5. Define acceptance and adversarial tests.
6. Complete `templates/vertical_slice_charter.md`.
7. Stop before coding if owner decisions remain.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
