---
name: authority-review
description: Evaluate capability, consent, approval binding, and delegation.
---

# Authority Review


Identify principal, action, target, scope, purpose, sensitivity, reversibility, authority level, approval requirements, expiry, and policy version. Test default deny and approval reuse.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
