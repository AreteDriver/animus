---
name: memory-curation
description: Review proposed memories for type, evidence, sensitivity, consent, validity, and lifecycle.
---

# Memory Curation


Separate explicit owner statements from inferences. Require review for sensitive or durable inferred preferences. Preserve corrections and contradictions.


## Required output

- Summary
- Evidence
- Risks
- Unknowns
- Required owner decisions
- Recommended next action
