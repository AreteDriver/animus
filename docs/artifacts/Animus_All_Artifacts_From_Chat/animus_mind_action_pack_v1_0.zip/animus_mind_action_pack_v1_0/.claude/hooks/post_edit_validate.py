#!/usr/bin/env python3
import json, subprocess, sys

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(0)

path = payload.get('tool_input', {}).get('file_path', '') or payload.get('tool_input', {}).get('path', '')
if not isinstance(path, str):
    sys.exit(0)

normalized = path.replace('\\', '/')
commands = []
if '/contracts/' in normalized or normalized.startswith('contracts/'):
    commands.append([sys.executable, 'scripts/validate_pack.py'])
if normalized.endswith('CLAUDE.md') or '/.claude/' in normalized or normalized.startswith('.claude/'):
    commands.append([sys.executable, 'scripts/scan_public_private.py', '--root', '.'])

for command in commands:
    result = subprocess.run(command, text=True, capture_output=True)
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr, file=sys.stderr)
        sys.exit(result.returncode)

sys.exit(0)
