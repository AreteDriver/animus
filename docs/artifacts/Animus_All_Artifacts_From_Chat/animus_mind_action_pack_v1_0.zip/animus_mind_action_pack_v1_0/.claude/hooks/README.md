# Hook Notes

These hooks are conservative examples. Review their path assumptions before enabling.

- `protect_paths.py` blocks edits to secrets, production data, and generated backups.
- `post_edit_validate.py` runs lightweight validation after edits to contracts or Claude configuration.

Hooks supplement but do not replace Animus policy enforcement.
