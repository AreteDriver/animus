#!/usr/bin/env python3
import json, os, sys

PROTECTED_PARTS = (
    '.env', '/secrets/', '/production-data/', '/backups/', 'credentials', 'private_keys'
)

try:
    payload = json.load(sys.stdin)
except Exception:
    sys.exit(0)

path = ''
for key in ('file_path', 'path'):
    value = payload.get('tool_input', {}).get(key)
    if isinstance(value, str):
        path = value.replace('\\', '/')
        break

lower = path.lower()
if any(part in lower for part in PROTECTED_PARTS):
    print(json.dumps({
        'decision': 'block',
        'reason': f'Protected path requires explicit owner handling: {path}'
    }))
    sys.exit(2)

sys.exit(0)
