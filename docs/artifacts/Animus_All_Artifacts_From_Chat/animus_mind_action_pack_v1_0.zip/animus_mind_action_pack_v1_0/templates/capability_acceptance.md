# Capability Acceptance

## Capability

## Domain

## Maturity level

## Authority level

## Permitted actions

## Approval requirements

## Data scope

## Evidence

## Evaluation results

## Known limitations

## Residual risk

## Disable path

## Review date

## Owner acceptance
