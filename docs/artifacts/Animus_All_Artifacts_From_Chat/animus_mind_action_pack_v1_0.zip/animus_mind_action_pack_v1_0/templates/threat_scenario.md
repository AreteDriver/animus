# Threat Scenario

## Capability

## Asset

## Threat actor

## Entry point

## Preconditions

## Attack path

## Expected impact

## Detection

## Prevention

## Recovery

## Test case

## Residual risk

## Owner decision
