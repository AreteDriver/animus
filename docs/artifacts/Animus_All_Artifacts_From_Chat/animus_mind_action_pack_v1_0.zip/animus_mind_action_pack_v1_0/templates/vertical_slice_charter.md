# Vertical Slice Charter

## Capability

## Owner outcome

## Repository placement

## Scope

## Explicit exclusions

## Data classes

## Maximum authority

## Governing contracts and ADRs

## Trust-loop steps

## Acceptance tests

## Adversarial tests

## Telemetry and ledger evidence

## Migration

## Recovery and disable path

## Owner decisions
