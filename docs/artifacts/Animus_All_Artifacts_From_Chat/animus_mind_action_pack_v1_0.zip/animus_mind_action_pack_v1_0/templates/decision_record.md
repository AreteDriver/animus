# Decision Record

## Decision

## Category

Constitutional, architectural, operational, product, or experimental.

## Context

## Options considered

## Decision and rationale

## Consequences

## Reversal trigger

## Review date

## Owner acceptance
