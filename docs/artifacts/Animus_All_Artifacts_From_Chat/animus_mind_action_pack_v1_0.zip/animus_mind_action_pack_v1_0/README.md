# Animus Mind Action Pack

**Version:** 1.0  
**Status:** Proposed implementation package  
**Date:** 2026-06-17  
**Audience:** Arete, Claude Code, collaborators, and future maintainers

## Purpose

This package converts the personal “Mind” goal into implementable architecture, contracts, prompts, agent skills, tests, and execution scripts.

The target is not an omnipotent assistant. It is a persistent, evidence-aware, policy-governed intelligence that:

- understands the owner and the external world across time;
- preserves uncertainty and provenance;
- coordinates tools through explicit authority;
- performs reversible work safely;
- explains what it did and why;
- increases the owner’s agency rather than replacing it.

## Canonical relationship

This package is a **proposed extension**, not an automatic replacement for the current Animus canon. Reconcile it against the current canonical architecture, executable baseline, ADRs, and roadmap before adoption.

The following constraints are treated as binding unless existing canon explicitly says otherwise:

1. The public kernel and private application remain separate repositories and security domains.
2. Core does not communicate directly with Swarm.
3. Forge is the sole bridge from owner intent to delegated execution and Swarm coordination.
4. Control surfaces precede increased autonomy.
5. Contracts, tests, evidence, policy, and recovery are first-class architecture.
6. Models may propose authority decisions but may never grant themselves authority.

## Repository placement

### Public kernel

Place reusable, non-personal mechanisms here:

- claim, evidence, event, memory, and action contracts;
- authorization interfaces and policy adapters;
- Forge orchestration primitives;
- workflow and event abstractions;
- evaluation harnesses;
- observability conventions;
- generic source and sensor interfaces;
- synthetic reference implementations.

### Private application

Place owner-specific or sensitive material here:

- personal ontology instances and relationship graph;
- actual memories, documents, credentials, and source records;
- domain policies and authority grants;
- health, legal, financial, family, employment, and location data;
- private MCP configuration;
- personal agents, prompts, dashboards, and intervention rules;
- production deployment manifests.

Never move private fixtures into the public repository to make a test pass. Create synthetic fixtures instead.

## Read order

1. `CLAUDE.md`
2. `OWNER_OPERATING_GUIDE.md`
3. `docs/00_mind_capability_maturity_model.md`
4. `docs/01_personal_world_model_ontology.md`
5. `docs/02_memory_semantics_and_lifecycle.md`
6. `docs/03_authority_consent_and_delegation_model.md`
7. `docs/05_claim_evidence_and_provenance_contract.md`
8. `docs/06_action_execution_and_compensation_contract.md`
9. `docs/07_mind_threat_model.md`
10. `docs/08_mind_evaluation_framework.md`
11. `docs/12_90_day_execution_plan.md`
12. `docs/13_agent_skills_and_orchestration.md`
13. `docs/19_first_vertical_slice_specification.md`

## First implementation target

Build one complete trust-loop vertical slice:

> A trusted source produces an observation; Animus stores the source and evidence, creates a claim with explicit epistemic status, requests a low-risk reversible action, evaluates policy, obtains approval when required, executes through Forge, verifies the outcome, records telemetry, and exposes the complete chain in the activity ledger.

Do not begin with a large autonomous swarm. Prove this loop first.

## Package structure

- `docs/` — system design and operating doctrine
- `contracts/` — schemas, examples, and policy samples
- `adrs/` — proposed architecture decisions
- `prompts/` — reusable prompts for the owner and Claude
- `.claude/skills/` — project skills callable in Claude Code
- `.claude/agents/` — specialized Claude Code subagents
- `.claude/rules/` — persistent project rules
- `.claude/hooks/` — deterministic safeguards
- `scripts/` — validation, audit, scaffolding, and quality gates
- `templates/` — implementation and review records

## Immediate use

1. Read `NEXT_ACTIONS.md`.
2. Fill in `contracts/project_manifest.yaml`.
3. Choose one low-risk first vertical slice.
4. Copy the appropriate Claude assets into the target repository on a branch.
5. Run `bash scripts/run_quality_gates.sh`.
6. Start with `/repo-recon` and `/vertical-slice`.

## Acceptance rule

A capability is not done because code exists. It is done when:

- contract and authority behavior are explicit;
- tests and adversarial cases pass;
- telemetry and ledger evidence exist;
- failure and recovery are demonstrated;
- the owner-facing explanation is understandable;
- the capability can be disabled;
- no private information leaked into public artifacts.
