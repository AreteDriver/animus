#!/usr/bin/env python3
"""Generate a Markdown index of package files."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'generated' / 'INDEX.md'
OUT.parent.mkdir(parents=True, exist_ok=True)
lines = ['# Package Index', '']
for p in sorted(ROOT.rglob('*')):
    if p.is_file() and '.git' not in p.parts and p != OUT:
        lines.append(f'- `{p.relative_to(ROOT)}`')
OUT.write_text('\n'.join(lines) + '\n', encoding='utf-8')
print(OUT)
