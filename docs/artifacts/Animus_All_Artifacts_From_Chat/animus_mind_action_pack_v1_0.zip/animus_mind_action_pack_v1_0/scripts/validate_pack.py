#!/usr/bin/env python3
"""Validate the action pack structure and JSON examples using the standard library."""
from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    'README.md', 'CLAUDE.md', 'AGENTS.md',
    'docs/00_mind_capability_maturity_model.md',
    'docs/19_first_vertical_slice_specification.md',
    'contracts/project_manifest.yaml',
    'contracts/schemas/source.schema.json',
    'contracts/schemas/evidence.schema.json',
    'contracts/schemas/claim.schema.json',
    'contracts/schemas/action-envelope.schema.json',
    'contracts/schemas/ledger-event.schema.json',
]

errors = []
for rel in REQUIRED:
    p = ROOT / rel
    if not p.exists(): errors.append(f'Missing required file: {rel}')
    elif p.stat().st_size == 0: errors.append(f'Empty required file: {rel}')

for p in (ROOT / 'contracts').rglob('*.json'):
    try:
        json.loads(p.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'Invalid JSON {p.relative_to(ROOT)}: {exc}')

for p in ROOT.rglob('*.md'):
    text = p.read_text(encoding='utf-8')
    if '\x00' in text:
        errors.append(f'NUL byte in {p.relative_to(ROOT)}')

if errors:
    print('\n'.join(f'ERROR: {e}' for e in errors))
    sys.exit(1)
print(f'PASS: validated {len(list(ROOT.rglob("*.md")))} Markdown files and JSON contracts.')
