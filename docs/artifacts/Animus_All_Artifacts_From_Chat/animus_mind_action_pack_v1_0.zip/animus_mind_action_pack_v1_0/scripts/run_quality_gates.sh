#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python scripts/generate_index.py
python scripts/validate_pack.py
# Boundary scan returns 2 for review items. The package includes example email-pattern guidance,
# so run it visibly but do not make it a hard failure until repository-specific allowlists exist.
python scripts/scan_public_private.py --root . || status=$?
if [[ "${status:-0}" -ne 0 ]]; then
  echo "NOTICE: boundary scan returned review items; inspect before public release."
fi
echo "Quality gates complete."
