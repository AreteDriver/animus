#!/usr/bin/env python3
"""Conservative public/private boundary scan. Does not print matched secret values."""
from pathlib import Path
import argparse, re, sys

parser = argparse.ArgumentParser()
parser.add_argument('--root', default='.')
args = parser.parse_args()
root = Path(args.root).resolve()

skip_dirs = {'.git', '.venv', 'venv', 'node_modules', '__pycache__'}
patterns = {
    'private-key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'aws-access-key': re.compile(r'AKIA[0-9A-Z]{16}'),
    'generic-secret-assignment': re.compile(r'(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*["\'][^"\']{8,}["\']'),
    'email-address': re.compile(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b', re.I),
}

findings = []
for p in root.rglob('*'):
    if not p.is_file() or any(part in skip_dirs for part in p.parts):
        continue
    if p.suffix.lower() not in {'.md','.py','.json','.yaml','.yml','.toml','.txt','.sh'}:
        continue
    try:
        text = p.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        continue
    for label, pattern in patterns.items():
        if pattern.search(text):
            # Expected placeholders and documentation email examples are still reported for review.
            findings.append((str(p.relative_to(root)), label))

if findings:
    for path, label in findings:
        print(f'REVIEW: {label} pattern in {path}')
    print('Boundary scan found review items. Inspect without copying sensitive values into reports.')
    sys.exit(2)
print('PASS: no configured public/private patterns found.')
