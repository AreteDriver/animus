#!/usr/bin/env python3
"""Create a vertical-slice workspace from templates without overwriting existing work."""
from pathlib import Path
import argparse, re, shutil, sys

parser = argparse.ArgumentParser()
parser.add_argument('name')
parser.add_argument('--root', default='.')
args = parser.parse_args()
root = Path(args.root).resolve()
slug = re.sub(r'[^a-z0-9]+', '-', args.name.lower()).strip('-')
target = root / 'work' / 'vertical-slices' / slug
if target.exists():
    print(f'ERROR: target exists: {target}', file=sys.stderr)
    sys.exit(1)
target.mkdir(parents=True)
pack = Path(__file__).resolve().parents[1]
for source, dest in [
    (pack/'templates/vertical_slice_charter.md', target/'charter.md'),
    (pack/'templates/threat_scenario.md', target/'threat-model.md'),
    (pack/'templates/capability_acceptance.md', target/'acceptance.md'),
]:
    shutil.copy2(source, dest)
print(target)
