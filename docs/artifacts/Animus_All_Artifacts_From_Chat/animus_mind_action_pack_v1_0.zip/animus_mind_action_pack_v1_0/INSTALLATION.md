# Installation and Adoption

## Safe adoption

Install into a new branch or worktree. Do not overwrite an existing `CLAUDE.md`, `.claude/`, or architecture pack without review.

## Recommended copy set

Copy into each repository:

- root `CLAUDE.md` adjusted for that repository;
- `AGENTS.md`;
- `.claude/rules/`;
- `.claude/skills/`;
- `.claude/agents/`;
- `.claude/hooks/`;
- `scripts/`;
- relevant contracts and templates.

The public repository receives only synthetic examples. The private repository may reference owner-specific data but must not make it exportable by default.

## Dependencies

All bundled validation scripts use the Python standard library. Optional project integrations may require additional packages inside Animus itself.

## Validate this package

```bash
bash scripts/run_quality_gates.sh
```

## Start Claude Code

From the target repository root:

```bash
claude
```

Then run:

```text
/repo-recon
/vertical-slice evidence-backed project commitment tracker
```

## Hook adoption

Review `.claude/settings.example.json` before merging it into `.claude/settings.json`. Hooks are safeguards, but they must match the target repository’s paths and commands.
