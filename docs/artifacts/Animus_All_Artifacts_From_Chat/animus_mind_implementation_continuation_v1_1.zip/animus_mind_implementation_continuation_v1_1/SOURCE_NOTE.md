# Source Note

This continuation pack was prepared against the following supplied artifacts:

- Animus v2.1 Executable Baseline Package
- Animus v2.2 Implementation Roadmap and Engineering Guidelines
- Animus v2.2 roadmap YAML
- Animus Canonical Architecture v2 Reconciled
- Animus Mind Action Pack v1.0
- The Culture Mind: Daily Function, Tooling, and Human Assistance

The v2.1 package is treated as canonical. Other artifacts are implementation guidance or historical/conceptual sources unless separately adopted.
