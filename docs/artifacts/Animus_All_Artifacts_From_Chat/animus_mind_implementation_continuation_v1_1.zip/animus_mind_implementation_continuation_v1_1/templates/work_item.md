# Work Item: <title>

- Work ID:
- Phase:
- Requirement IDs:
- Objective:
- In scope:
- Out of scope:
- Contracts affected:
- Files expected:
- Tests required:
- Evidence required:
- Stop conditions:
- Completion decision:
