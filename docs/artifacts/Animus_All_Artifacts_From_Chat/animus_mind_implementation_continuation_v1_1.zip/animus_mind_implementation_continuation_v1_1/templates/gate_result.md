# Gate Result: <gate-id>

- Command:
- Started:
- Completed:
- Exit code:
- Result: pass | fail | error
- Requirement IDs:
- Output artifact:
- Environment:
- Commit:
- Notes:
