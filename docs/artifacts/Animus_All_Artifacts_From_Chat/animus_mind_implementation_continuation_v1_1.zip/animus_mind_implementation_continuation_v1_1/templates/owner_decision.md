# Owner Decision: <title>

- Decision ID:
- Date:
- Status: proposed | approved | rejected | superseded
- Authority basis:
- Decision:
- Alternatives:
- Affected requirements:
- Affected repositories:
- Security/privacy impact:
- Migration impact:
- Rollback/reversal:
- Evidence:
- Review date:
