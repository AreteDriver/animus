# Capability Promotion Decision

- Capability:
- Version:
- Current stage:
- Proposed stage:
- Critical gates:
- Open defects:
- Deviations:
- Authority scope:
- Data scope:
- Providers:
- Known limitations:
- Disable path:
- Rollback evidence:
- Decision: reject | correct | evaluation | shadow | limited | general
- Owner approval:
- Review date:
