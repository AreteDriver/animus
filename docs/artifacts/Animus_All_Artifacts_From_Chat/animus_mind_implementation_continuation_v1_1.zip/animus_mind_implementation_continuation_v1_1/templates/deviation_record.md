# Deviation: <title>

- Deviation ID:
- Requirement IDs:
- Severity:
- Reason:
- Scope:
- Compensating controls:
- Evidence:
- Owner approval required: yes/no
- Expiry:
- Resolution plan:
- Promotion impact:
