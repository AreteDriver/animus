#!/usr/bin/env python3
"""Assemble selected evidence files and generate a SHA-256 manifest."""
from pathlib import Path
import argparse, hashlib, json, shutil, datetime, sys
p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); p.add_argument('--capability',required=True); p.add_argument('--version',required=True); p.add_argument('--commit',default='unknown'); p.add_argument('files',nargs='+'); args=p.parse_args()
root=Path(args.root).resolve(); stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ'); bundle=root/'evidence'/f'{args.capability}-{args.version}-{stamp}'; bundle.mkdir(parents=True,exist_ok=False); artifacts=[]
for name in args.files:
    src=(root/name).resolve()
    if root not in src.parents or not src.is_file(): print(f'ERROR: invalid evidence file {name}',file=sys.stderr); sys.exit(1)
    rel=src.relative_to(root); dest=bundle/rel; dest.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(src,dest); data=dest.read_bytes()
    artifacts.append({'path':str(rel),'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data),'producer':'manual selection','requirement_ids':[],'evidence_type':'artifact','mock_derived':False})
manifest={'bundle_version':'1.0','capability':args.capability,'version':args.version,'commit':args.commit,'generated_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'artifacts':artifacts}
(bundle/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8'); print(bundle)
