#!/usr/bin/env python3
"""Validate starter requirement/gate traceability using JSON-compatible YAML files."""
from pathlib import Path
import argparse, json, re, sys, shlex

p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); args=p.parse_args()
root=Path(args.root).resolve()
errors=[]
def load(rel):
    try: return json.loads((root/rel).read_text(encoding='utf-8'))
    except Exception as exc: errors.append(f'{rel}: {exc}'); return {}
reqs=load('control/requirements.yaml').get('requirements',[])
gates=load('control/gates.yaml').get('gates',[])
req_ids=[x.get('id') for x in reqs]; gate_ids=[x.get('id') for x in gates]
for label,ids in [('requirement',req_ids),('gate',gate_ids)]:
    for i in sorted({x for x in ids if ids.count(x)>1}): errors.append(f'duplicate {label} id: {i}')
for r in reqs:
    if any('TBD' in str(v).upper() for v in r.values()): errors.append(f"TBD in requirement {r.get('id')}")
    if r.get('gate') not in gate_ids: errors.append(f"{r.get('id')} references missing gate {r.get('gate')}")
    if not r.get('authority'): errors.append(f"{r.get('id')} missing authority")
for g in gates:
    cmd=g.get('command','').strip()
    if not cmd: errors.append(f"{g.get('id')} missing command"); continue
    try: first=shlex.split(cmd)[0]
    except Exception: errors.append(f"{g.get('id')} command cannot be parsed"); continue
    if first in {'python','python3'}:
        parts=shlex.split(cmd)
        if len(parts)>1 and parts[1].endswith('.py') and not (root/parts[1]).exists():
            # Commands may target future implementation tests; scripts must exist now.
            errors.append(f"{g.get('id')} references missing script {parts[1]}")
if errors:
    print('\n'.join('ERROR: '+e for e in errors)); sys.exit(1)
print(f'PASS: {len(reqs)} requirements mapped to {len(gates)} gates')
