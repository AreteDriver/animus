#!/usr/bin/env python3
from pathlib import Path
root=Path(__file__).resolve().parents[1]; out=root/'generated'/'INDEX.md'; out.parent.mkdir(parents=True,exist_ok=True); lines=['# Package Index','']
for f in sorted(root.rglob('*')):
    if f.is_file() and f != out and '.git' not in f.parts: lines.append(f'- `{f.relative_to(root)}`')
out.write_text('\n'.join(lines)+'\n',encoding='utf-8'); print(out)
