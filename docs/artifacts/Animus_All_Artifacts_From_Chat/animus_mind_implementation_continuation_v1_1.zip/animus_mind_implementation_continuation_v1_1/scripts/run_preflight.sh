#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python scripts/generate_index.py
python scripts/validate_json_contracts.py --root .
python scripts/lint_traceability.py --root .
python scripts/build_traceability_matrix.py --root .
python scripts/check_authority_conflicts.py --root . || status=$?
if [[ "${status:-0}" -eq 2 ]]; then
  echo "NOTICE: authority scanner produced review items; inspect before adoption."
elif [[ "${status:-0}" -ne 0 ]]; then
  exit "${status}"
fi
python scripts/scan_public_boundary.py --root . || boundary=$?
if [[ "${boundary:-0}" -eq 2 ]]; then
  echo "NOTICE: boundary scanner produced review items; inspect before public release."
elif [[ "${boundary:-0}" -ne 0 ]]; then
  exit "${boundary}"
fi
python scripts/generate_checksums.py
echo "Preflight complete."
