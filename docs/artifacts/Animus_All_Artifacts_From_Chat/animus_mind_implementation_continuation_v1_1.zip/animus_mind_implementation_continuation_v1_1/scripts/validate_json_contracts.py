#!/usr/bin/env python3
"""Parse every JSON file and optionally validate schemas when jsonschema is installed."""
from pathlib import Path
import argparse, json, sys
p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); args=p.parse_args(); root=Path(args.root).resolve(); errors=[]; count=0
for f in root.rglob('*.json'):
    if '.git' in f.parts: continue
    try:
        obj=json.loads(f.read_text(encoding='utf-8')); count+=1
        if f.name.endswith('.schema.json'):
            try:
                import jsonschema
                jsonschema.Draft202012Validator.check_schema(obj)
            except ImportError: pass
    except Exception as exc: errors.append(f'{f.relative_to(root)}: {exc}')
if errors:
    print('\n'.join('ERROR: '+e for e in errors)); sys.exit(1)
print(f'PASS: parsed {count} JSON files')
