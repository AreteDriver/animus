#!/usr/bin/env python3
"""Conservative scan for statements that may conflict with the owner-sovereignty Charter."""
from pathlib import Path
import argparse, re, sys
p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); args=p.parse_args(); root=Path(args.root).resolve()
skip={'.git','.venv','venv','node_modules','__pycache__','evidence'}
patterns={
'replacement-sovereign':re.compile(r'(?i)animus\s+(?:is|becomes)\s+(?:a\s+)?(?:replacement\s+)?sovereign'),
'model-self-authority':re.compile(r'(?i)(model|agent).{0,40}(grant|expand|approve).{0,25}(its own|itself).{0,15}(permission|authority)'),
'silent-override':re.compile(r'(?i)(silently|without review).{0,35}(override|change).{0,25}(charter|policy|authority)')}
findings=[]
for f in root.rglob('*'):
    if not f.is_file() or any(x in skip for x in f.parts) or f.suffix.lower() not in {'.md','.txt','.yaml','.yml','.json','.py'}: continue
    if f.resolve() == Path(__file__).resolve(): continue
    text=f.read_text(encoding='utf-8',errors='ignore')
    for line_no,line_text in enumerate(text.splitlines(),1):
        # Prohibitions describing forbidden behavior are safe documentation, not endorsements.
        if re.search(r'(?i)\b(cannot|can not|may not|must not|never|prohibit(?:ed|s)?)\b', line_text):
            continue
        for name,pat in patterns.items():
            if pat.search(line_text): findings.append((str(f.relative_to(root)),line_no,name))
if findings:
    for item in findings: print(f'REVIEW: {item[2]} at {item[0]}:{item[1]}')
    sys.exit(2)
print('PASS: no configured authority-conflict phrases found')
