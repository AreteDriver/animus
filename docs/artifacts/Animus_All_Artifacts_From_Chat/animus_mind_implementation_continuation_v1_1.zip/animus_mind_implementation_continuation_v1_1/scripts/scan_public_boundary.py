#!/usr/bin/env python3
"""Scan public repository candidates without printing matched secret values."""
from pathlib import Path
import argparse, re, sys
p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); args=p.parse_args(); root=Path(args.root).resolve()
skip={'.git','.venv','venv','node_modules','__pycache__'}
patterns={
'private-key':re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
'aws-key':re.compile(r'AKIA[0-9A-Z]{16}'),
'secret-assignment':re.compile(r'(?i)(api[_-]?key|secret|token|password)\s*[:=]\s*["\'][^"\']{8,}["\']'),
'email':re.compile(r'\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b',re.I),
'home-path':re.compile(r'/(?:home|Users)/[^/\s]+/')}
findings=[]
for f in root.rglob('*'):
    if not f.is_file() or any(x in skip for x in f.parts) or f.suffix.lower() not in {'.md','.txt','.json','.yaml','.yml','.py','.sh','.toml','.csv'}: continue
    text=f.read_text(encoding='utf-8',errors='ignore')
    for name,pat in patterns.items():
        if pat.search(text): findings.append((str(f.relative_to(root)),name))
if findings:
    for path,name in findings: print(f'REVIEW: {name} pattern in {path}')
    sys.exit(2)
print('PASS: no configured public-boundary patterns found')
