#!/usr/bin/env python3
"""Generate Markdown and CSV traceability views."""
from pathlib import Path
import argparse, json, csv
p=argparse.ArgumentParser(); p.add_argument('--root',default='.'); args=p.parse_args(); root=Path(args.root).resolve()
reqs=json.loads((root/'control/requirements.yaml').read_text())['requirements']
gates={g['id']:g for g in json.loads((root/'control/gates.yaml').read_text())['gates']}
out=root/'generated'; out.mkdir(exist_ok=True)
rows=[]
for r in reqs:
    g=gates.get(r['gate'],{})
    rows.append([r['id'],r['authority'],r['severity'],r['gate'],g.get('command','MISSING'),g.get('evidence','MISSING'),r['text']])
with (out/'traceability.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['requirement','authority','severity','gate','command','evidence','text']); w.writerows(rows)
md=['# Traceability Matrix','', '| Requirement | Authority | Severity | Gate | Command | Evidence |','|---|---|---|---|---|---|']
for r in rows:
    vals=[str(x).replace('|','\\|') for x in r[:6]]; md.append('| '+' | '.join(vals)+' |')
(out/'traceability.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(out/'traceability.md'); print(out/'traceability.csv')
