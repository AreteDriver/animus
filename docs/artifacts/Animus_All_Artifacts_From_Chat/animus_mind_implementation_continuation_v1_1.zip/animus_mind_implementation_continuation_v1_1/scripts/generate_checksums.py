#!/usr/bin/env python3
from pathlib import Path
import hashlib
root=Path(__file__).resolve().parents[1]; out=root/'CHECKSUMS.sha256'; lines=[]
for f in sorted(root.rglob('*')):
    if f.is_file() and f != out and '.git' not in f.parts:
        lines.append(f"{hashlib.sha256(f.read_bytes()).hexdigest()}  {f.relative_to(root)}")
out.write_text('\n'.join(lines)+'\n',encoding='utf-8'); print(out)
