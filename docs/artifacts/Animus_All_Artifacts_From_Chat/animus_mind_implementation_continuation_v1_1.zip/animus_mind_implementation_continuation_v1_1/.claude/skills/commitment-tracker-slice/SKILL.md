# Skill: commitment-tracker-slice

## Purpose

Build or review the second personal slice.

## Procedure

1. Use synthetic input.
2. Create sourced commitment claim.
3. Detect conflict.
4. Prepare internal reminder.
5. Test injection and deletion.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
