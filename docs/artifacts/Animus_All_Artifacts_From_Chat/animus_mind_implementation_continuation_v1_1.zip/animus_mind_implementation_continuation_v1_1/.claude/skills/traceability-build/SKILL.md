# Skill: traceability-build

## Purpose

Build and validate the Phase 0 requirement map.

## Procedure

1. Normalize stable IDs.
2. Map contracts, tests, gates, evidence.
3. Run seeded-defect linter.
4. Assemble Phase 0 evidence.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
