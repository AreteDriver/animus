# Skill: evidence-bundle

## Purpose

Assemble and verify release evidence.

## Procedure

1. Collect required artifacts.
2. Hash and manifest.
3. Check traceability.
4. Label mocks.
5. Report missing evidence.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
