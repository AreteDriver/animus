# Skill: architecture-corpus-slice

## Purpose

Build or review the canonical first slice.

## Procedure

1. Register sources.
2. Extract anchored claims.
3. Detect contradictions.
4. Run bounded agents.
5. Approve and commit memory.
6. Replay and recover.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
