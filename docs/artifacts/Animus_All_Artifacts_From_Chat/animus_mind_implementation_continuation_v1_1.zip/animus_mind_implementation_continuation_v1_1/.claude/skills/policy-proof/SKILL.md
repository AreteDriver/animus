# Skill: policy-proof

## Purpose

Prove policy and approval enforcement.

## Procedure

1. Test grants and delegation.
2. Test approval binding.
3. Test revocation and kill switch.
4. Verify external enforcement.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
