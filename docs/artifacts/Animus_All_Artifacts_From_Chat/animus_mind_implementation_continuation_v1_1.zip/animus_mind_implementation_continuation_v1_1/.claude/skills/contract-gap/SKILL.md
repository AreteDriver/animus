# Skill: contract-gap

## Purpose

Close one contract gap safely.

## Procedure

1. Identify authority.
2. Map overlap.
3. Draft schema and semantics.
4. Add fixtures and compatibility.
5. Update traceability.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
