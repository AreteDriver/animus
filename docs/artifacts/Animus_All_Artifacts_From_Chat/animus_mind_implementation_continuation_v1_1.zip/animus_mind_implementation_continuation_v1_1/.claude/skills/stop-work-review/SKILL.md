# Skill: stop-work-review

## Purpose

Determine whether work must stop.

## Procedure

1. Check Charter conflict.
2. Check authority/data expansion.
3. Check critical invariants.
4. Escalate reserved decisions.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
