# Skill: promotion-review

## Purpose

Review a capability for stage promotion.

## Procedure

1. Verify critical gates.
2. Inspect deviations.
3. Test disable and rollback.
4. Check owner-readable limits.
5. Recommend stage only.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
