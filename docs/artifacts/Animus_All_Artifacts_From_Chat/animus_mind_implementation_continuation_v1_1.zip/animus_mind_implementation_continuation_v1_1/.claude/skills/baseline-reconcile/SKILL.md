# Skill: baseline-reconcile

## Purpose

Reconcile the repository against v2.1 authority and v2.2 proposals.

## Procedure

1. Inventory sources and status.
2. Detect conflicts and duplicate canon.
3. List owner-reserved decisions.
4. Produce a no-edit report.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
