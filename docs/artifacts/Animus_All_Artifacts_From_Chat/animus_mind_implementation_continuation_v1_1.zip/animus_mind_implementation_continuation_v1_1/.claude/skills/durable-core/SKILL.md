# Skill: durable-core

## Purpose

Implement and prove one durable-core increment.

## Procedure

1. Define transaction.
2. Implement idempotency.
3. Inject faults.
4. Rebuild projections.
5. Capture evidence.

## Output

A concise report with requirement IDs, files, commands, evidence paths, failures, and owner decisions.
