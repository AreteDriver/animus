# Animus Mind Implementation Continuation Pack

**Version:** 1.1  
**Date:** 2026-06-17  
**Status:** Proposed implementation package subordinate to the Animus v2.1 Executable Baseline  
**Audience:** Arete, Claude Code, engineering collaborators, reviewers

## Purpose

This pack continues the Animus Mind Action Pack by converting its broad design requirements into a controlled implementation sequence aligned with:

1. the canonical **Animus v2.1 Executable Baseline**;
2. the proposed **Animus v2.2 Implementation Roadmap**;
3. the **Animus Mind Action Pack v1.0**;
4. the Culture Mind guide as non-normative design inspiration.

It is built for immediate use by the owner and Claude. It supplies reconciliation decisions, phase plans, acceptance tests, owner prompts, Claude prompts, agent skills, templates, registries, and scripts.

## Critical authority rule

The v2.1 Mind Charter and Executable Baseline remain authoritative. The Culture concept does not make Animus a sovereign replacement for the owner. Animus is a governed personal intelligence that increases the owner's agency while remaining inspectable, bounded, correctable, exportable, deletable, and stoppable.

## Correct implementation sequence

1. Reconcile repositories and authority.
2. Complete v2.2 Phase 0 traceability.
3. Close missing contracts in Phase 1.
4. Implement the deterministic durable core in Phase 2.
5. Complete the canonical architecture-corpus vertical slice.
6. Only then build the evidence-backed commitment tracker as the first personal application slice.
7. Defer broad autonomy, external communications, health action, finance, legal execution, and physical-world control.

## Start here

Read in this order:

1. `START_HERE.md`
2. `docs/00_authority_and_reconciliation_report.md`
3. `docs/01_owner_decision_register.md`
4. `docs/04_phase_0_traceability_execution_plan.md`
5. `docs/05_phase_1_contract_closure_plan.md`
6. `docs/06_phase_2_durable_core_build_plan.md`
7. `docs/07_architecture_corpus_vertical_slice_build_spec.md`
8. `docs/08_commitment_tracker_second_slice_spec.md`
9. `prompts/owner/01_initialize_program.md`

## Package map

- `docs/` — reconciled implementation documentation
- `prompts/owner/` — prompts Arete can paste into Claude Code
- `prompts/claude/` — task prompts for specialized Claude workers
- `.claude/agents/` — focused subagent definitions
- `.claude/skills/` — repeatable Claude Code workflows
- `control/` — requirements, gates, decisions, deviations, and work items
- `contracts/` — additional implementation-control schemas
- `scripts/` — preflight, traceability, evidence, and authority checks
- `templates/` — records used during implementation and review

## Merge policy

Do not copy this package wholesale into the canonical repository. Use the reconciliation workflow, adopt only approved files, and record every normative change through an ADR or owner-approved decision. Proposed schemas that overlap v2.1 objects must be mapped or rejected rather than added as competing canon.
