# Traceability Matrix

| Requirement | Authority | Severity | Gate | Command | Evidence |
|---|---|---|---|---|---|
| CH-001 | Mind Charter §2 | critical | GATE-AUTH-001 | python scripts/check_authority_conflicts.py --root . | evidence/gates/GATE-AUTH-001.txt |
| CH-002 | Mind Charter §3 | critical | GATE-ACT-001 | pytest -q tests/actions/test_r3_r4_approval.py | evidence/gates/GATE-ACT-001.txt |
| CH-003 | Mind Charter §4 | critical | GATE-TRACE-001 | pytest -q tests/observability/test_trace_completeness.py | evidence/gates/GATE-TRACE-001.txt |
| CH-004 | Mind Charter §6 | critical | GATE-AUTH-002 | pytest -q tests/policy/test_no_self_grant.py | evidence/gates/GATE-AUTH-002.txt |
| CH-005 | Mind Charter §8 | critical | GATE-SEC-001 | pytest -q tests/security/test_secret_context.py | evidence/gates/GATE-SEC-001.txt |
| BASE-001 | Baseline invariant 1 | critical | GATE-SCHEMA-001 | python scripts/validate_json_contracts.py --root . | evidence/gates/GATE-SCHEMA-001.txt |
| BASE-002 | Baseline invariant 2 | critical | GATE-TXN-001 | pytest -q tests/durable_core/test_atomic_write_faults.py | evidence/gates/GATE-TXN-001.txt |
| BASE-003 | Baseline invariant 3 | critical | GATE-TRACE-001 | pytest -q tests/observability/test_trace_completeness.py | evidence/gates/GATE-TRACE-001.txt |
| BASE-004 | Baseline invariant 4 | critical | GATE-ACT-001 | pytest -q tests/actions/test_r3_r4_approval.py | evidence/gates/GATE-ACT-001.txt |
| BASE-005 | Baseline invariant 6 | critical | GATE-CANON-001 | pytest -q tests/canonical/test_generated_view_rejection.py | evidence/gates/GATE-CANON-001.txt |
| BASE-006 | Baseline invariant 7 | critical | GATE-RET-004 | pytest -q tests/retrieval/test_contradiction_coverage.py | evidence/gates/GATE-RET-004.txt |
| BASE-007 | Baseline invariant 8 | critical | GATE-TIME-001 | pytest -q tests/temporal/test_bitemporal_invariants.py | evidence/gates/GATE-TIME-001.txt |
| BASE-008 | Baseline invariant 10 | critical | GATE-REL-001 | python scripts/lint_traceability.py --root . | evidence/gates/GATE-REL-001.txt |
| BASE-009 | Baseline invariant 11 | critical | GATE-DEL-001 | pytest -q tests/deletion/test_no_resurrection.py | evidence/gates/GATE-DEL-001.txt |
| MEM-001 | Baseline §7 | critical | GATE-MEM-004 | pytest -q tests/memory/test_candidate_admission.py | evidence/gates/GATE-MEM-004.txt |
| AG-001 | Baseline §8 | critical | GATE-AG-005 | pytest -q tests/agents/test_delegation_bounds.py | evidence/gates/GATE-AG-005.txt |
| ACT-001 | Baseline §10 | critical | GATE-ACT-003 | pytest -q tests/actions/test_denied_call_receipt.py | evidence/gates/GATE-ACT-003.txt |
| REC-001 | Baseline §13 | critical | GATE-REC-002 | pytest -q tests/recovery/test_projection_rebuild.py | evidence/gates/GATE-REC-002.txt |
| REL-001 | v2.2 roadmap | critical | GATE-REL-001 | python scripts/lint_traceability.py --root . | evidence/gates/GATE-REL-001.txt |
| BOUND-001 | Owner-approved repository split | critical | GATE-BOUND-001 | python scripts/scan_public_boundary.py --root . | evidence/gates/GATE-BOUND-001.txt |
