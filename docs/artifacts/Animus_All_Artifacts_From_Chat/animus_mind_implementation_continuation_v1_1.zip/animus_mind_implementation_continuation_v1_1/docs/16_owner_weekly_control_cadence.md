# Owner Weekly Control Cadence

## Monday — Select one outcome

Choose one bounded trust loop. Reject plans framed as “build memory, agents, and dashboards.”

## Midweek — Evidence review

Ask for:

- current requirement coverage;
- failing gates;
- new contract decisions;
- deviations;
- security findings;
- actual test output;
- next irreversible choice.

## End of week — Acceptance or rejection

Accept only when:

- the intended contract is explicit;
- the implementation matches it;
- negative and fault tests pass;
- the evidence bundle is complete;
- private data boundaries hold;
- disable and rollback paths are demonstrated;
- known limitations are honest.

## Owner questions

- What can this now do that it could not do last week?
- What new data can it see?
- What new action can it take?
- What happens when it is wrong?
- What proves the result?
- What did we defer?
- Did any technology enter without a measured requirement?
- Does this increase my capability or encourage dependence?

## Weekly artifact

Create one signed or owner-approved weekly decision record containing:

- accepted capabilities;
- rejected claims;
- changed authority;
- open defects;
- next work item;
- stop-work conditions;
- review date.
