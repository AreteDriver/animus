# Deferred Capabilities Register

These capabilities are intentionally deferred until lower-level controls are operationally proven.

| Capability | Reason deferred | Prerequisite |
|---|---|---|
| Unrestricted email sending | Impersonation and reputation risk | R3 approval, receipts, verification, kill switch |
| Calendar modification | External state and scheduling consequences | Second-slice read-only success plus exact approval binding |
| Financial transactions | Irreversibility and fraud risk | Specialized policy, hardware-backed approval, transaction limits |
| Medical treatment recommendations | High-stakes harm | Professional oversight, medical policy, validated evidence protocols |
| Legal filing | Binding external consequence | Legal review workflow and exact artifact approval |
| Browser/computer control | Broad ambient authority | Sandboxing, target allowlists, session recording, compensation |
| Broad sensor ingestion | Privacy and surveillance risk | Sensor registry, consent, retention, local processing |
| Autonomous Swarm execution | Compounding authority and error | Agent contracts, delegation bounds, kill switches, trace gates |
| Self-modifying policy | Circular authorization | Prohibited without owner-controlled amendment workflow |
| Graph database | Synchronization and operational cost | Proven relational query shortfall |
| Large cloud data lake | Complexity before data need | Stable ingestion, governance, and analytical workload |
| Fine-tuning on personal data | Privacy, correction, deletion difficulty | Mature dataset governance and unlearning/retirement plan |

Deferral is an architecture decision, not a lack of ambition. It protects the path to greater capability.
