# Claude Execution Workflow

## Operating mode

Claude is an implementation collaborator, not an architecture authority. It may inventory, propose, implement bounded approved tasks, test, and document. It may not expand authority, change canon, or declare promotion.

## Required loop

1. Read authority files.
2. State task scope and exclusions.
3. Identify requirement IDs.
4. Inspect existing implementation before proposing new components.
5. Produce a change plan.
6. Ask for owner approval only when the change crosses a reserved decision.
7. Implement the smallest coherent change.
8. Run tests and capture evidence.
9. Perform adversarial self-review using a separate critic context.
10. Update traceability and known limitations.
11. Stop rather than paper over failed gates.

## Context-loss recovery

At the start of each new session Claude should read:

- current Charter and baseline;
- branch status;
- open work item;
- owner decisions;
- deviation register;
- last evidence manifest;
- failing gates.

Then it should restate only the operative constraints and proposed next command.

## Prohibited shortcuts

- creating a second schema because mapping is inconvenient;
- changing a gate threshold to make a build pass;
- using private data to improve public tests;
- mocking the exact property under test;
- treating model agreement as evidence independence;
- skipping migration or rollback;
- adding infrastructure before contracts;
- presenting documentation as proof of implementation.
