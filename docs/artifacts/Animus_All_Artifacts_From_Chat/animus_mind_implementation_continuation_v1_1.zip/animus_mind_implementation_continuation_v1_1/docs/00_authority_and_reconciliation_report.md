# Authority and Reconciliation Report

## 1. Authority order

The implementation must use this order:

1. `Animus v2.1/docs/00_Mind_Charter_v1.md`
2. `Animus v2.1/docs/01_Executable_Baseline_Specification.md`
3. v2.1 schemas, policies, registries, accepted ADRs, SLOs, and recovery requirements
4. owner-approved v2.2 implementation specifications
5. the Mind Action Pack and this continuation pack as proposed extensions
6. the Culture Mind guide as conceptual inspiration only

A lower item may clarify or extend a higher item but may not silently override it.

## 2. Reconciled identity of Animus

Animus is not a sovereign artificial citizen and is not a replacement moral authority. It is a governed, persistent personal intelligence for one sovereign human owner. It may disagree, challenge, abstain, and refuse prohibited behavior, but its operating authority derives from the Charter, owner-approved policy, law, and safety controls.

This preserves the useful Culture-inspired properties—long-term context, anticipation, stewardship, restraint, and developmental assistance—without importing fictional political status into a real system.

## 3. Major alignments

| Proposal | v2.1 alignment | Decision |
|---|---|---|
| Persistent context | Core system definition | Adopt through canonical objects and Context Envelopes |
| World model | Source/claim/intelligence chain | Extend through approved schemas, not a parallel memory store |
| PostgreSQL durable core | Relational durable-core-first ADR | Adopt as default unless existing implementation proves equivalent |
| Policy outside the model | Charter and tool-security ADR | Mandatory |
| Explicit provenance | Architectural invariant | Mandatory |
| Reversible actions and compensation | Reliability and action controls | Adopt |
| OpenTelemetry-style tracing | Trace requirements | Adopt implementation technology only after technology admission |
| Event backbone | Transactional outbox requirement | Defer broker choice until durable core exists |
| Durable workflows | Resumable workflow requirement | Defer engine choice until workflow requirements are measured |

## 4. Conflicts resolved

### AI sovereignty

The Culture guide describes a sovereign artificial person. Animus v2.1 explicitly says Animus is not a replacement sovereign. The v2.1 rule governs.

### First vertical slice

The v2.1 baseline requires architecture-corpus reconciliation as the first admitted capability. The v1.0 Mind Action Pack recommends a commitment tracker. The correct sequence is:

1. architecture-corpus vertical slice;
2. evidence-backed commitment tracker as the first personal application slice.

### Duplicate contracts

The action pack introduces source, evidence, claim, ledger-event, and action-envelope schemas. v2.1 already defines source, claim, action, approval receipt, action receipt, trace, and other objects. The action-pack schemas are design references, not new canon. Phase 1 must map each field into v2.1 or justify an ADR for a new object.

### Forge terminology

If `Forge` is retained, it must be an implementation name for the governed orchestration/action boundary. It may not bypass the MCP gateway, policy enforcement point, approval lifecycle, receipts, or trace requirements. Core-to-Swarm separation remains a project constraint only where it does not contradict the canonical plane/module model.

## 5. Required adoption decisions

The owner must explicitly approve:

- repository paths and branch strategy;
- whether Forge remains a named module;
- implementation language and database version;
- private-application workspace boundaries;
- default approval mode;
- initial data-retention values;
- local-only classifications;
- first external provider, if any;
- technology-admission thresholds for broker, workflow engine, graph database, and vector index.

## 6. Non-negotiable implementation principles

- No duplicate canon.
- No authority inferred from model output.
- No consequential action without enforceable policy and receipt.
- No memory promotion without candidate workflow.
- No sensitive fixture in the public kernel.
- No promotion without retained evidence.
- No broad autonomy before control surfaces and kill switches.
