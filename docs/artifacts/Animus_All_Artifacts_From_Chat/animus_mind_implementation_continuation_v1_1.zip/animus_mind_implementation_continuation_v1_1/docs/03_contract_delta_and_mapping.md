# Contract Delta and Mapping

## Purpose

Prevent proposed Mind Action Pack contracts from becoming duplicate canonical objects.

## Mapping table

| Action-pack concept | Existing v2.1 object or mechanism | Required treatment |
|---|---|---|
| Source | `source.schema.json` | Extend only through compatible versioning |
| Evidence | Source anchors, observations, derivation, trace | Decide whether evidence is a canonical object or structured relation |
| Claim | `claim.schema.json` | Map fields; preserve bitemporal and epistemic coordinates |
| Ledger event | Planned v2.2 durable-core contract | Define one canonical event contract in Phase 1 |
| Action envelope | Action + approval receipt + policy decision + action receipt + trace | Prefer composed runtime view unless a new canonical object is justified |
| Personal world entity | `entity.schema.json` | Extend entity types and relation model through approved schema changes |
| Commitment | Claim/event/decision or new subtype | First model as typed claim plus valid-time; add object only after measured insufficiency |
| Intervention | Decision plus proposed action | Keep as policy-governed proposal, not a hidden behavior class |
| Memory category | `memory_candidate` plus accepted canonical object | Do not create independent memory tables per psychology label |
| Authority level | Risk class + capability grant + policy decision | Use v2.1 R0–R4 and capability model |

## Phase 1 decisions required

1. Determine whether `evidence` is a first-class object or a relation over source anchors and derivation edges.
2. Define the canonical ledger event contract.
3. Define versioned object record and projection contracts.
4. Define the policy input/decision/obligation contracts.
5. Define capability grants and delegation rules.
6. Define retrieval request/result/omission/ranking explanation.
7. Define deletion, export, backup, restore, incident, gate, and evaluation records.
8. Define semantic validators for cross-object invariants.

## Compatibility rule

A new contract is admitted only when:

- no current contract can express the requirement without semantic distortion;
- the authority source is named;
- migration is defined;
- positive, negative, and semantic-invalid fixtures exist;
- old readers and writers have an explicit compatibility result;
- the owner approves consequential ontology changes.
