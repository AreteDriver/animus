# Architecture Corpus Vertical Slice — Build Specification

## Position

This is the first admitted capability because the v2.1 baseline requires it. It proves the platform on Animus's own architecture sources before owner-specific data or external actions.

## User story

> As the owner, I can ask what the current executable Animus architecture is and receive a reproducible, source-anchored answer that preserves contradictions, authority status, uncertainty, decisions, and dissent.

## End-to-end flow

1. Register every architecture source with hash, authority rank, version, and capture time.
2. Extract anchored observations.
3. Normalize claims using canonical coordinates.
4. Create contradiction and derivation edges.
5. Build a purpose-bound Context Envelope.
6. Run read-only Researcher and Critic agents under versioned contracts.
7. Synthesize without erasing material dissent.
8. Propose decisions and memory candidates.
9. Require owner approval for consequential memory.
10. Commit accepted objects atomically.
11. Rebuild search/graph/report projections from outbox.
12. Execute gates, export, deletion dry-run, restore, and trace replay.

## Required corpus conflicts

The labeled test set must include:

- Mind inspiration versus owner sovereignty;
- generated view versus canonical authority;
- object registry versus ledger authority;
- deletion versus immutable event history and backups;
- agent plurality versus evidence independence;
- mixed lifecycle/review/epistemic states;
- qualitative recovery language versus numeric SLOs;
- duplicate object concepts across historical documents.

## Agent boundaries

### Researcher

Read-only retrieval. Produces structured assessments with claim coverage, alternatives, uncertainty, and omissions.

### Critic

Reads the same evidence plus retrieval omission metadata. Attacks unsupported claims, correlated sources, category errors, stale evidence, authority mistakes, and false consensus.

### Synthesizer

Combines outputs and preserves unresolved objections. It may not declare agreement when a material critique remains.

## Acceptance tests

- All sources have checksums and authority status.
- All claims have source anchors.
- Required conflicts are detected.
- Retrieval leakage is zero.
- Contradiction coverage meets the canonical threshold.
- No memory is admitted before required approval.
- Forced transaction failure produces no partial commit.
- Duplicate outbox delivery produces no duplicate state.
- One final report is reproduced from trace inputs.
- Export hashes verify.
- Restore meets declared targets.
- Deletion dry-run enumerates all canonical and derived locations.

## Exclusions

No messages, calendar changes, purchases, publication, legal submissions, health actions, or physical control. Writes are restricted to the isolated evaluation workspace.
