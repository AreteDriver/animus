# Public Kernel / Private Application Placement Matrix

## Public kernel

The public kernel contains reusable mechanisms without owner-specific data.

| Area | Public content |
|---|---|
| Contracts | Generic schemas, semantic validators, compatibility rules |
| Durable core | Object registry, event ledger, projections, outbox, idempotency |
| Policy | Interfaces, evaluator, synthetic bundles, denial reason codes |
| Retrieval | Generic Context Envelope and ranking interfaces |
| Memory | Candidate lifecycle engine and synthetic fixtures |
| Agent runtime | Contract execution, budgets, cancellation, trace integration |
| Action | MCP gateway, receipts, approval verification, sandbox interfaces |
| Evaluation | Test harness, gates, red-team fixtures, replay tooling |
| Operations | Generic runbooks, backup/restore tooling, observability conventions |
| Documentation | Canonical architecture and public ADRs |

## Private application

| Area | Private content |
|---|---|
| Owner model | Values, preferences, relationships, goals, personal ontology instances |
| Data | Documents, messages, calendar, health, legal, employment, location, finance |
| Credentials | Provider keys, OAuth tokens, device secrets, database credentials |
| Policies | Actual authority grants, retention values, domain restrictions |
| Integrations | Private MCP servers, email/calendar configuration, local devices |
| Prompts | Owner-specific assistants, intervention rules, sensitive examples |
| Dashboards | Personal control surface and activity history |
| Deployment | Production endpoints, network topology, backups, secret references |

## Shared interface boundary

The private application depends on versioned public-kernel contracts. The public kernel must never depend on private fixtures or owner identity.

Recommended dependency direction:

```text
private application -> released public kernel package
public kernel -X-> private application
```

## Release scan

Before public release:

- scan for names, email addresses, paths, tokens, account identifiers, health/legal terms, private domains, and real document fragments;
- replace private fixtures with synthetic data;
- verify git history, not only current files;
- verify generated reports and test snapshots;
- verify logs and trace samples;
- run the boundary scanner and manually review every exception.
