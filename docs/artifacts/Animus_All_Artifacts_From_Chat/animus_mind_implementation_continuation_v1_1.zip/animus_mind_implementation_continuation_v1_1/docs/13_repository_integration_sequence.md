# Repository Integration Sequence

## Step 1 — Inventory

Claude produces a repository map without editing code:

- canonical documents;
- schemas and versions;
- migration system;
- policy engine status;
- database code;
- test framework;
- CI gates;
- public/private boundaries;
- unresolved branches and migrations.

## Step 2 — Create program-control branch

Recommended branch: `feat/v2.2-program-control`.

Only Phase 0 artifacts enter this branch initially. Do not mix durable-core implementation with authority reconciliation.

## Step 3 — Import selected controls

Adopt:

- requirement registry;
- gate registry;
- evidence manifest schema;
- decision/deviation templates;
- traceability scripts.

Do not yet import proposed runtime schemas from the action pack.

## Step 4 — Reconcile contract gaps

Create one report per contract family. Every proposed schema must state whether it extends, replaces, composes, or rejects an existing v2.1 object.

## Step 5 — Implement Phase 2 on a separate branch

Recommended branch: `feat/v2.2-durable-core` after Phase 1 acceptance.

## Step 6 — Private application integration

Only after a released public-kernel version exists:

- pin the version;
- configure private workspace policies;
- add private connectors and deployment secrets;
- use synthetic data in public tests;
- run cross-repository compatibility and boundary scans.

## Pull-request rule

Every consequential PR must include:

- linked requirement IDs;
- contract changes;
- migration and rollback;
- positive, negative, adversarial, and fault tests as relevant;
- evidence artifact location;
- security and privacy impact;
- public/private review;
- known limitations.
