# Release and Promotion Playbook

## Stages

1. **Development** — incomplete, local, no reliance.
2. **Evaluation** — controlled tests and adversarial campaigns.
3. **Shadow** — observes real inputs but does not act or alter canonical state unless explicitly isolated.
4. **Limited** — narrow users, domains, data, and actions with intensive review.
5. **General** — approved stable use within declared boundaries.

## Promotion review

The reviewer must verify:

- all critical gates pass automatically;
- no unresolved critical defect;
- no unexplained divergence between contract, implementation, and trace;
- no private data in public artifacts;
- kill switch works without the agent runtime;
- rollback is tested;
- export and deletion behavior is verified;
- known limitations are owner-readable;
- authority scope is no broader than needed;
- the capability increases owner agency without hidden coercion.

## Automatic block conditions

- unauthorized R3/R4 action;
- workspace or classification leakage;
- secret in model context or telemetry;
- duplicate consequential side effect;
- critical trace gap;
- deletion resurrection;
- critical gate bypass;
- failed restore target;
- schema incompatibility without approved migration;
- unreviewed Charter or policy change.

## Owner promotion record

The owner records:

- capability and version;
- stage approved;
- domains and workspaces;
- action classes;
- provider routes;
- retention constraints;
- known limitations;
- monitoring plan;
- review date;
- emergency disable path.
