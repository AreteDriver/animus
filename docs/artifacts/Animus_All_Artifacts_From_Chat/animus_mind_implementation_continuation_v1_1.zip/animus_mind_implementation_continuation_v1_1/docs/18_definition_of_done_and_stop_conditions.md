# Definition of Done and Stop Conditions

## Definition of done

A capability is done only when:

- authority source is identified;
- contract is versioned;
- semantic rules are enforceable;
- implementation exists;
- positive and negative tests pass;
- adversarial and fault tests pass where relevant;
- telemetry and receipts exist;
- evidence is retained and hashed;
- migration and rollback are tested;
- private/public boundary is clean;
- owner-facing behavior is understandable;
- capability can be disabled;
- promotion stage is explicitly approved.

## Stop immediately

- Charter conflict.
- Hidden expansion of data access.
- Hidden expansion of action access.
- Secret enters model context.
- Cross-workspace leakage.
- Unapproved R3/R4 path.
- Duplicate side effect.
- Partial canonical transaction.
- Critical trace omission.
- Deleted data reappears.
- Test or gate is bypassed.
- Private fixture appears in public repository.

## Stop and seek a decision

- new canonical object is needed;
- retention must change;
- provider routing must change;
- recurring approval is proposed;
- owner identity or values are inferred;
- a new external integration is proposed;
- a technology introduces a new operational dependency;
- rollback is not straightforward;
- material dissent cannot be resolved.
