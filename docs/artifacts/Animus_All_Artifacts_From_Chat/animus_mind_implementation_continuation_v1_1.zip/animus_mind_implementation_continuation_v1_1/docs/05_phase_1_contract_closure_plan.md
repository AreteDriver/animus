# Phase 1 — Contract Closure

## Objective

Remove every place where implementation workers would otherwise invent consequential behavior.

## Contract families

### Durable core

- ledger event;
- versioned object record;
- current projection record;
- transactional outbox record;
- projection checkpoint;
- idempotency record;
- integrity-verification result.

### Source and retrieval

- source extraction record;
- immutable source anchor;
- contradiction edge;
- retrieval request and result;
- omission record;
- ranking explanation.

### Identity, policy, and security

- principal;
- session;
- capability grant;
- delegation request;
- policy input;
- policy decision;
- obligation;
- denial reason;
- provider definition;
- kill-switch state;
- revocation event.

### Agents and models

- agent contract;
- agent execution;
- budget state;
- model-call record;
- prompt-template version;
- cancellation result.

### Operations and owner control

- deletion job and receipt;
- tombstone;
- export manifest;
- backup receipt;
- restore report;
- evaluation result;
- gate result;
- workflow checkpoint;
- incident record.

## Semantic invariants

JSON Schema validates shape, not meaning. Implement deterministic semantic validators for:

- R3/R4 approval freshness, target, scope, and single-use status;
- delegation never exceeding parent capability;
- coherent valid-time and transaction-time intervals;
- monotonic object versions;
- generated views prohibited from direct canonical admission;
- consequential writes requiring provenance and integrity hashes;
- successful traces requiring completion, required spans, and outcome;
- deleted objects excluded from ordinary retrieval;
- forecasts obeying the selected probability model;
- memory workflow state agreeing with admission state;
- approval and action receipts referencing exact contract versions.

## State-machine requirement

Every stateful contract must include:

- allowed states;
- allowed transitions;
- required actor or authority;
- preconditions;
- emitted event;
- side effects;
- idempotency behavior;
- invalid-transition response.

Undefined transitions must fail closed.

## Review procedure

For each contract:

1. Identify authority source.
2. Compare existing schema.
3. Record gap.
4. Propose minimal change.
5. Add fixtures.
6. Add semantic tests.
7. Run compatibility check.
8. Update traceability.
9. Obtain owner approval when ontology, authority, retention, or personal interpretation is affected.

## Exit criteria

- Every runtime boundary is versioned.
- Every contract compiles.
- Positive and negative fixtures exist.
- Semantic-invalid fixtures are rejected.
- State machines have no undefined transitions.
- Breaking changes are blocked or explicitly approved.
- No duplicated canonical concept remains unresolved.
