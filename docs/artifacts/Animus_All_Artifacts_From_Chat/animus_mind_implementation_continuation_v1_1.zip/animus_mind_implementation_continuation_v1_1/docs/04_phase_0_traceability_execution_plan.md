# Phase 0 — Program Control and Traceability

## Objective

Create the machinery that proves every requirement has an implementation path, verification command, evidence artifact, owner decision status, and release consequence.

## Deliverables

1. Requirement registry with stable IDs.
2. Requirement-to-contract-to-test-to-gate-to-evidence matrix.
3. Executable gate registry.
4. Evidence manifest schema.
5. Decision and deviation registers.
6. Traceability linter.
7. Seeded-defect tests proving the linter fails correctly.
8. Phase 0 evidence bundle.

## Work sequence

### P0.1 Inventory authority

Record every canonical file, its version, status, checksum, and authority rank. Proposed packs must be marked non-canonical.

### P0.2 Normalize requirement IDs

Use prefixes:

- `CH-` Charter
- `BASE-` Executable baseline
- `SEC-` Security
- `RET-` Retrieval
- `MEM-` Memory
- `AG-` Agent runtime
- `ACT-` Action and MCP
- `OBS-` Observability
- `REC-` Recovery
- `OPS-` Operations
- `REL-` Release

Requirements should be atomic and testable. Split prose containing multiple obligations.

### P0.3 Map verification

Each critical requirement must map to:

- a contract or policy;
- an implementation component;
- at least one positive test;
- at least one relevant negative/adversarial test;
- a gate;
- an evidence output;
- an owner or engineering acceptance authority.

### P0.4 Register executable gates

A gate record must contain the exact command, expected exit behavior, output location, severity, blocking rule, and owner override policy. Critical gates cannot be overridden by an ordinary model or developer.

### P0.5 Prove the linter

Seed defects:

- requirement with no test;
- gate with no command;
- test ID referenced but absent;
- critical requirement mapped only to a manual claim;
- evidence path outside the bundle;
- unresolved deviation marked promoted.

The linter must fail for each defect and pass after correction.

## Exit criteria

- No `TBD` verification IDs.
- All critical gates have commands.
- All requirements have authority sources.
- Every critical requirement has negative or adversarial coverage where applicable.
- Seeded defects are detected.
- The owner reviews open deviations.

## Evidence

- `requirements.yaml`
- generated traceability matrix
- gate registry
- linter output
- seeded-defect report
- decision register
- deviation register
- checksums
