# Policy and Authority Profiles

## Risk classes

Use v2.1 R0–R4. Do not create a competing authority ladder.

| Class | Typical action | Initial rule |
|---|---|---|
| R0 | Read public non-sensitive data | Standing policy allowed |
| R1 | Read authorized private data | Workspace and classification grant required |
| R2 | Reversible internal write | Narrow standing policy, budget, idempotency, receipt |
| R3 | External or consequential write | Fresh scoped single-use approval |
| R4 | Irreversible, privileged, financial, legal, medical, identity, destructive | Disabled initially; fresh approval and specialized controls later |

## Initial profiles

### Documentation worker

- R0 public architecture files.
- R1 private repository metadata only where explicitly granted.
- R2 branch-local documentation edits.
- No R3/R4.

### Contract engineer

- Read canonical contracts.
- Propose schema changes and fixtures.
- Cannot mark a proposal canonical.
- Cannot modify the Charter.

### Evaluation worker

- Execute tests in isolated environments.
- Write evidence artifacts.
- Cannot modify gates to force a pass.

### Personal context reader

- Restricted to named workspace and purpose.
- No credentials.
- No cross-workspace retrieval.
- No durable memory write without candidate path.

### Action executor

- Disabled until gateway, approval, receipt, idempotency, kill switch, and trace gates pass.

## Approval binding

Approval must bind:

- principal;
- exact action type;
- target;
- parameters or bounded parameter range;
- workspace;
- purpose;
- issue time and expiry;
- preconditions;
- allowed attempts;
- contract and policy versions;
- whether it is single-use.

A human-readable “yes” in chat is not sufficient for an R3/R4 action unless converted into a valid approval receipt by the trusted control surface.
