# Phase 2 — Deterministic Durable Core

## Objective

Implement canonical authority and transactionality before adding model-driven behavior.

## Minimum database model

- owners;
- workspaces;
- principals;
- schema versions;
- canonical objects;
- object versions;
- current projections;
- ledger events;
- transactional outbox;
- idempotency records;
- approvals;
- action receipts;
- projection checkpoints;
- integrity verification results.

## Atomic write path

One transaction must:

1. validate the command and schema version;
2. verify principal, workspace, capability, and policy;
3. verify idempotency key;
4. lock the logical object when needed;
5. write immutable object version;
6. write ledger event;
7. update current projection;
8. write outbox entry;
9. write integrity metadata;
10. commit or roll back all records together.

No model, connector, or projection may write around this path.

## Worker behavior

Outbox workers must:

- claim work safely;
- tolerate duplicate delivery;
- produce deterministic projection keys;
- record attempts and final outcome;
- retry transient failures with bounded backoff;
- dead-letter poison records;
- support replay from checkpoint;
- never create duplicate external side effects.

## Required commands

- propose canonical object;
- accept or reject candidate;
- read current object;
- read historical version;
- list ledger events;
- rebuild projection;
- reconcile projection against canonical state;
- replay outbox range;
- verify object integrity;
- export workspace scope;
- enumerate deletion scope.

## Fault-injection campaign

Test:

- crash after object version but before ledger insert;
- crash after ledger insert but before projection update;
- crash after projection update but before outbox insert;
- transaction timeout;
- duplicate command submission;
- duplicate outbox delivery;
- worker crash after side effect but before receipt;
- stale object version write;
- corrupted integrity hash;
- projection deletion and full rebuild.

Every partial-write scenario must produce either a complete transaction or no transaction.

## Exit criteria

- Zero partial transactions under fault injection.
- Duplicate submission produces one canonical effect.
- Duplicate delivery produces no duplicate projection or side effect.
- All projections rebuild from canonical state.
- Integrity verification detects seeded corruption.
- Reconciliation reports deliberate divergence.
- Evidence bundle retains commands, logs, database checks, and checksums.
