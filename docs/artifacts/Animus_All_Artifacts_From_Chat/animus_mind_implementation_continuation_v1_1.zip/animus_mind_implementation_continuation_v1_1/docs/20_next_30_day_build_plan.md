# Next 30-Day Build Plan

## Week 1 — Reconciliation and traceability

- complete owner decisions;
- inventory repositories and canonical authority;
- build requirement registry;
- build gate-command registry;
- run traceability linter with seeded defects;
- produce Phase 0 evidence bundle.

## Week 2 — Contract-gap closure

- inventory all v2.1 schemas and planned v2.2 contracts;
- resolve action-pack duplicates;
- specify durable-core, policy, retrieval, agent, and operations contracts;
- add positive, negative, and semantic-invalid fixtures;
- produce compatibility report.

## Week 3 — Durable core foundation

- database migrations;
- atomic object/event/projection/outbox command;
- idempotency and replay;
- projection rebuild;
- fault-injection suite;
- integrity verification.

## Week 4 — Architecture-corpus slice foundation

- source registry and immutable anchors;
- claim and contradiction extraction pipeline;
- Context Envelope request/result;
- read-only Researcher and Critic contracts;
- first reproducible trace;
- evidence bundle draft.

## Explicitly not in this 30-day plan

- external sending;
- personal health or legal ingestion;
- financial integrations;
- broad agent swarm;
- physical sensors;
- graph database;
- workflow engine;
- event broker beyond the transactional outbox;
- fine-tuning.
