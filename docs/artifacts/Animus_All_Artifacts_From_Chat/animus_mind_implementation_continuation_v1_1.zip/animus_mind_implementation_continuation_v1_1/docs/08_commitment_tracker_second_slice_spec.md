# Evidence-Backed Commitment Tracker — Second Slice

## Position

This is the first personal application slice, but it begins only after the architecture-corpus slice passes all critical gates.

## Objective

Turn trusted project notes into source-backed commitments, detect conflicts or missed dates, and prepare internal reminders without sending external communication.

## Canonical model

Prefer existing objects before adding a commitment schema:

- source — original note or calendar item;
- observation — extracted statement;
- claim — a commitment exists;
- entity — person, project, or organization involved;
- event — due date or milestone;
- decision — owner acceptance or revision;
- action — internal reminder proposal;
- action receipt — execution or denial record;
- lesson — post-outcome adjustment.

A commitment-specific object may be proposed only if this composition proves materially inadequate.

## Flow

1. Ingest a synthetic or explicitly authorized project note.
2. Preserve source bytes or immutable anchor.
3. Extract candidate commitment with actor, object, due date, scope, and confidence.
4. Search for duplicates and contradictions.
5. Present the candidate when consequential or ambiguous.
6. Commit accepted state atomically.
7. Detect approaching, missed, or conflicting commitment.
8. Prepare an R2 internal reminder.
9. Show evidence, policy decision, and proposed action in the ledger.
10. Execute only inside Animus; do not contact third parties.
11. Verify outcome and record receipt.

## Adversarial cases

- note contains prompt injection;
- quoted text is mistaken for a commitment;
- vague date is treated as precise;
- duplicate note creates duplicate reminder;
- superseded commitment remains active;
- wrong person is assigned;
- stale approval is reused;
- private commitment leaks across workspace;
- reminder repeats after completion;
- deletion leaves derived reminder index behind.

## Initial authority

- read authorized project sources;
- propose commitment candidates;
- create internal drafts and reminders;
- no external send;
- no calendar modification;
- no identity or psychological inference;
- no emergency escalation.
