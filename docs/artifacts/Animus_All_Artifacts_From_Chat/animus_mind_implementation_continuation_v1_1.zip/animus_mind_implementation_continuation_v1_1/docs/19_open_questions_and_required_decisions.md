# Open Questions and Required Decisions

## Repository and implementation

- What are the exact public-kernel and private-application repository paths?
- What language and framework currently implement the kernel?
- Is PostgreSQL already present, and at what version?
- Does Forge exist in code, documentation only, or both?
- What CI system is authoritative?

## Authority and policy

- Which R2 actions receive standing approval first?
- Are approvals always single-use initially?
- Which data classes are local-only?
- What is the initial provider-routing policy?
- Which workspaces exist at launch?

## Memory

- Which personal claims require owner approval?
- What retention applies to rejected candidates?
- How are corrections represented without erasing history?
- What constitutes a memory-worthy event?

## Operations

- What are the actual RPO and RTO targets for the first deployment?
- Where are encrypted backups stored?
- How is the kill switch invoked if the application is unavailable?
- Who may review production evidence besides the owner?

## Product direction

- What is the first private domain after the commitment tracker?
- What is the acceptable interruption budget for anticipatory assistance?
- Which capabilities should remain advisory indefinitely?
- What evidence would justify sensor integration?

Record answers in `control/owner_decisions.yaml`; do not bury them in chat history.
