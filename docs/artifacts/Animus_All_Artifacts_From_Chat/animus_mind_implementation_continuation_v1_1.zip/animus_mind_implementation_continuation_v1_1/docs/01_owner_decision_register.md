# Owner Decision Register

Complete `control/owner_decisions.yaml` before implementation. Recommended defaults are intentionally conservative.

| Decision | Recommended default | Why it matters |
|---|---|---|
| Canonical public repository | Existing public kernel repository | Prevents a third architecture repository |
| Private repository | Existing private application repository | Keeps owner data and credentials outside public code |
| Integration branch | `feat/v2.2-program-control` | Isolates planning and traceability work |
| First slice | Architecture corpus | Required by v2.1 |
| Second slice | Commitment tracker | Low-risk personal application |
| Emergency authority | None | Avoids undefined exception paths |
| R3/R4 approval | Fresh, action-specific, single-use | Strongest practical owner control |
| R2 approval | Standing policy with strict scope and idempotency | Enables useful internal work safely |
| Default retention | Minimize; domain-specific | Avoids indefinite accumulation |
| Restricted data routing | Local only | Protects health, legal, identity, family, credentials |
| Personal memory inference | Candidate only; owner review for consequential claims | Prevents silent identity rewriting |
| Database | PostgreSQL | Matches relational durable-core direction |
| Vector index | Derived, rebuildable projection | Prevents embeddings becoming truth |
| Graph store | Deferred | No measured need yet |
| Event broker | Deferred until transactional outbox is working | Prevents infrastructure-first design |
| Workflow engine | Deferred until two resumable workflows exist | Avoids premature Temporal adoption |
| External sending | Disabled in initial releases | Limits impersonation and reputation risk |
| Health action | Information organization only | Avoids unsafe treatment decisions |
| Financial action | Read-only analysis only | Avoids money movement risk |
| Legal action | Draft/research only | Avoids unauthorized submissions |

## Decision quality rule

A decision is complete only when it records:

- the choice;
- alternatives considered;
- authority basis;
- affected repositories and contracts;
- migration consequence;
- security consequence;
- rollback or reversal path;
- review date.

## Decisions Claude must never make alone

- changing the Charter;
- accepting a new canonical object;
- expanding action authority;
- moving a data class from local-only to cloud-permitted;
- weakening approval freshness;
- accepting psychological or identity inferences as fact;
- enabling external communication;
- changing deletion or backup guarantees;
- promoting a capability to general use.
