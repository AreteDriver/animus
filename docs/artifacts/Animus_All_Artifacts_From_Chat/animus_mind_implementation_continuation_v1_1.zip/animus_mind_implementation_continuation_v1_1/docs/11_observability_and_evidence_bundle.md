# Observability and Release Evidence Bundle

## Trace model

Every consequential run must connect:

```text
owner intent
-> authenticated principal and session
-> purpose and Context Envelope
-> retrieved sources and omissions
-> model and prompt versions
-> agent plan and delegation
-> policy decisions and obligations
-> tool calls and receipts
-> canonical writes and outbox events
-> verification and outcome
-> evaluation and gate results
```

## Required trace properties

- globally unique trace ID;
- parent-child span relationships;
- timestamps and durations;
- component and version;
- data classification;
- redaction status;
- input references rather than unrestricted payload copies;
- model provider, model ID, prompt version, and token/cost record;
- policy bundle and decision ID;
- action and approval receipt IDs;
- canonical object and event IDs;
- error and retry state;
- final outcome.

## Release evidence bundle

Each promoted capability must include:

- source identity and checksums;
- build provenance;
- contract and policy manifests;
- migration and environment manifests;
- requirement coverage report;
- schema and semantic validation;
- integration and adversarial tests;
- fault-injection report;
- retrieval, memory, agent, and action evaluations;
- trace audit and replay report;
- export verification;
- deletion report;
- backup and restore report;
- SLO snapshot;
- deviations and waivers;
- promotion decision.

## Evidence integrity

- Generate hashes after artifacts are final.
- Store a manifest with relative path, size, hash, producer, and trace ID.
- Do not modify artifacts after signing or hashing.
- Mark evidence generated from mocks.
- Keep raw command output when it is needed to reproduce a claim.
- Never call a screenshot or narrative “proof” when executable output is required.
