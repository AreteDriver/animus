# Technology Adoption Sequence

## Adopt now

### PostgreSQL

Use for canonical objects, versions, ledger, approvals, receipts, outbox, idempotency, and policy-supporting state.

### Existing application language and test framework

Do not rewrite the stack merely to follow a new architecture document.

### JSON Schema plus semantic validators

Shape and meaning require separate enforcement.

### Repository-native CI

Make gates executable before adding additional orchestration platforms.

## Admit after measured need

### pgvector

Admit when semantic retrieval evaluation exists. It remains a derived projection.

### OpenTelemetry

Admit when trace schema and redaction rules are settled. Use it as implementation plumbing, not the canonical evidence model itself.

### NATS JetStream

Admit when outbox consumers, replay, and operational ownership justify a broker. PostgreSQL outbox is first.

### Temporal

Admit when at least two workflows require durable timers, retries, human approval waits, and compensation. Do not use it to avoid defining workflow state.

### Neo4j

Admit only when labeled multi-hop query benchmarks show the relational model is inadequate.

### Iceberg

Admit when the analytical data lake has multi-writer, schema-evolution, snapshot, and scale requirements.

### Home Assistant / MQTT

Admit only after sensor registry, consent, retention, physical-security, and kill-switch controls exist.

### A2A / SPIFFE

Admit when independently deployed agents or workloads require interoperable identity and secure communication.

## Technology admission evidence

Every adoption proposal must include:

- requirement IDs;
- benchmark or operational evidence;
- simpler alternatives;
- failure modes;
- security boundary;
- data classification impact;
- recovery and export behavior;
- lock-in and replacement path;
- total operational cost;
- exit criteria if the experiment fails.
