# Start Here

## The immediate objective

Do not attempt to build the full personal Mind. Build the smallest trustworthy substrate that can later support it.

The next engineering milestone is:

> Produce a complete Phase 0 traceability system and a reviewed Phase 1 contract-gap report without changing canonical behavior by accident.

## First working session

1. Create an integration branch in the public kernel.
2. Place the v2.1 package in a read-only reference directory or reference it by path.
3. Place this continuation pack in a temporary planning directory.
4. Fill `control/owner_decisions.yaml`.
5. Run `bash scripts/run_preflight.sh`.
6. Paste `prompts/owner/01_initialize_program.md` into Claude Code.
7. Review the generated reconciliation report before allowing edits to canonical contracts.

## First implementation order

### Workstream A — Program control

Create stable IDs for requirements, gates, tests, evidence, decisions, and deviations. A requirement without an executable verification path is not ready for implementation.

### Workstream B — Contract closure

Inventory every runtime boundary and identify whether it is:

- already canonical;
- incomplete;
- proposed by v2.2;
- duplicated by the action pack;
- intentionally deferred.

### Workstream C — Durable core

Implement the canonical relational transaction that writes the object version, ledger event, current projection, and transactional outbox atomically. Prove idempotency and rebuildability before model-driven behavior.

## Stop conditions

Stop work and escalate to the owner when:

- a proposed document conflicts with the v2.1 Charter;
- a schema would create a second canonical representation of the same concept;
- an agent requests additional authority to finish a task;
- a test cannot distinguish a real pass from a mocked pass;
- private data is needed in the public kernel;
- an R3/R4 path is reachable without fresh scoped approval;
- a technology is being added without a measured requirement;
- a change cannot be rolled back or disabled.

## What success looks like after this pack

- One authoritative requirement map exists.
- Every critical gate maps to an executable command.
- Contract gaps are explicit and owner-reviewed.
- The durable-core implementation has fault-injection evidence.
- The architecture-corpus slice is reproducible.
- The commitment tracker remains a second slice, not a shortcut around the canonical first slice.
