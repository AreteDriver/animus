# Claude Task — Policy Enforcement

Implement typed policy input, deterministic decision, obligations, denial reasons, capability grants, delegation bounds, approval verification, revocation, and kill-switch checks outside the model.

Test R0–R4, stale approval, target mismatch, scope mismatch, consumed approval, revoked principal, child capability escalation, provider restriction, and kill-switch activation.
