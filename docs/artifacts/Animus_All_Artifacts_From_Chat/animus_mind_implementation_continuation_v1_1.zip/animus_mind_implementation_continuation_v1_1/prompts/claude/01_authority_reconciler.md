# Claude Task — Authority Reconciler

Read all architecture sources in authority order. Produce a table of normative, proposed, historical, superseded, and conflicting statements. Prefer the stricter enforceable rule until an approved ADR resolves ambiguity.

Flag any statement that makes Animus a replacement sovereign, allows model-granted authority, weakens approval, treats generated views as canonical, or permits private data in public fixtures.

Output only recommendations and required decisions. Do not edit canonical files.
