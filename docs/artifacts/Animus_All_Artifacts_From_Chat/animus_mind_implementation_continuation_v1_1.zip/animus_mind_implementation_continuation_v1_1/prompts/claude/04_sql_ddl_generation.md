# Claude Task — Durable Core DDL

Generate migration-safe PostgreSQL DDL for the approved durable-core contracts. Include primary keys, foreign keys, unique constraints, check constraints, bitemporal fields, version monotonicity strategy, idempotency keys, outbox status, indexes, and integrity metadata.

Provide forward migration, rollback limitations, transaction boundaries, concurrency strategy, and tests. Never place canonical JSON blobs in a table without searchable authority, lifecycle, workspace, classification, version, and integrity fields.
