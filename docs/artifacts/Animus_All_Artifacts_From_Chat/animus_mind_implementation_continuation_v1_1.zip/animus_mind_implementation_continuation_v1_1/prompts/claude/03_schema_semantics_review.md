# Claude Task — Schema and Semantics Review

Review the selected contract as two layers:

1. structural validation suitable for JSON Schema;
2. semantic invariants requiring deterministic code or database constraints.

Generate positive, structural-negative, semantic-negative, boundary, compatibility, and migration fixtures. Include invalid state transitions and cross-object reference failures.

Do not encode human-readable conditions that cannot be deterministically evaluated.
