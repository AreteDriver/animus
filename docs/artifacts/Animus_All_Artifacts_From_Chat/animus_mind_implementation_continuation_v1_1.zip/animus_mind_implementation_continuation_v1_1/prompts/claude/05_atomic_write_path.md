# Claude Task — Atomic Write Path

Implement one command that validates authorization, policy, schema, semantics, version precondition, and idempotency before atomically writing object version, ledger event, current projection, and outbox entry.

Add fault injection at every write boundary. Prove complete commit or complete rollback. Add duplicate submission tests and deterministic error codes. Capture trace and evidence without logging restricted payloads.
