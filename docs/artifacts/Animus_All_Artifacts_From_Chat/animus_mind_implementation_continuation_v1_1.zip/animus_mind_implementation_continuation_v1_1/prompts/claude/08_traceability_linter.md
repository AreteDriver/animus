# Claude Task — Traceability Linter

Implement or improve the traceability linter so every requirement maps to authority, implementation, tests, gates, and evidence. Fail on missing critical mappings, nonexistent commands, duplicate IDs, unresolved promoted deviations, and `TBD` identifiers.

Add seeded-defect fixtures and prove the linter fails for each one.
