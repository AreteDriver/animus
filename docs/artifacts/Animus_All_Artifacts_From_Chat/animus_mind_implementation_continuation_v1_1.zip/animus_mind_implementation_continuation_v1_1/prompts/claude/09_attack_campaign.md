# Claude Task — Combined Attack Campaign

Create an automated adversarial suite for authorization escalation, prompt injection, forged metadata, replay, duplicate side effects, transaction failure, leakage, deletion resurrection, secret exposure, trace gaps, and gate bypass.

Keep attack fixtures synthetic. Produce a machine-readable result and a human-readable report linked to requirement IDs.
