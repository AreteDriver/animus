# Claude Task — Outbox and Projection

Implement idempotent outbox workers and rebuildable projections. Define deterministic projection keys, claim/retry/dead-letter behavior, checkpoints, replay, reconciliation, and corruption detection.

Prove duplicate delivery creates no duplicate projection or side effect. Delete a projection and rebuild it from canonical state as an acceptance test.
