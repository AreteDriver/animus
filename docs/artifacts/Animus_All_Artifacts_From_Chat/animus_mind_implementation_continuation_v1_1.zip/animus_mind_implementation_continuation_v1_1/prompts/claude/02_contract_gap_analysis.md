# Claude Task — Contract Gap Analysis

Inventory every runtime boundary named by v2.1 and v2.2. For each boundary list existing schema, missing fields, missing semantic validator, missing state machine, missing fixtures, migration impact, compatibility risk, and owner-reserved decisions.

Map Mind Action Pack concepts into v2.1 instead of creating duplicates. Mark each proposal extend, compose, replace, reject, or defer.
