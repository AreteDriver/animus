# Claude Task — Release Evidence Assembly

Collect the approved release artifacts into a deterministic evidence bundle. Generate a manifest with path, size, SHA-256, producer command, trace ID, requirement IDs, and evidence type.

Validate that required artifacts exist, no path escapes the bundle, hashes match, mock-derived evidence is labeled, and critical gates passed. Do not declare promotion; create the package for owner review.
