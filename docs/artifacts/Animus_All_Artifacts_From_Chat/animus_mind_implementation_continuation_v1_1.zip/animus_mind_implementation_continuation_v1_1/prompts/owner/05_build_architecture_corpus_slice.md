# Owner Prompt — Build the Canonical First Vertical Slice

Build the architecture-corpus reconciliation vertical slice exactly within the v2.1 exclusions.

Use the canonical source manifest, source authority rules, claims, contradiction links, Context Envelope, Researcher, Critic, Synthesizer, approval, memory-candidate, durable-core, trace, export, deletion dry-run, restore, and replay paths.

No external side effects. No personal data. No broad tool permissions.

Before coding, show:

- the complete sequence diagram;
- contracts used at each step;
- requirement and gate IDs;
- deliberate fault and adversarial cases;
- evidence artifacts that will be produced.

After coding, run the entire slice from a clean environment and assemble the release evidence bundle.
