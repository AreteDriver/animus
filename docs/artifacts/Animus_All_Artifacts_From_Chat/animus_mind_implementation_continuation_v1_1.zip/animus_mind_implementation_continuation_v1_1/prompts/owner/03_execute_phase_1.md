# Owner Prompt — Execute Phase 1 Contract Closure

Using the accepted Phase 0 traceability map, close the v2.2 contract gaps.

For every proposed contract:

1. cite its canonical requirement IDs;
2. identify any v2.1 overlap;
3. classify the change as extend, compose, replace, reject, or defer;
4. define JSON Schema shape;
5. define semantic invariants separately;
6. define state transitions where applicable;
7. add positive, negative, and semantic-invalid fixtures;
8. add compatibility and migration consequences;
9. update traceability and evidence.

Do not import the Mind Action Pack source/evidence/claim/action-envelope schemas as parallel canon. Map them into v2.1 first.

Stop for owner review before accepting any new canonical object, authority scope, retention rule, provider route, or psychological/personal ontology claim.
