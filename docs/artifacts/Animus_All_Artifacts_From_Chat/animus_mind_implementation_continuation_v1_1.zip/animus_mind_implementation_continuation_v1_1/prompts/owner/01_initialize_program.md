# Owner Prompt — Initialize the v2.2 Program

You are working inside the Animus public-kernel repository. Treat the Animus v2.1 Mind Charter and Executable Baseline as canonical. Treat the v2.2 roadmap and the Mind continuation pack as proposed implementation guidance.

Do not edit code yet.

1. Inventory the repository, current branches, schemas, policies, migrations, tests, CI gates, database code, agent runtime, MCP gateway, and documentation authority.
2. Identify the exact paths of canonical v2.1 artifacts.
3. Compare the repository to `control/requirements.yaml` and the v2.2 phases.
4. Produce a reconciliation report with: already implemented, partially implemented, missing, conflicting, duplicated, and deferred.
5. Identify every decision reserved for the owner.
6. Propose the smallest Phase 0 branch plan.
7. Do not create new canonical schemas, change the Charter, or weaken any gate.
8. End with the first five executable tasks and their verification commands.
