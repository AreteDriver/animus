# Owner Prompt — Execute Phase 0

Implement Phase 0 program control and traceability only.

Required outputs:

- stable requirement IDs with authority sources;
- requirement-to-contract-to-test-to-gate-to-evidence mapping;
- executable gate registry;
- decision and deviation registers;
- evidence manifest support;
- traceability linter;
- seeded-defect tests proving the linter fails correctly;
- Phase 0 evidence bundle.

Constraints:

- no runtime behavior changes;
- no new external dependencies unless strictly required and documented;
- no `TBD` critical test or command IDs;
- no manual narrative accepted as the only proof for a critical requirement;
- update docs and scripts in the same change;
- stop if canonical authority is ambiguous.

Show the proposed file changes before editing. After implementation, run every gate and provide the exact evidence paths.
