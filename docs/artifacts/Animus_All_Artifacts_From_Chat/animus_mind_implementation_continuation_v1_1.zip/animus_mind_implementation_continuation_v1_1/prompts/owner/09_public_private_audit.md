# Owner Prompt — Public/Private Repository Audit

Audit the proposed public-kernel release and its git history for owner-specific or sensitive content.

Check source, tests, fixtures, snapshots, generated documentation, logs, traces, issue templates, commit messages, examples, configuration, and deleted files in history.

Report findings without reproducing secret values. Classify each item as public-safe, synthetic-but-review, private, credential, or uncertain. Provide a remediation path and verify the cleaned branch again.

Do not solve a public test failure by copying a private fixture into the public repository.
