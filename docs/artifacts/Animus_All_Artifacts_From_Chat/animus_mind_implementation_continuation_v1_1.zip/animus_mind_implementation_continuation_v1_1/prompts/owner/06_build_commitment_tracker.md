# Owner Prompt — Build the Commitment Tracker Second Slice

The architecture-corpus slice has passed all critical gates. Build the evidence-backed commitment tracker as the first private application slice.

Start with synthetic data. Use existing canonical source, observation, claim, entity, event, decision, action, outcome, and lesson objects unless a measured gap proves a new commitment object is required.

Authority:

- ingest approved project notes;
- propose commitment candidates;
- detect duplicates, conflicts, and due dates;
- create R2 internal reminders;
- no external sending;
- no calendar modification;
- no health, legal, financial, identity, or psychological inference.

Include prompt-injection, vague-date, quotation, duplicate, supersession, wrong-actor, workspace-leakage, stale-approval, and deletion-resurrection tests.
