# Owner Prompt — Execute Phase 2 Durable Core

Implement the deterministic durable core from the approved contracts.

Build the atomic command path for object version, ledger event, current projection, and transactional outbox. Add idempotency, projection checkpoints, replay, reconciliation, and integrity verification.

Required proof:

- database migrations;
- transaction integration tests;
- duplicate-submission tests;
- duplicate-delivery tests;
- fault injection at each transaction boundary;
- projection deletion and rebuild;
- seeded integrity corruption detection;
- evidence bundle with commands and outputs.

Do not add an event broker, workflow engine, graph database, or model-driven behavior in this phase unless an owner-approved technology admission record exists.
