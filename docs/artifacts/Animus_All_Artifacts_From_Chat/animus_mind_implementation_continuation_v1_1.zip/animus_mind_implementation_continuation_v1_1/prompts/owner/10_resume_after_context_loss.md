# Owner Prompt — Resume After Context Loss

Reconstruct the active implementation state from repository evidence rather than memory.

Read the Charter, baseline, current branch, owner decisions, work-item registry, deviation register, latest evidence manifest, open pull requests, and failing gates.

Then provide:

1. current phase and accepted milestone;
2. last completed work item and proof;
3. unresolved owner decisions;
4. current failing gates;
5. next smallest executable task;
6. commands you will run;
7. files you expect to change;
8. stop conditions.

Do not infer acceptance from merged code alone.
