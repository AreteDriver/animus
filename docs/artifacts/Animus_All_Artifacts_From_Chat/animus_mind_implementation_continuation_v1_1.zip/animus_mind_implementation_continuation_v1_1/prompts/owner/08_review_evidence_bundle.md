# Owner Prompt — Review Release Evidence

Review the capability evidence bundle as a skeptical release authority.

Verify that every critical claim is supported by executable output, not narrative. Re-run a representative sample of commands from a clean environment. Check hashes, trace completeness, policy versions, migration/rollback, private/public boundaries, restore, export, deletion, kill switch, and known limitations.

Return one decision:

- reject;
- return for correction;
- approve for evaluation;
- approve for shadow;
- approve for limited use.

Do not approve general use unless the capability has already passed limited operation with retained evidence and no unresolved critical defect.
