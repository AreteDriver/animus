# Changelog

## 1.1 — 2026-06-17

- Reconciles the Mind Action Pack with the v2.1 canonical authority hierarchy.
- Resolves the vertical-slice ordering conflict: architecture corpus first, commitment tracker second.
- Treats Culture-style sovereignty as inspiration, not system authority.
- Adds detailed Phase 0, Phase 1, and Phase 2 execution plans.
- Adds contract-delta and repository-placement maps.
- Adds owner decisions with recommended defaults.
- Adds Claude prompts, subagents, skills, scripts, and control registries.
- Adds release evidence and promotion procedures.
- Adds explicit stop-work conditions and deferred-technology rules.
