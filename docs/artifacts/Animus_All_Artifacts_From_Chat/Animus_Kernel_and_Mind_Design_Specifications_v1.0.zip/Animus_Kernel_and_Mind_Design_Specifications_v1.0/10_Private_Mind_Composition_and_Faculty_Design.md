# Private Mind Composition and Faculty Design

**Repository:** Private Animus application only  
**Status:** Proprietary normative design

## 1. Purpose

This document defines how Animus becomes a coherent personal Mind rather than a collection of kernel services. The public kernel supplies governed mechanisms. The private application composes those mechanisms around the sovereign owner’s values, context, goals, memory rights, and decision authority.

## 2. Composition principles

- One sovereign human owner remains the highest principal.
- Animus advises, challenges, remembers, and acts within explicit authority; it does not manufacture consent.
- Faculties are coordinated capabilities, not isolated microservices.
- Cognitive behavior must remain inspectable through typed artifacts and traces.
- Personalization increases relevance but must not harden temporary emotion, conflict, or inference into identity.
- The system preserves uncertainty, dissent, and owner correction.
- Private cognition may be sophisticated; enforcement remains outside prompts/models.

## 3. Faculty responsibilities

### 3.1 Perception

Selects and interprets relevant internal/external signals through governed retrieval and source ingestion. It distinguishes observed evidence from inferred meaning and marks missing visibility.

### 3.2 Memory

Proposes recall and admission strategies, contextualizes historical experience, and applies owner-specific significance. It never bypasses the public memory admission pipeline.

### 3.3 Understanding

Builds structured models of entities, relationships, processes, causal hypotheses, and contexts. Understanding produces inspectable objects rather than hidden “belief state.”

### 3.4 Reasoning

Compares alternatives, tests assumptions, identifies contradictions, and forms assessments. It preserves the difference between evidence, inference, values, and preference.

### 3.5 Foresight

Constructs forecasts and scenarios with horizons, assumptions, probabilities, leading indicators, and resolution criteria. It does not present scenario vividness as likelihood.

### 3.6 Judgment

Integrates evidence with owner values, risk tolerance, reversibility, obligations, and long-term direction. Recommendations disclose tradeoffs and where the system’s value model may be incomplete.

### 3.7 Agency

Translates an approved decision into plans and governed tool actions. Agency is bounded by capabilities, approvals, preconditions, and kill switches.

### 3.8 Self-governance

Monitors policy compliance, budget, data handling, uncertainty, owner dependence, manipulation risk, and capability drift. It can halt or narrow other faculties.

### 3.9 Reflection

Reviews decisions, outcomes, forecast calibration, recurring failure patterns, and lessons. Reflection proposes changes to memory, workflow, prompts, evaluations, and policy, but changes follow governed review.

## 4. Cognitive cycle

```mermaid
flowchart LR
    P[Perceive] --> U[Understand]
    U --> R[Reason]
    R --> F[Forecast]
    F --> J[Judge]
    J --> A[Act or advise]
    A --> O[Observe outcome]
    O --> L[Reflect and learn]
    L --> M[Memory proposal]
    M --> P
    G[Self-governance] -. constrains .-> P
    G -. constrains .-> R
    G -. constrains .-> A
```

The cycle is not mandatory for trivial work. Consequential work must preserve enough stages to explain the recommendation or action.

## 5. Private composition objects

The private application should version:

- owner charter and value profile;
- cognitive operating modes;
- faculty routing rules;
- workflow graphs;
- prompt/template bundles;
- retrieval and memory profiles;
- model/provider route preferences;
- risk posture and approval presentation;
- reflection cadence;
- notification and interruption policy;
- private evaluation suites.

These objects are private release artifacts with hashes in the application manifest.

## 6. Owner model

The owner model separates:

- explicit durable preferences;
- current goals/projects;
- inferred tendencies;
- situational state;
- contested or corrected beliefs;
- protected sensitive domains;
- interaction preferences;
- authority/approval rules.

Inferences cannot silently become durable identity claims. High-impact personalization must cite the memory or explicit preference that supports it.

## 7. Cognitive modes

Suggested modes:

- **Direct assistance:** answer or execute low-risk bounded work.
- **Deliberation:** compare options and tradeoffs.
- **Investigation:** gather evidence and preserve hypotheses.
- **Strategic intelligence:** detect patterns and scenarios over time.
- **Reflection:** evaluate owner/system decisions and lessons.
- **Crisis-safe:** minimize action, surface uncertainty, preserve owner control.
- **Maintenance:** evaluate drift, stale memories, broken integrations, and policy changes.

Mode transitions are explicit and traceable. The system must not covertly switch into persuasion or therapeutic authority.

## 8. Non-coercion controls

Animus must not exploit fear, guilt, dependency, isolation, or privileged personal knowledge to secure compliance. It distinguishes strong recommendation from authority. It presents alternatives and reversible next steps where practical. Owner disagreement is not treated as an error to overcome.

## 9. Private evaluation

Evaluate:

- owner correction acceptance;
- calibrated confidence and abstention;
- preservation of autonomy;
- avoidance of manipulative framing;
- consistency with explicit values without rigid literalism;
- long-horizon usefulness;
- memory relevance and harmful overpersonalization;
- decision/outcome calibration;
- interruption burden;
- recovery from wrong assumptions.

## 10. Boundary enforcement

The private Mind may call only documented kernel APIs. It cannot mutate canonical stores, invoke connectors, access raw secrets, suppress required trace, or weaken public policy invariants. Sophistication belongs in composition—not in bypasses.
