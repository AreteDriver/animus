# Identity, Policy, Keys, and Kill Switch Design

**Repository:** Public kernel contracts and enforcement; private deployment profiles and secret implementations  
**Roadmap alignment:** P3  
**Criticality:** Constitutional

## 1. Responsibility

This subsystem proves who or what is acting, what authority it possesses, under which purpose and workspace, what policy decided, whether human approval is required, how secrets are obtained without entering model context, and how authority is revoked independently of agents.

## 2. Principal model

Principal types:

- sovereign owner;
- owner-operated device session;
- application service;
- agent execution;
- worker;
- extension/adapter;
- recovery operator;
- test principal.

Only the sovereign owner is the root authority. Service and agent principals are delegated identities. Delegation cannot exceed the parent’s capabilities, classification ceiling, workspace scope, duration, or purpose.

A principal record contains identity type, parent, authentication strength, device binding when applicable, issued/expiry time, workspace scope, revocation epoch, and allowed delegation depth.

## 3. Capability grant

Capabilities are explicit grants:

```yaml
capability_id: cap-id
principal_id: agent-run-id
action: tool.calendar.create
resource_scope: workspace/personal/calendar
purpose: owner-approved-scheduling
risk_ceiling: R2
data_classification_ceiling: confidential
valid_from: timestamp
expires_at: timestamp
constraints:
  max_calls: 3
  max_cost: 0
  destination_allowlist: []
revocation_epoch: 42
```

Ambient filesystem, network, cloud metadata, inherited shell credentials, and process environment are not capabilities.

## 4. Policy decision point and enforcement points

The policy decision point (PDP) is deterministic for the same signed inputs, policy version, and time basis. It returns:

- `allow`, `deny`, or `require_approval`;
- applicable risk class;
- obligations and preconditions;
- data handling restrictions;
- policy version/hash;
- expiry;
- reason codes.

Policy enforcement points (PEPs) exist at retrieval, canonical write, agent delegation, provider routing, tool invocation, export, deletion, and administrative operations. A PEP may enforce stricter local constraints but may not weaken the PDP outcome.

## 5. Approval lifecycle

Approval state:

`requested -> presented -> approved | denied | expired | revoked -> consumed | cancelled`

A receipt is scoped to the exact action class, normalized parameters or parameter hash, workspace, principal, risk, validity window, and maximum uses. R3/R4 approvals are fresh by default. Parameter drift invalidates approval. A consumed single-use approval cannot be replayed.

The owner-facing approval presentation must disclose consequential effects, destination, reversibility, data released, estimated cost, and known uncertainty. Approval UX is private; receipt semantics are public.

## 6. Secret broker boundary

The model and general agent runtime receive secret references, never secret values. The secret broker:

- authenticates the requesting service principal;
- verifies capability and policy decision;
- resolves a narrowly scoped secret;
- delivers it directly to an approved adapter execution context;
- records use without recording the value;
- supports rotation and immediate revocation;
- blocks export to prompts, traces, logs, exceptions, or receipts.

Adapters should use short-lived tokens. Long-lived credentials are isolated and rotated behind the broker.

## 7. Key architecture

- root owner key or equivalent root trust anchor;
- workspace data-encryption keys;
- object or blob data keys where warranted;
- separate signing keys for policy, receipts, and release evidence;
- independent backup key handling;
- cryptographic erasure by destruction of active data keys after deletion authorization.

Key references are durable; raw key material is not. Restore procedures must verify that revoked credentials and destroyed data keys are not resurrected.

## 8. Kill switches

Kill switches operate without agent cooperation:

- global tool execution stop;
- R3/R4 action stop;
- provider route stop;
- source ingestion stop;
- memory admission stop;
- outbound network stop;
- workspace quarantine;
- principal/session revocation;
- full application read-only mode.

Each switch has a separate authorization path, observable state, reason, activation timestamp, and tested recovery procedure. Failures in the agent runtime must not prevent activation.

## 9. Revocation

Revocation increments a principal or scope epoch. All grants and cached decisions include the observed epoch and become invalid when it changes. Long-running work checks revocation at bounded intervals and before consequential transitions. Queued work revalidates authorization at execution time.

## 10. Failure semantics

- Unknown principal or unverifiable token: deny.
- PDP unavailable: deny consequential operations; optionally permit explicitly safe cached read decisions within a short TTL.
- Policy signature/hash mismatch: stop affected path.
- Approval store unavailable: deny approval-required action.
- Secret broker unavailable: adapter cannot execute.
- Revocation feed stale beyond SLO: stop high-risk operations.
- Kill-switch state uncertain: assume activated for affected capability.

## 11. Adversarial tests

- forged owner identity;
- confused-deputy delegation;
- capability escalation;
- stale or cross-workspace approval replay;
- parameter substitution after approval;
- revoked token during long-running agent work;
- prompt injection requesting secret disclosure;
- adapter exception containing credentials;
- cloud metadata credential acquisition;
- kill-switch activation while agents and queues are unhealthy;
- restoration from backup containing old credentials.

Zero unauthorized R3/R4 actions is a release invariant, not an average quality metric.

## 12. Evidence

Retain policy bundle hash, decision fixtures, capability graph tests, approval replay report, revocation latency report, secret scanning results, kill-switch exercise, provider routing classification tests, key rotation test, and restore-with-revoked-credential proof.
