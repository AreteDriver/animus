# Agent Runtime and Intelligence Workflow Design

**Repository:** Public kernel runtime and typed workflow primitives; private agents, prompts, strategies, and orchestration graphs  
**Roadmap alignment:** P6

## 1. Responsibility

The agent runtime executes bounded model-assisted work under explicit contracts. It provides budgets, cancellation, delegation limits, structured outputs, tool mediation, tracing, and failure containment. Intelligence workflow primitives preserve typed transitions from evidence to forecast and decision.

The kernel does not contain the proprietary Animus personality, owner model, private prompts, or final orchestration strategy.

## 2. Agent contract

Each execution declares:

- agent ID and contract version;
- role and objective;
- completion and abstention criteria;
- allowed input artifact types;
- allowed tools/capabilities;
- workspace and classification ceiling;
- token, time, cost, recursion, and tool-call budgets;
- required output schema;
- escalation path;
- model/provider constraints;
- prompt/template identity;
- trace parent and cancellation token.

Unknown tools, undeclared outputs, and implicit delegation are rejected.

## 3. Execution lifecycle

```text
created -> authorized -> context_bound -> running
-> awaiting_tool | awaiting_delegate | synthesizing
-> completed | abstained | cancelled | failed | budget_exhausted
```

Every transition emits a trace event. Cancellation is cooperative at the model boundary and enforced at the runtime/tool boundary. A cancelled run cannot start new tools or commit new canonical state.

## 4. Delegation

A child receives a subset of the parent’s capabilities, time, classification, and purpose. Delegation depth and fan-out are bounded. The coordinator remains responsible for evidence coverage and synthesis. Agent identity does not establish evidence independence.

## 5. Researcher–critic–synthesizer reference pattern

The public runtime may ship a reference workflow:

1. researcher proposes evidence-backed findings;
2. critic searches for missing evidence, contradictions, invalid inference, and unsafe recommendations;
3. synthesizer produces a typed assessment while preserving material dissent.

Private Animus workflows may use additional specialists. The synthesis must link each material conclusion to evidence dependencies and identify unsupported inference.

## 6. Intelligence object chain

`source -> observation -> signal -> pattern -> hypothesis -> assessment -> forecast -> decision -> action -> outcome -> lesson`

Each stage has a schema, provenance, and entry criteria. Skipping a stage requires a machine-recorded justification. Examples:

- a source passage can support an observation but is not itself a pattern;
- a pattern needs repeated or structurally related signals;
- a hypothesis is a testable explanation, not a high-confidence fact;
- an assessment combines evidence and uncertainty;
- a forecast needs horizon, probability, assumptions, alternatives, and resolution rule;
- a decision records owner or authorized system choice, not merely model recommendation.

## 7. Evidence dependency graph

Conclusions link to claims, sources, transformations, models, and prior intelligence objects. Independence is calculated from shared origins and derivation paths. Five agents quoting the same article remain one evidence lineage.

The graph supports:

- provenance inspection;
- circular-source detection;
- contradiction propagation;
- confidence recalculation;
- forecast scoring;
- later lesson extraction.

## 8. Dissent preservation

Material dissent is preserved when it changes expected outcome, risk, ethical/owner alignment, confidence, or recommended action. The synthesizer may adjudicate but cannot erase the dissent. Output includes dissent statement, evidence, confidence, and resolution/remaining uncertainty.

## 9. Model/provider behavior

Provider adapters expose capabilities and data-handling declarations. Routing occurs before content transmission and respects classification, residency, retention, and owner policy. Model failures are not silently treated as negative evidence. Structured-output repair may be attempted only under a bounded, traced repair policy.

## 10. Commit boundary

Agent outputs are proposals. Canonical claims, memories, decisions, and actions pass through their governing validators and policy gates. The runtime has no direct database or connector bypass.

## 11. Failure semantics

- Budget exhausted: stop, return partial typed result and missing-work declaration.
- Model unavailable: use approved route fallback or fail explicitly.
- Structured output invalid: bounded repair, then fail.
- Tool denied: preserve denial and continue only if completion remains valid.
- Child failure: coordinator may replace, abstain, or synthesize with reduced confidence.
- Evidence below threshold: abstain or return hypothesis, not assessment/fact.
- Cancellation: stop future effects and checkpoint resumable work where allowed.
- Trace sink unavailable: block consequential workflows when trace completeness cannot be guaranteed.

## 12. Tests and gates

Roadmap gates: contract conformance ≥ 0.98, evidence coverage ≥ 0.95, zero unauthorized tool calls, appropriate abstention ≥ 0.90, and 100% preservation of critical dissent.

Adversarial campaigns include prompt injection, goal hijacking, recursive delegation, tool laundering through child agents, fake citations, circular evidence, consensus pressure, hidden dissent, budget evasion, cancellation races, provider route downgrade, and model-output schema smuggling.

## 13. Evidence

Retain agent contract manifest, prompt/model/provider identities, budget reports, delegation graphs, evidence coverage evaluation, abstention evaluation, dissent cases, unauthorized-tool report, cancellation fault tests, and replayable redacted reference traces.
