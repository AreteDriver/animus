#!/usr/bin/env python3
from pathlib import Path
import hashlib, json, sys, yaml

ROOT = Path(__file__).resolve().parents[1]
REQUIRED = [
    "README.md",
    *[f"{i:02d}_" for i in range(1, 15)],
    "adrs/ADR-017_contract_first_module_boundaries.md",
    "adrs/ADR-018_private_cognition_public_mechanism.md",
    "registries/module_design_registry.yaml",
    "registries/interface_catalog.yaml",
    "registries/failure_mode_registry.yaml",
    "templates/module_design_template.md",
    "templates/interface_contract_template.yaml",
]

def load(path):
    return yaml.safe_load(path.read_text(encoding="utf-8"))

def validate_presence():
    files = [p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file()]
    for item in REQUIRED:
        if item.endswith("_"):
            if not any(Path(f).name.startswith(item) for f in files):
                raise AssertionError(f"Missing numbered document prefix {item}")
        elif item not in files:
            raise AssertionError(f"Missing {item}")

def validate_yaml():
    for path in ROOT.rglob("*.yaml"):
        load(path)

def validate_modules():
    modules = load(ROOT/"registries/module_design_registry.yaml")["modules"]
    ids = [m["id"] for m in modules]
    if len(ids) != len(set(ids)): raise AssertionError("Duplicate module ID")
    known = set(ids)
    writers = [m["id"] for m in modules if m.get("canonical_write")]
    if writers != ["durable_core"]: raise AssertionError(f"Canonical writers: {writers}")
    for m in modules:
        if set(m["depends_on"]) - known: raise AssertionError(f"Unknown dependency in {m['id']}")
        if not (ROOT/m["design_document"]).exists(): raise AssertionError(f"Missing design for {m['id']}")

def validate_interfaces():
    modules = {m["id"] for m in load(ROOT/"registries/module_design_registry.yaml")["modules"]}
    catalog = load(ROOT/"registries/interface_catalog.yaml")
    ids = set()
    for i in catalog["interfaces"]:
        if i["id"] in ids: raise AssertionError(f"Duplicate interface {i['id']}")
        ids.add(i["id"])
        if i["provider_module"] not in modules: raise AssertionError(f"Unknown provider {i['id']}")
        if i["contract_class"] not in catalog["contract_classes"]: raise AssertionError(f"Bad class {i['id']}")
        if i["stability"] not in catalog["stability_levels"]: raise AssertionError(f"Bad stability {i['id']}")
        if i["visibility"] == "public" and i["provider_module"] in {
            "faculty_orchestration","personalization_owner_model","world_model_priorities",
            "prompt_workflow_assets","product_experience"
        }: raise AssertionError(f"Private provider public interface {i['id']}")

def validate_failures():
    modules = {m["id"] for m in load(ROOT/"registries/module_design_registry.yaml")["modules"]}
    failures = load(ROOT/"registries/failure_mode_registry.yaml")["failure_modes"]
    ids = set()
    for f in failures:
        if f["id"] in ids: raise AssertionError(f"Duplicate failure {f['id']}")
        ids.add(f["id"])
        if f["module"] not in modules: raise AssertionError(f"Unknown module {f['id']}")
        if f["severity"] == "critical" and not f["evidence_required"]:
            raise AssertionError(f"Critical failure missing evidence {f['id']}")

def validate_manifest():
    path = ROOT/"package_manifest.json"
    if not path.exists(): return
    manifest = json.loads(path.read_text(encoding="utf-8"))
    for item in manifest["files"]:
        p = ROOT/item["path"]
        data = p.read_bytes()
        if len(data) != item["bytes"]: raise AssertionError(f"Size mismatch {item['path']}")
        if hashlib.sha256(data).hexdigest() != item["sha256"]:
            raise AssertionError(f"Hash mismatch {item['path']}")

def main():
    validate_presence(); validate_yaml(); validate_modules()
    validate_interfaces(); validate_failures(); validate_manifest()
    print("PASS: required files, YAML, module ownership, interfaces, failure modes, and manifest")

if __name__ == "__main__":
    try: main()
    except Exception as exc:
        print(f"FAIL: {type(exc).__name__}: {exc}", file=sys.stderr)
        raise
