# Design Review and Implementation Readiness Checklist

Use this checklist before implementation begins and again before a module is declared interface-frozen.

## 1. Authority and placement

- [ ] Governing charter, baseline section, roadmap phase, and ADRs are identified.
- [ ] Public kernel vs private application ownership is explicit.
- [ ] The design does not duplicate a cognitive faculty as a service.
- [ ] Private prompts, owner models, workflows, endpoints, and data are excluded from public scope.
- [ ] Dependency direction is acyclic and registry-aligned.

## 2. Responsibility

- [ ] Single primary responsibility is stated.
- [ ] Non-responsibilities are stated.
- [ ] Upstream/downstream modules are identified.
- [ ] Canonical authority vs generated projection is clear.
- [ ] Product policy vs reusable mechanism is separated.

## 3. Interfaces

- [ ] Commands, queries, events, receipts, and SPIs are versioned.
- [ ] Input/output schemas and semantic validators are named.
- [ ] Identity, workspace, purpose, classification, budget, and trace context are present where applicable.
- [ ] Error taxonomy is deterministic and documented.
- [ ] Compatibility and deprecation behavior is defined.
- [ ] No undocumented dictionary or ambient context crosses a boundary.

## 4. State and atomicity

- [ ] Legal states and transitions are enumerated.
- [ ] Invariants are machine-testable.
- [ ] Transaction and external side-effect boundaries are explicit.
- [ ] Idempotency and concurrency behavior are specified.
- [ ] Temporal semantics are defined.
- [ ] Correction, supersession, deletion, and replay are covered.

## 5. Security and sovereignty

- [ ] Default-deny behavior is explicit.
- [ ] Capability and delegation limits are defined.
- [ ] Approval and precondition rules are defined for consequential behavior.
- [ ] Secrets remain outside model context and general telemetry.
- [ ] Workspace/data-classification enforcement occurs before exposure.
- [ ] Kill-switch and revocation behavior is independent of agents.
- [ ] Owner correction, export, and deletion rights are preserved.
- [ ] Manipulation/dependency risks are assessed for private cognitive features.

## 6. Failure and recovery

- [ ] Every critical dependency failure has fail-open/fail-closed behavior.
- [ ] Partial execution and uncertain outcome states are represented.
- [ ] Retry is safe and bounded.
- [ ] Compensation or reconciliation is defined.
- [ ] Recovery does not resurrect deleted data, revoked credentials, or old approvals.
- [ ] Degraded modes are visible and time-bounded.

## 7. Observability

- [ ] Required traces, metrics, logs, and receipts are listed.
- [ ] Redaction/classification behavior is defined.
- [ ] SLOs and alert thresholds are specified or referenced.
- [ ] Consequential trace completeness is testable.
- [ ] Evidence artifacts have stable names and hashes.

## 8. Testing

- [ ] Positive and negative contract fixtures exist.
- [ ] Semantic-invalid fixtures exist.
- [ ] Property/invariant tests are identified.
- [ ] Integration and cross-repository conformance tests are identified.
- [ ] Fault injection covers each atomicity boundary.
- [ ] Adversarial tests attack every trust boundary.
- [ ] Recovery/rebuild/replay tests are specified.
- [ ] Critical failures cannot be averaged away.

## 9. Operational readiness

- [ ] Runbook ownership is assigned.
- [ ] Migration and rollback strategy is tested.
- [ ] Configuration and environment assumptions are explicit.
- [ ] Dependency health and capability readiness are distinct.
- [ ] Capacity, cost, rate, and budget limits are defined.
- [ ] Evidence retention and access are governed.

## 10. Approval to implement

A module is **implementation-ready** only when:

- no constitutional or safety-critical behavior is left to prompt convention;
- no critical interface or state transition is undefined;
- public/private ownership is unambiguous;
- required tests and evidence can be produced;
- a named reviewer accepts residual risks and deviations.

Record the review result:

```yaml
module_id: example
spec_version: 1.0.0
reviewed_commit: git-sha
result: approved | changes_required | rejected
reviewers: []
open_deviations: []
approved_at: timestamp
expires_at: null
```
