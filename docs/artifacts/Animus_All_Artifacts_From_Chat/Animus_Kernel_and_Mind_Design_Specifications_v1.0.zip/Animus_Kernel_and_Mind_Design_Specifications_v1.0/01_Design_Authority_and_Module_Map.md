# Design Authority and Module Map

**Status:** Normative design index

## 1. Objective

This document establishes the implementation decomposition for Animus v2.2 and prevents three recurring architecture failures:

1. cognitive faculties being implemented as tightly coupled services;
2. infrastructure components silently owning policy or product behavior;
3. private Animus assumptions leaking into the reusable kernel.

Faculties describe *why the Mind acts*. Modules describe *what software responsibility is executed*. Planes describe *where a responsibility participates*. These are independent views and must not be collapsed.

## 2. Design views

### 2.1 Cognitive faculties — private composition

- Perception
- Memory
- Understanding
- Reasoning
- Foresight
- Judgment
- Agency
- Self-governance
- Reflection

The kernel may expose mechanisms used by a faculty, but no kernel package may claim to embody the complete faculty. For example, the retrieval service supports perception, memory, reasoning, and foresight; it is not the “Understanding service.”

### 2.2 Technical planes — cross-cutting architecture

- Experience
- Orchestration
- Context
- Intelligence
- Action
- Governance
- Observability
- Infrastructure

### 2.3 Runtime modules — implementation units

| Module | Repository owner | Primary responsibility | Depends on |
|---|---|---|---|
| Contract registry and semantic validation | Public kernel | Schema identity, validation, compatibility | None |
| Durable core | Public kernel | Canonical state, ledger, projection, outbox | Contracts |
| Identity/capability primitives | Public kernel | Principal and grant representation | Contracts, durable core |
| Policy runtime | Public kernel | Deterministic decision and enforcement hooks | Identity, contracts |
| Secret-broker interface | Public kernel; implementation usually private | Secret references and bounded retrieval | Identity, policy |
| Source ingestion | Public kernel mechanism | Immutable source registration and normalized extraction | Durable core, policy |
| Governed retrieval | Public kernel mechanism | Authorized, temporal Context Envelope assembly | Sources, durable core, policy |
| Memory admission | Public kernel mechanism | Candidate validation and atomic admission | Retrieval, policy, durable core |
| Agent runtime | Public kernel mechanism | Contract, budget, cancellation, delegation, trace | Policy, retrieval, trace |
| Intelligence workflow primitives | Public kernel mechanism | Typed stage transitions and evidence graph | Agent runtime, durable core |
| MCP/tool gateway | Public kernel mechanism | Capability, approval, idempotency, receipts | Policy, trace, durable core |
| Trace and audit | Public kernel | Correlated execution evidence | All runtime modules |
| Evaluation and promotion | Public kernel mechanism | Gate execution and promotion state | Trace, evidence store |
| Export/deletion/recovery | Public kernel mechanism; deployment private | Enumerate, verify, erase, restore | Durable core, projections, keys |
| Composition root | Private application | Bind all concrete components and profiles | Published kernel API only |
| Faculty orchestration | Private application | Animus cognitive behavior | Composition root, kernel APIs |
| Personalization and owner model | Private application | Owner-specific goals, values, preferences, boundaries | Memory/retrieval APIs |
| World model and intelligence priorities | Private application | Physical/social/economic state interpretation | Retrieval, intelligence primitives |
| Prompt and workflow assets | Private application | Model instructions and private orchestration graphs | Agent runtime APIs |
| Product experience | Private application | Owner console, API, notifications, UX | Composition root |

## 3. Dependency order

The implementation dependency graph is intentionally acyclic:

```mermaid
flowchart TD
    C[Contracts and semantic validation] --> D[Durable core]
    D --> I[Identity and capabilities]
    I --> P[Policy and approvals]
    D --> S[Source ingestion]
    P --> S
    S --> R[Governed retrieval]
    P --> R
    R --> M[Memory admission]
    D --> M
    R --> A[Agent runtime]
    P --> A
    A --> W[Intelligence workflow primitives]
    A --> G[MCP gateway]
    P --> G
    D --> T[Trace and evidence]
    A --> T
    G --> T
    T --> E[Evaluation and promotion]
    D --> O[Export deletion recovery]
    E --> X[Private composition root]
    M --> X
    W --> X
    G --> X
```

Circular runtime callbacks must use explicit events or interfaces. Direct imports against a higher layer are prohibited.

## 4. Contract classes

Every cross-module contract belongs to one class:

- **Canonical object contract:** durable schema and semantic rules.
- **Command contract:** requested state change with principal, purpose, idempotency, and preconditions.
- **Query contract:** read request with scope, classification ceiling, temporal perspective, and budget.
- **Event contract:** accepted fact about a completed or denied transition.
- **Receipt contract:** durable proof of policy and execution outcome.
- **Extension contract:** SPI implemented by an adapter.
- **Evaluation contract:** input corpus, scorer, threshold, and evidence output.

Unversioned dictionaries, ambient context, and undocumented callback shapes are not acceptable boundaries.

## 5. Atomicity boundaries

Only the durable core owns database transaction composition. Higher modules submit transaction intents. A module may define semantic preconditions but may not perform partial direct writes across canonical tables.

The minimum canonical mutation transaction is:

1. verify command identity and preconditions;
2. append accepted event;
3. append new object version;
4. update current projection;
5. append outbox work;
6. commit once;
7. return immutable commit receipt.

Policy decisions and approvals used for consequential writes must be linked to the transaction. External side effects occur after canonical intent is durable and must be reconciled through receipts and idempotency.

## 6. Public/private placement test

A component belongs in the public kernel only when all are true:

- its semantics are application-neutral;
- its interfaces can be documented without private data or prompts;
- an independent consumer could use it without understanding Animus internals;
- it has a stable conformance suite;
- publication does not reveal owner-specific behavior, proprietary workflow, or sensitive topology.

When uncertain, keep it private until reuse is demonstrated. Premature extraction creates a false public API and long-term compatibility burden.

## 7. Design completeness states

Each module progresses through:

`identified -> specified -> interface_frozen -> implementation_ready -> implemented -> verified -> adversarially_verified -> operationally_proven -> promoted`

`interface_frozen` means all critical inputs, outputs, transitions, error classes, and ownership are versioned. It does not mean the interface can never change; it means changes now require compatibility review.

## 8. Required artifacts per module

- module design specification;
- interface definitions;
- state-transition table;
- data-classification and threat notes;
- error taxonomy;
- test plan and negative fixtures;
- SLO and observability fields;
- evidence manifest entries;
- runbook links for operational modules;
- ADR for materially irreversible choices.

The machine-readable registry in `registries/module_design_registry.yaml` is the authoritative inventory for design coverage.
