# <Module Name> Module Design

**Module ID:**  
**Repository placement:**  
**Status:** identified / specified / interface frozen / implementation ready / implemented / verified  
**Authority:**  
**Owner:**  

## 1. Responsibility
## 2. Non-responsibilities
## 3. Dependencies and prohibited dependencies
## 4. Versioned input, output, event, receipt, and extension contracts
## 5. Durable state, projections, indexes, caches, and secret references
## 6. Legal states, transitions, guards, and terminal states
## 7. Atomicity, idempotency, external effects, and reconciliation
## 8. Capability, policy, approval, classification, retention, and provider routing
## 9. Typed failures and fail-closed behavior
## 10. Metrics, traces, logs, alerts, SLOs, and redaction
## 11. Unit, contract, integration, fault, adversarial, recovery, and performance tests
## 12. Promotion evidence, runbooks, deviations, and gate IDs
## 13. Security, private assumptions, and publication review
