# Export, Deletion, Recovery, and Incident Design

**Repository:** Public kernel contracts/mechanisms; private deployment inventory, topology, and runbooks  
**Roadmap alignment:** P9

## 1. Responsibility

This subsystem proves that the owner can obtain their data, remove it from active and derived systems, recover service without resurrecting deleted content or revoked authority, and respond to incidents with bounded, auditable control.

## 2. Data inventory prerequisite

Export and deletion are only credible when every data-bearing system is registered:

- canonical database;
- event/receipt stores;
- object/blob storage;
- search/vector/graph indexes;
- caches and queues;
- trace/evidence stores;
- provider-side retained data where applicable;
- backups and snapshots;
- local device stores;
- connector-specific artifacts.

Each registry entry states owner/workspace addressing, encryption, retention, deletion method, restore behavior, and verification command.

## 3. Export

An export request is authenticated, authorized, scoped, versioned, and traceable. Export includes canonical objects, relevant history, source/provenance references, approvals/receipts, policy-relevant metadata, and a manifest of omitted material with reason. Generated views may be included but must be labeled as rebuildable/noncanonical.

The export manifest contains file hashes, schema versions, object counts, time range, workspace, classification, encryption information, and verification instructions. A verifier must detect corruption or omission.

## 4. Deletion lifecycle

```text
requested -> authorized -> enumerated -> frozen
-> active_store_deleted -> derived_store_deleted
-> keys_destroyed_when_applicable -> verified
-> backup_expiry_pending -> completed
```

Deletion is object/workspace aware. Enumeration occurs from the authoritative inventory and creates a deletion plan before destructive execution. A tombstone prevents automatic re-ingestion or restoration. The plan records legal/safety exceptions explicitly.

## 5. Derived data

Search, vector, graph, caches, generated views, evaluation corpora, and trace payload references must be deleted or rebuilt without affected content. A deletion cannot be considered complete because the canonical row is gone while embeddings or source chunks remain queryable.

## 6. Backups and cryptographic erasure

Active deletion targets are distinct from backup expiry. Destroying active data keys may render encrypted content inaccessible immediately, while backup media expires within the bounded retention target. Restore tooling reads deletion tombstones and destroyed-key registry before reactivation.

Target outcomes from the roadmap:

- active deletion ≤ 24 hours;
- derived deletion ≤ 4 hours;
- backup expiry ≤ 35 days;
- RPO ≤ 5 minutes;
- RTO ≤ 2 hours.

## 7. Restore

Restore occurs to clean infrastructure and verifies:

1. artifact and backup provenance;
2. key availability and revocation state;
3. schema/migration compatibility;
4. canonical integrity;
5. projection rebuild;
6. deletion tombstone application;
7. credential/session invalidation;
8. reconciliation and SLO readiness;
9. owner authorization before returning to general service.

Restoring an old database image must not reactivate deleted data, revoked sessions, old approvals, or obsolete policies.

## 8. Incident control

Incident classes include confidentiality breach, unauthorized action, integrity divergence, deletion failure, credential exposure, provider mishandling, recovery failure, and trace/evidence loss. Incident mode can activate kill switches, quarantine workspaces, stop writes, preserve forensic evidence, and switch to safe read-only service.

The runbook records detection, severity, authority, containment, evidence preservation, owner communication, remediation, recovery, and post-incident lessons.

## 9. Failure semantics

- Incomplete data inventory: deletion/export promotion gate fails.
- Enumeration uncertainty: stop destructive phase and require review.
- Derived store unavailable: retain pending state and block completion claim.
- Backup restore contains tombstoned data: quarantine restore.
- Export hash mismatch: export invalid.
- Key destruction unverified: deletion incomplete.
- Incident trace store unavailable: preserve local signed emergency log.
- Recovery exceeds SLO: remain degraded; do not bypass integrity checks.

## 10. Tests

- full and scoped export verification;
- deletion dry-run and destructive test on synthetic owner/workspace;
- cache/index/embedding resurrection attempts;
- re-ingestion of tombstoned content;
- backup restore before and after key destruction;
- revoked credential and approval resurrection;
- point-in-time recovery under partial infrastructure loss;
- projection rebuild and reconciliation;
- incident kill-switch/tabletop exercise;
- evidence-chain integrity.

## 11. Evidence

Retain inventory hash, export verifier report, deletion enumeration and receipts, derived-store verification, tombstone tests, backup-expiry evidence, clean-restore report, credential non-reactivation proof, RPO/RTO measurement, incident exercise, and owner promotion decision.
