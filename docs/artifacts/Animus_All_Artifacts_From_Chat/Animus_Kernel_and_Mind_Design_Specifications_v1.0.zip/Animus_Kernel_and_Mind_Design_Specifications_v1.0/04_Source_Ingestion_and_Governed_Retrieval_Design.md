# Source Ingestion and Governed Retrieval Design

**Repository:** Public kernel mechanisms; private connectors, ranking profiles, and source priorities  
**Roadmap alignment:** P4

## 1. Responsibility

This subsystem transforms external material into immutable, provenance-preserving source records and produces authorized Context Envelopes for a declared purpose. It must preserve source identity, extraction anchors, temporal meaning, contradictions, omissions, and retrieval trace.

It does not silently convert source text into accepted truth or durable memory.

## 2. Ingestion pipeline

```text
acquire -> classify -> register immutable source -> extract -> anchor
-> normalize -> derive observations/claims -> link provenance
-> index projections -> evaluate ingestion quality
```

### 2.1 Acquisition

Connectors supply bytes or content references plus acquisition metadata. Private connectors own account-specific behavior. The kernel normalizes connector output into a source-ingest command.

### 2.2 Immutable source registration

The source identity includes content hash, origin URI or opaque locator, publisher/author where known, acquisition time, publication/event times where known, media type, classification, workspace, licensing/usage metadata, connector version, and extraction status.

Repeated identical content may deduplicate bytes while preserving distinct acquisition records and provenance.

### 2.3 Extraction and anchors

Extracted units must be addressable through stable anchors such as page/region, character range, timestamp range, table cell, image region, message ID, or structured record key. Derived claims link to exact anchors. OCR or model-derived extraction records method, model/tool version, and confidence.

## 3. Claim and contradiction model

A claim is not a source. It is a proposition derived from one or more anchored source passages. Claims include subject, predicate, object/value, qualifiers, valid time, extraction confidence, source dependencies, derivation method, and epistemic status.

Contradiction links are explicit objects with relation type, affected proposition, temporal compatibility, and resolution status. The system must distinguish true contradiction from different time periods, scopes, definitions, or uncertainty ranges.

## 4. Retrieval request

```yaml
query_id: uuid
workspace_id: workspace
principal_ref: principal
purpose: architecture-review
query_text: bounded text
temporal_view:
  valid_at: timestamp-or-null
  known_at: timestamp-or-null
subject_domains: [project]
artifact_types: [source, claim, decision, lesson]
sensitivity_ceiling: confidential
required_evidence_classes: [direct_source]
include_contradictions: true
token_budget: 12000
latency_budget_ms: 5000
trace_parent: trace-id
```

## 5. Retrieval stages

1. Authenticate and authorize request.
2. Apply owner/workspace and classification filters before candidate exposure.
3. Resolve temporal perspective.
4. Generate lexical, semantic, structured, graph, and recency candidates.
5. Fuse and rerank under a versioned profile.
6. Expand provenance and contradiction neighborhoods.
7. Allocate token/evidence budget.
8. Build Context Envelope.
9. Verify citations/anchors and omission reasons.
10. Emit retrieval trace and evaluation hooks.

Private applications may provide ranking and budget strategies through public SPIs. They may not bypass pre-retrieval security filtering.

## 6. Context Envelope

The envelope contains separate sections:

- direct evidence;
- accepted memory;
- applicable knowledge;
- current intelligence;
- contradictions and dissent;
- freshness and temporal warnings;
- confidence dimensions;
- omitted-result counts and reasons;
- provenance graph references;
- retrieval profile/version;
- budget use and truncation explanation.

Evidence sections must retain artifact identity and anchors. Generated synthesis is not evidence.

## 7. Temporal retrieval

Two questions are distinct:

- What was valid in the world at time T?
- What did Animus know at transaction time K?

The request may specify either or both. Retrieval must not replace historical understanding with later corrections unless the requested perspective calls for current knowledge. Consequential decisions should preserve the exact temporal envelope used.

## 8. Leakage prevention

Security filters execute before embedding similarity, graph expansion, reranking, or prompt assembly. Unauthorized candidates must not appear in counts, scores, exception details, caches, or model context. Shared indexes require cryptographically or structurally enforced workspace partitioning; application-side filtering after retrieval is insufficient.

## 9. Failure semantics

- Unavailable required source store: return incomplete envelope with explicit failure or fail request when evidence class is mandatory.
- Index stale beyond threshold: use canonical fallback where feasible and flag staleness.
- Anchor invalid: exclude affected evidence and create repair task.
- Ranking component failure: use declared fallback profile; record degradation.
- Token budget insufficient: preserve direct evidence and contradictions before lower-priority generated context.
- Classification uncertainty: apply stricter class.
- Temporal ambiguity: do not invent time; return uncertainty.

## 10. Evaluation

Minimum labeled corpus evaluates recall@10, MRR, temporal correctness, contradiction coverage, citation/anchor validity, freshness, omission transparency, latency, and leakage. Roadmap gates are recall@10 ≥ 0.90, MRR ≥ 0.80, temporal correctness ≥ 0.98, contradiction coverage ≥ 0.95, and zero leakage.

Adversarial cases include prompt injection in sources, poisoned metadata, near-duplicate misinformation, contradictory official records, stale facts, cross-workspace similarity collisions, classification downgrades, malicious PDFs/documents, and retrieval-budget attacks.

## 11. Evidence

Retain corpus version/hash, query set, relevance judgments, ranking profile, index build identity, connector/extractor versions, temporal test report, contradiction report, leakage campaign, anchor verification report, and example redacted Context Envelopes.
