# Cross-Repository Integration Playbook

**Applies to:** Public kernel maintainers and private Animus application maintainers

## 1. Goal

Allow independent kernel releases and controlled private adoption without hidden coupling, accidental public leakage, or unsafe upgrades.

## 2. Release identities

A kernel release publishes:

- semantic version;
- immutable artifact hashes/signatures;
- public contract/schema versions;
- SPI compatibility range;
- migration requirements;
- conformance kit version;
- changelog and deprecations;
- known security/reliability limitations;
- reference evidence bundle.

A private application release records the exact kernel artifact and all private policy, prompt, adapter, migration, and evaluation versions.

## 3. Change workflow

### 3.1 Kernel change

1. Open issue/RFC and identify affected contracts.
2. Decide whether behavior is public mechanism or private cognition.
3. Update design and interface registry.
4. Add compatibility fixtures and negative tests.
5. Implement behind stable boundary.
6. Run kernel conformance/adversarial suite.
7. Test against a private application compatibility branch without importing private code into public CI artifacts.
8. Publish signed release and migration notes.

### 3.2 Private adoption

1. Pin candidate kernel artifact.
2. Run contract and SPI negotiation.
3. Apply required database/config migrations in evaluation environment.
4. Run kernel conformance suite.
5. Run private product, sovereignty, adversarial, and operational suites.
6. Replay reference traces and compare divergence.
7. Run shadow/limited promotion as risk requires.
8. Record adoption decision and rollback target.

## 4. Compatibility policy

- Patch releases cannot intentionally break public contracts.
- Minor releases may add backward-compatible fields/capabilities.
- Major releases may break with migration and deprecation process.
- Security fixes may require accelerated change but still publish explicit impact.
- Private application code may not rely on public package internals, undocumented import paths, or reference-implementation quirks.

## 5. Contract tests

The kernel publishes consumer-independent conformance tests. The private application publishes private consumer tests that exercise only public interfaces. Failures classify as:

- kernel regression;
- application misuse;
- ambiguous contract;
- unsupported compatibility;
- private behavioral regression.

Ambiguous contracts are defects and require documentation/fixture updates.

## 6. Migration

Every stateful migration defines forward path, compatibility window, rollback or restore strategy, integrity checks, expected duration, failure checkpoints, and evidence output. Dual-read/write periods are explicit and temporary. The private application never permits kernel auto-migration in general service without owner/operations control.

## 7. Rollback

Rollback is tested before promotion. It must account for schema compatibility, outbox messages, receipts, policy versions, private workflow state, and adapter contracts. When state cannot safely downgrade, recovery uses forward-fix or clean restore rather than pretending binary rollback is sufficient.

## 8. Evidence exchange

Public repository evidence contains only public fixtures and redacted environment data. Private CI imports public evidence identifiers and creates a separate private evidence bundle. Private traces, prompts, owner data, endpoint names, credentials, and proprietary metrics never enter public artifacts or issue logs.

## 9. Security publication gate

Before every public release/history rewrite/import:

- secret scan;
- private identifier and path scan;
- large-file/data scan;
- license/provenance review;
- generated artifact inspection;
- example/fixture review;
- commit-history review when content moved from private work;
- threat review for newly exposed interfaces.

## 10. Emergency security fix

A critical kernel vulnerability may be fixed under embargo. The private application pins the patched artifact, runs a reduced but mandatory critical suite, activates compensating controls if needed, and completes full evidence afterward. Urgency does not permit skipping artifact integrity, compatibility assertion, or rollback planning.

## 11. Integration readiness checklist

- exact versions pinned;
- registries updated;
- public API only;
- migrations tested;
- conformance green;
- private gates green;
- trace/replay complete;
- no leakage in artifacts;
- rollback proven;
- promotion decision recorded.
