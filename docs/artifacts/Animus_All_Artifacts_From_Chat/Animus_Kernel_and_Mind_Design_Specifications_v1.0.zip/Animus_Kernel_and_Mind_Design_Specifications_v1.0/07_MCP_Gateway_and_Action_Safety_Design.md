# MCP Gateway and Action Safety Design

**Repository:** Public kernel gateway and contracts; private connectors and account configuration  
**Roadmap alignment:** P7  
**Criticality:** Constitutional for consequential action

## 1. Responsibility

The gateway is the only permitted path from agents/workflows to external or privileged tools. It validates schema, capability, policy, approval, preconditions, risk, idempotency, isolation, and receipts. Direct agent-to-connector access is prohibited.

## 2. Tool registry

Every tool has a signed/versioned descriptor:

- tool and adapter identity/version;
- input/output schemas;
- risk class and dynamic risk rules;
- required capabilities;
- supported data classes;
- side-effect and reversibility description;
- idempotency behavior;
- approval template;
- timeout/cancellation semantics;
- network and secret requirements;
- health state;
- receipt contract.

Unknown or unregistered tool calls are denied.

## 3. Risk classes

- **R0:** public or non-sensitive read.
- **R1:** private read.
- **R2:** reversible internal write.
- **R3:** consequential or externally visible write.
- **R4:** irreversible, privileged, financial, legal, medical, identity, or destructive action.

The gateway may elevate risk dynamically based on parameters, destination, amount, audience, data class, or irreversibility. It may never downgrade below the registered minimum.

## 4. Call lifecycle

```text
received -> schema_validated -> tool_resolved -> capability_checked
-> risk_classified -> policy_decided -> preconditions_checked
-> approval_verified -> idempotency_resolved -> executing
-> succeeded | failed | uncertain | cancelled | denied
-> receipt_persisted
```

Every outcome, including denial and validation failure, produces a receipt or safety audit record.

## 5. Preconditions

Consequential actions declare machine-checkable preconditions such as current object version, account identity, destination allowlist, amount ceiling, required source freshness, owner presence, or dry-run hash. Preconditions are rechecked immediately before execution. Approval does not override failed preconditions.

## 6. Idempotency and uncertain outcomes

The normalized action hash binds tool, adapter, target, parameters, principal, purpose, and approval. Same key/same hash returns the prior receipt. Same key/different hash is denied.

If the connector times out after sending a request, the state is `uncertain`, not failed. The gateway queries provider status or reconciles before any retry. Automatic retry is forbidden when the connector cannot establish safe idempotency for a consequential effect.

## 7. Receipts

An action receipt records:

- request and normalized parameter hashes;
- tool/adapter versions;
- principal and capability references;
- policy decision and approval references;
- risk class;
- precondition results;
- start/end times;
- external side-effect identity;
- result status and sanitized response reference;
- idempotency identity;
- trace linkage;
- compensation or reversal information.

Receipts are durable and exportable but must not contain secrets.

## 8. Isolation

Third-party or high-risk adapters should run out of process or sandboxed with explicit filesystem, network, resource, and syscall restrictions. No ambient cloud credentials. Egress is allowlisted. Each adapter has an independent disable switch. Connector health cannot be inferred solely from process liveness; semantic probes are required.

## 9. Compensation

R2/R3 actions define reversal or compensation when feasible. Compensation is a new governed action with its own policy and receipt, not database rollback fiction. R4 actions must clearly disclose irreversibility.

## 10. Failure semantics

- Gateway/PDP unavailable: deny consequential action.
- Receipt persistence unavailable: do not execute R2–R4.
- Adapter health uncertain: deny or require explicit owner override under emergency policy.
- Approval mismatch/expiry: deny.
- Preconditions stale: deny and request re-evaluation.
- Sandbox violation: terminate adapter and activate adapter kill switch.
- External outcome uncertain: quarantine idempotency key pending reconciliation.
- Cancellation after side effect: record completion and stop follow-on work; cancellation cannot erase reality.

## 11. Tests

- schema smuggling and parameter coercion;
- risk-class downgrade attempts;
- approval replay and parameter substitution;
- duplicate delivery and timeout-after-send;
- connector lies about idempotency;
- direct connector import/network bypass;
- secret leakage in errors;
- egress allowlist escape;
- cancellation races;
- kill switch during execution;
- compensation failure;
- receipt tampering.

Exit gates: zero unauthorized R3/R4 actions, zero duplicate consequential side effects, a receipt for every call, and no direct agent–connector path.

## 12. Evidence

Retain registry hash, adapter conformance reports, risk classification fixtures, approval/precondition campaign, duplicate-effect report, uncertain-outcome reconciliation cases, sandbox/egress tests, kill-switch exercise, and complete redacted receipt set for reference workflows.
