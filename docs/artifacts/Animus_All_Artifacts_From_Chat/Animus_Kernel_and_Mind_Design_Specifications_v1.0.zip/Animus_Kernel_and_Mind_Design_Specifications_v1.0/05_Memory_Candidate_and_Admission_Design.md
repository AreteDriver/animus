# Memory Candidate and Admission Design

**Repository:** Public kernel mechanism; private memory policy, owner preferences, and significance models  
**Roadmap alignment:** P5  
**Criticality:** Sovereignty and identity

## 1. Responsibility

Memory admission converts a proposal into an accepted canonical memory only after duplicate, contradiction, provenance, temporal, sensitivity, policy, and approval checks. Models and private workflows may propose; only the governed admission pipeline may commit.

## 2. Candidate origins

- explicit owner request;
- extracted event or fact;
- repeated interaction pattern;
- decision/outcome/lesson workflow;
- correction to active memory;
- import or migration;
- system operational learning.

Origin influences confidence and approval but does not bypass validation.

## 3. Candidate state machine

```text
proposed -> normalized -> duplicate_checked -> contradiction_checked
-> policy_evaluated -> awaiting_approval | admissible | rejected
-> committing -> admitted | commit_failed
```

Independent fields track workflow, epistemic, lifecycle, and storage states. “Approved” is not evidence status; “supported” is not owner approval.

## 4. Candidate contract

A candidate includes:

- proposed content and artifact type;
- subject domain and cognitive role;
- owner/workspace;
- valid-time assertion;
- provenance and source anchors;
- confidence dimensions;
- sensitivity/classification;
- proposed retention and storage tier;
- significance rationale;
- duplicate/contradiction references;
- proposer identity and model/prompt lineage when applicable;
- required approval class;
- trace parent.

## 5. Duplicate detection

Duplicate evaluation uses exact identity, normalized semantic representation, entity/time overlap, and provenance similarity. Results are:

- exact duplicate — reject or link observation;
- semantic duplicate — merge proposal or request review;
- compatible refinement — create new version or linked memory;
- distinct event/fact — continue;
- uncertain — require review for consequential memory.

The system must not collapse distinct repeated events into one memory merely because wording is similar.

## 6. Contradiction handling

Candidate admission searches active and historically relevant memories. A contradiction does not automatically reject. The system may:

- admit as disputed and link contradiction;
- supersede earlier memory with correction while preserving history;
- restrict use until owner review;
- reject unsupported candidate;
- represent temporal change as two compatible valid-time intervals.

Silent overwrite is prohibited.

## 7. Approval policy

Consequential memory includes identity, health, legal, financial, relationship, values, enduring preference, or other state likely to shape future high-impact behavior. Such memory requires explicit or previously defined narrow owner policy. The owner must be able to inspect source, proposed wording, scope, expected use, retention, and contradictory records.

Low-risk operational memories may be admitted under standing policy when provenance and confidence thresholds pass. Standing policy remains revocable.

## 8. Atomic commit

The admission service submits one durable-core transaction intent containing:

- candidate decision;
- admitted memory object/version;
- candidate lifecycle update;
- contradiction/duplicate links;
- approval reference;
- event(s);
- outbox updates for indexes and evaluations.

Partial admission is impossible. Post-commit verification confirms projection and index convergence.

## 9. Correction, forgetting, and deletion

- Correction creates a new version and may supersede prior content.
- Forgetting reduces retrieval eligibility or moves storage tier but is not deletion.
- Owner-requested deletion invokes the deletion subsystem and propagates to derived stores.
- Legal or safety retention conflicts must be disclosed and governed by explicit policy.
- A deleted memory must not be recreated automatically from cached generated views, old indexes, or restored backups.

## 10. Retrieval use constraints

Accepted memory includes allowed purposes, classification, temporal scope, and confidence. Memory cannot be treated as universally applicable. Context assembly must surface stale, disputed, superseded, and owner-corrected status.

## 11. Failure semantics

- Missing provenance for required class: reject or await evidence.
- Duplicate service unavailable: do not admit consequential candidate.
- Contradiction search degraded: block high-impact admission or require owner review.
- Approval expired/revoked: deny commit.
- Index update fails after commit: retain canonical memory, retry from outbox, mark retrieval lag.
- Candidate model output malformed: reject without repair-by-assumption.
- Policy ambiguity: choose stricter review path.

## 12. Evaluation and adversarial proof

Roadmap gates: accepted-memory precision ≥ 0.95, duplicate commit rate ≤ 0.02, contradiction recall ≥ 0.90, and zero unapproved consequential memory.

Test cases cover repeated wording, evolving preferences, abusive or coercive claims, hallucinated personal facts, indirect sensitive inference, stale health/legal data, prompt injection asking the model to “remember permanently,” owner correction, deletion resurrection, and migration conflicts.

## 13. Evidence

Retain labeled candidate corpus, admission policy hash, duplicate/contradiction metrics, consequential-memory approval audit, atomicity fault report, correction/deletion cases, index convergence report, and sample owner-review receipts with private content redacted.
