# Composition Root, Configuration, and Environment Design

**Repository:** Private application, consuming public kernel SPIs  
**Status:** Normative integration design

## 1. Responsibility

The composition root is the only location that selects concrete adapters, policy profiles, stores, providers, evaluators, workflows, and application services. It makes all authority and dependency choices visible and testable.

## 2. Prohibited patterns

- import-time global registration;
- hidden service locators;
- singleton credentials;
- environment-variable access scattered across modules;
- runtime monkey-patching of kernel internals;
- direct construction of connectors inside agents;
- configuration that disables constitutional invariants;
- fallback to a less secure provider or store without explicit policy.

## 3. Configuration layers

From lowest to highest precedence:

1. public kernel defaults that are safe and application-neutral;
2. private application defaults;
3. environment profile;
4. workspace policy/profile;
5. owner-approved runtime preference;
6. emergency/incident override with audit and expiry.

Higher layers may narrow behavior. Any widening of authority requires explicit validation and, when consequential, owner approval.

## 4. Configuration classes

- **Public configuration:** non-sensitive feature and algorithm settings.
- **Private configuration:** product policies, prompts, priorities, topology.
- **Secret references:** identifiers resolved only by the secret broker.
- **Dynamic policy state:** signed, versioned, revocable.
- **Release-locked configuration:** hash-pinned to a promoted release.

Unknown fields fail validation. Critical configuration is schema-valid and semantically validated before startup.

## 5. Startup sequence

1. Load release manifest and verify signature/hash.
2. Validate kernel version and required contract/SPI versions.
3. Validate configuration schemas and prohibited combinations.
4. Initialize identity, keys, and secret references.
5. Initialize durable core and verify migrations/reconciliation.
6. Load signed policy bundles and kill-switch state.
7. Register adapters from manifests; verify capabilities and isolation.
8. Initialize trace/evidence path.
9. Initialize retrieval, memory, agent, gateway, and evaluation modules.
10. Register private workflows and faculties.
11. Run health and conformance probes.
12. Enter declared service mode: normal, degraded, read-only, or maintenance.

Startup fails closed when required safety compatibility or state integrity is unverifiable.

## 6. Dependency injection

All dependencies use explicit constructors/factories. Interfaces are passed as bounded capabilities rather than broad containers. Agents receive runtime handles, not database or connector clients. Test composition can replace adapters with deterministic fakes without altering product code.

## 7. Environment profiles

Recommended profiles:

- development;
- evaluation;
- shadow;
- limited;
- general;
- disaster recovery;
- offline/local-only.

Each profile declares allowed providers, external side effects, data classes, retention, observability, evaluation gates, and owner approval expectations. “Development” is not permission to use production owner data casually.

## 8. Feature and capability activation

Feature flags control presentation or routing, not invariant enforcement. A capability becomes active only when contract compatibility, policy, adapter health, required gates, and release manifest all agree. Flags cannot bypass approval, tracing, deletion, or receipts.

## 9. Health model

Health is structured by dependency and capability:

- alive;
- ready for read;
- ready for canonical write;
- ready for model execution;
- ready for R0/R1 tools;
- ready for R2;
- ready for R3/R4;
- degraded reason and expiry.

A single green process status is insufficient.

## 10. Configuration changes

Changes are proposed, validated, tested, approved where required, applied atomically or through a staged rollout, and recorded in the release/evidence manifest. Critical changes support rollback. Dynamic changes that alter policy or authority increment a configuration epoch and invalidate stale cached decisions.

## 11. Tests and evidence

Test missing/unknown fields, incompatible kernel versions, unsafe combinations, unavailable secret broker, stale policy signatures, adapter capability mismatch, migration drift, kill-switch persistence, partial startup, configuration rollback, and environment-profile side-effect isolation.

Retain startup compatibility report, configuration hashes, adapter manifest set, health probe results, environment manifest, capability activation matrix, and approved deviations.
