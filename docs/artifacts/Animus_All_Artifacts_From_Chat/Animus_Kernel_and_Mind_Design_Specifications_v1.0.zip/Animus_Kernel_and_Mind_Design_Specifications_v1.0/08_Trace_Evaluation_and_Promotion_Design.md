# Trace, Evaluation, and Promotion Design

**Repository:** Public kernel mechanisms; private product scorers and corpora  
**Roadmap alignment:** P8

## 1. Responsibility

This subsystem makes consequential behavior inspectable and gates promotion on retained evidence. It links source, retrieval, prompts, models, agents, policy, tools, writes, outcomes, and evaluations without exposing restricted payloads by default.

## 2. Trace model

A trace is a causally linked graph of spans and events. Required span categories:

- request/session;
- retrieval and Context Envelope;
- model/provider call;
- agent and delegation;
- policy decision and approval;
- tool gateway and connector;
- canonical transaction and outbox;
- evaluation/gate;
- export/deletion/recovery operation.

Each span records identity/version, timestamps, parent/links, status, classification, redaction profile, input/output hashes or references, cost/resource usage, and safety-relevant reason codes.

## 3. Redaction and payload handling

Raw sensitive prompts, sources, secrets, and owner data are not required in general telemetry. Traces use hashes, encrypted evidence references, structured summaries, and approved redaction. Debug capture is explicit, time-bounded, workspace-scoped, and audited. Secret values are never captured.

## 4. Trace completeness

A consequential operation is trace-complete when an auditor can traverse from owner/system request through context, model/agent reasoning artifacts, policy/approval, tool or canonical write, and final receipt/outcome. Missing required links are critical defects.

## 5. Replay

Replay modes:

- **deterministic infrastructure replay:** events, policy decisions, transactions, and workers;
- **recorded model replay:** use captured structured model outputs to test orchestration;
- **live model re-execution:** compare behavior under declared nondeterminism;
- **policy replay:** evaluate historical request under original and candidate policy;
- **projection rebuild:** reconstruct read models from canonical state.

Replay never re-executes external side effects unless explicitly run in a safe simulator.

## 6. Evaluation architecture

Evaluation assets are versioned:

- corpus/fixture identity;
- runner and environment;
- scorer identity/version;
- thresholds;
- criticality and aggregation rule;
- expected evidence outputs;
- waiver policy.

Evaluation layers remain separate: contract correctness, safety/adversarial, product quality, owner sovereignty, and operational proof. Catastrophic failures cannot be averaged away by high mean scores.

## 7. Gate model

A gate result is `pass`, `fail`, `error`, or `not_run`. Critical gate `fail`, `error`, or `not_run` blocks promotion unless the gate definition explicitly permits not-applicable status. Waivers are scoped, expiring, owner/maintainer approved, and preserved in evidence.

Promotion stages:

`development -> evaluation -> shadow -> limited -> general`

Promotion state is a durable object with exact artifact hashes and environment. Rollback creates a new decision event.

## 8. Promotion controller

The controller:

1. resolves candidate release manifest;
2. verifies artifact provenance and signatures;
3. resolves required gates by capability/risk;
4. executes or imports verifiable gate results;
5. checks evidence completeness and freshness;
6. blocks on critical failures or unexplained divergence;
7. records promotion recommendation;
8. requires owner/authorized release decision where defined;
9. activates only the approved artifact set.

It cannot be bypassed by deployment scripts or configuration flags.

## 9. Failure semantics

- Trace sink unavailable: buffer within bounded secure capacity; block consequential workflows when completeness cannot be guaranteed.
- Evidence hash mismatch: fail gate and open incident.
- Scorer error: gate error, not pass.
- Stale corpus/result: not run for current release.
- Replay divergence: block when unexplained and safety-relevant.
- Promotion service unavailable: current approved release remains; no implicit promotion.
- Telemetry exporter failure: enforcement remains active; observability degrades visibly.

## 10. Adversarial proof

Test trace deletion, span forgery, correlation collision, redaction failure, secret capture, gate-result tampering, stale-result reuse, deployment bypass, metric averaging, evaluator prompt injection, non-independent test data, and replay that accidentally triggers tools.

Exit gates include 100% consequential trace completeness, 100% reference trace reproduction, automatic blocking by critical gates, and matching evidence hashes.

## 11. Evidence bundle

The release bundle contains source/build provenance, contract/policy/migration/environment manifests, requirement report, validation results, integration/adversarial/fault tests, retrieval/memory/agent/action evaluations, trace audit, replay, export/deletion/restore reports, SLO snapshot, gate results, deviations, and promotion decision.
