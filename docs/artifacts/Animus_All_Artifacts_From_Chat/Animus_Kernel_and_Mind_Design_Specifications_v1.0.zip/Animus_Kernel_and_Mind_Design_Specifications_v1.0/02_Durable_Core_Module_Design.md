# Durable Core Module Design

**Repository:** Public kernel  
**Roadmap alignment:** P1–P2  
**Criticality:** Constitutional

## 1. Responsibility

The durable core is the sole authority for canonical object identity, immutable event history, current projections, transactionally coupled outbox work, idempotent mutation, and deterministic reconstruction. It does not decide product policy, memory worthiness, retrieval relevance, or cognitive meaning. Those decisions arrive as validated commands and policy evidence.

## 2. Components

### 2.1 Object registry

Stores stable object identity and immutable versions. Required fields include object ID, version, schema ID/version, owner, workspace, context coordinates, sensitivity, valid-time interval, transaction-time interval, provenance, lifecycle state, integrity hash, and payload reference or encrypted payload.

### 2.2 Event ledger

Append-only record of accepted transitions and safety-relevant denials. Ledger events include causation ID, correlation/trace ID, command ID, principal, policy decision reference, approval reference when required, prior version, resulting version, event type, event time, integrity hash, and redacted metadata.

### 2.3 Current projection

Optimized authoritative read pointer to the latest active version. It is transactionally updated with the ledger and version record. Search, vector, graph, and generated views are not current projections in this sense; they are rebuildable secondary projections.

### 2.4 Transactional outbox

Stores downstream work in the same transaction as accepted canonical state. Each row has event ID, effect type, payload reference, destination class, idempotency key, attempts, next-attempt time, state, and terminal error when dead-lettered.

### 2.5 Reconciliation engine

Detects divergence among ledger, versions, current projection, outbox, and derived indexes. It repairs rebuildable state, quarantines unexplained canonical divergence, and produces signed reconciliation evidence.

## 3. Command contract

A mutation command must contain:

```yaml
command_id: uuid
command_type: canonical_object.mutate.v1
idempotency_key: opaque-stable-key
principal_ref: principal-id
owner_id: owner-id
workspace_id: workspace-id
purpose: bounded-purpose
expected_object_version: 7
schema_ref: claim.v1
policy_decision_ref: decision-id
approval_receipt_ref: null
valid_time:
  from: timestamp
  to: null
payload_ref: encrypted-or-inline-reference
trace_parent: trace-id
```

The core rejects missing identity, undefined schema, invalid semantics, stale expected version, mismatched workspace, invalid approval linkage, or reused idempotency keys with non-equivalent commands.

## 4. Transaction algorithm

1. Begin serializable or equivalently safe transaction.
2. Acquire object/version guard.
3. Resolve idempotency key.
4. Validate schema and semantic invariants.
5. Verify policy decision and approval scope have not expired or been revoked.
6. Verify expected version and temporal constraints.
7. Append object version.
8. Append ledger event.
9. Update current projection.
10. Append all required outbox rows.
11. Commit.
12. Return commit receipt containing hashes and identifiers.

Any failure before commit leaves no accepted state. Client uncertainty after commit is resolved by command ID or idempotency lookup, never by blind retry.

## 5. State rules

- Object versions are immutable.
- Corrections create a new version and preserve historical transaction time.
- `deleted` is a lifecycle state plus content-removal workflow, not a direct row deletion shortcut.
- A generated view cannot be mutated into canonical state; it must become a new proposal command.
- Contradictory objects may coexist when linked and classified correctly.
- Valid-time overlap rules are artifact-specific and enforced by semantic validators.

## 6. Concurrency and idempotency

Optimistic concurrency is the default through expected version. High-contention aggregates may use advisory or row locks. Idempotency records bind `(workspace, command_type, idempotency_key)` to the normalized command hash and outcome. Same key/same hash returns the original result. Same key/different hash is a conflict and security-relevant event.

Workers claim outbox records with leases. A delivery may occur more than once; a consequential effect may not. Every consumer must use the event/effect idempotency identity.

## 7. Failure semantics

| Failure | Response |
|---|---|
| Schema or semantic invalidity | Reject; no write; validation receipt |
| Stale version | Conflict; return current version metadata |
| Policy/approval invalid | Deny; no write; audit event |
| Database interruption before commit | Roll back completely |
| Client timeout after possible commit | Require idempotency lookup |
| Projection divergence | Quarantine affected object; rebuild from ledger/version history |
| Ledger/version mismatch | Critical incident; stop canonical mutation path |
| Outbox backlog | Continue canonical writes only within configured safety threshold; otherwise degrade/stop |
| Hash mismatch | Quarantine and trigger integrity incident |

## 8. Security

- Workspace and owner filters are mandatory predicates, not optional query parameters.
- Payload encryption is separate from index metadata.
- Database roles separate mutation, projection worker, reconciliation, and read-only access.
- No service receives unrestricted cross-workspace query capability unless explicitly designated for deletion/export/recovery and independently approved.
- Ledger metadata must avoid secret or restricted payload leakage.

## 9. Observability

Required metrics include transaction latency, conflict rate, idempotent replay rate, rollback count, outbox age, dead-letter count, projection lag, reconciliation divergence, hash failure, and canonical mutation availability. Every mutation span records command type, schema version, object type, workspace pseudonym, policy outcome, and commit receipt reference without raw restricted content.

## 10. Test and evidence obligations

Required tests:

- positive and negative schema fixtures;
- semantic-invalid but schema-valid fixtures;
- concurrent update races;
- duplicate command and duplicate delivery;
- injected failure after each transaction step;
- projection rebuild from canonical state;
- outbox crash/restart and lease expiry;
- integrity corruption detection;
- workspace leakage attempts;
- deletion tombstone interaction;
- restore and reconciliation on clean infrastructure.

Promotion evidence includes migration hash, schema manifest, transaction fault report, idempotency report, rebuild report, reconciliation report, performance/SLO snapshot, and unresolved deviation list.

## 11. Explicit non-responsibilities

The durable core does not choose what to remember, determine source credibility, call models, execute tools, infer owner intent, or resolve contradictions. It guarantees that an accepted decision is recorded correctly and reproducibly.
