# Animus Kernel and Mind Design Specifications

**Version:** 1.0.0  
**Status:** Proposed normative implementation-design companion  
**Effective date:** June 17, 2026  
**Applies to:** Public kernel repository and private Animus application repository  
**Depends on:** Animus Mind Charter v1, Animus v2.1 Executable Baseline, Animus v2.2 Implementation Roadmap, and Repository Split Documentation Pack v1.0

## 1. Purpose

This package converts the established Animus architecture into module-level implementation designs. It does not redefine the constitutional model or repeat the repository-split rules. It answers the engineering questions that remain after those documents:

- What does each module own?
- Which interfaces cross module and repository boundaries?
- Which state transitions are legal?
- What must happen atomically?
- How does each module fail closed?
- What telemetry, tests, adversarial proof, and retained evidence are required?
- Which mechanisms belong in the public kernel, and which cognitive composition remains private?

## 2. Authority order

1. Animus Mind Charter v1.
2. Animus v2.1 Executable Baseline and its machine-readable contracts.
3. Accepted ADRs.
4. Repository Split Documentation Pack v1.0.
5. This design package.
6. Repository-local implementation notes.

A lower document may specialize but may not weaken a higher-level invariant.

## 3. Design rule

> Public kernel modules provide deterministic, governed mechanisms. The private Animus application selects, composes, configures, evaluates, and applies those mechanisms as a Mind.

Prompts, private workflow graphs, owner models, personal memory policy, intelligence priorities, worldview construction, and product behavior remain private. Schemas, lifecycle enforcement, policy hooks, tracing, receipts, extension interfaces, and conformance mechanisms may be public when they are reusable and free of private assumptions.

## 4. Package map

| Document | Scope |
|---|---|
| `01_Design_Authority_and_Module_Map.md` | System decomposition, ownership, dependency order, and design completeness |
| `02_Durable_Core_Module_Design.md` | Object registry, event ledger, projection, outbox, idempotency, reconciliation |
| `03_Identity_Policy_Keys_and_Kill_Switch_Design.md` | Principals, capabilities, PDP/PEP, approvals, secret broker, key isolation, revocation |
| `04_Source_Ingestion_and_Governed_Retrieval_Design.md` | Immutable sources, extraction, claims, contradictions, retrieval, Context Envelopes |
| `05_Memory_Candidate_and_Admission_Design.md` | Candidate lifecycle, duplicate/contradiction checks, approval, commit, correction, deletion |
| `06_Agent_Runtime_and_Intelligence_Workflow_Design.md` | Agent contracts, budgets, delegation, dissent, evidence graphs, synthesis |
| `07_MCP_Gateway_and_Action_Safety_Design.md` | Tool registry, risk classes, preconditions, approvals, idempotency, receipts, isolation |
| `08_Trace_Evaluation_and_Promotion_Design.md` | End-to-end trace, replay, gates, promotion controller, evidence retention |
| `09_Export_Deletion_Recovery_and_Incident_Design.md` | Export, deletion, tombstones, backup, restore, recovery, incident control |
| `10_Private_Mind_Composition_and_Faculty_Design.md` | Private faculty composition, owner authority, reflective loops, product behavior |
| `11_World_Model_Pattern_and_Scenario_Engine_Design.md` | World-state representation, signal fusion, patterns, hypotheses, forecasts, scenarios |
| `12_Composition_Root_Configuration_and_Environment_Design.md` | Explicit assembly, configuration layering, capability registration, startup assertions |
| `13_Cross_Repository_Integration_Playbook.md` | Kernel release consumption, compatibility testing, migration, rollback, evidence exchange |
| `14_Design_Review_and_Implementation_Readiness_Checklist.md` | Review gates before code, integration, promotion, and public release |
| `adrs/ADR-017_contract_first_module_boundaries.md` | Contract-first module boundaries and anti-corruption layers |
| `adrs/ADR-018_private_cognition_public_mechanism.md` | Public mechanism/private cognition decision |
| `registries/module_design_registry.yaml` | Machine-readable module ownership and required artifacts |
| `registries/interface_catalog.yaml` | Machine-readable interface inventory and stability levels |
| `registries/failure_mode_registry.yaml` | Critical failure modes and mandated responses |
| `templates/module_design_template.md` | Standard structure for future module specifications |
| `templates/interface_contract_template.yaml` | Standard interface contract template |

## 5. Required use

Before a module enters implementation, its design entry must identify:

- authority and owner;
- public/private placement;
- inputs, outputs, and durable state;
- legal transitions and atomicity boundaries;
- authorization and data-classification behavior;
- error taxonomy and fail-closed behavior;
- observability and SLOs;
- unit, contract, integration, fault, adversarial, and recovery tests;
- evidence artifacts required for promotion.

A module is not implementation-ready when any critical interface, state transition, policy decision, or evidence obligation remains implicit.

## 6. Completion criterion

This package is successfully adopted when the registries are checked in CI, every implemented module points to its governing design, cross-repository interfaces have conformance tests, and a release cannot be promoted with undocumented critical behavior.
