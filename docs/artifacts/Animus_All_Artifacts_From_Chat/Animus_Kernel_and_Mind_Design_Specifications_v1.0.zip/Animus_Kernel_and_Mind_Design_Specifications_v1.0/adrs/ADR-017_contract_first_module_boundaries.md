# ADR-017: Contract-First Module Boundaries

**Status:** Accepted  
**Date:** June 17, 2026  
**Scope:** Public kernel and private application integration

## Context

Animus combines canonical state, policy, retrieval, memory, agents, tools, evaluation, private cognition, and
owner-facing behavior. Direct imports, ambient dictionaries, shared database writes, and undocumented callbacks
would allow modules to bypass policy, tracing, receipts, compatibility review, and the public/private boundary.

## Decision

Every cross-module and cross-repository boundary is contract-first and uses a registered contract class:
canonical object, command, query, event, receipt, extension, or evaluation.

Contracts are versioned before implementations depend on them. Providers and consumers use anti-corruption
layers when their internal models differ. Only the durable core composes canonical database transactions.
Circular dependencies use registered interfaces or events rather than direct imports.

## Required controls

- interface identity and semantic version;
- provider and consumer ownership;
- structural and semantic validation;
- typed failure taxonomy;
- compatibility and negative tests;
- trace propagation;
- publication review.

## Consequences

This increases contract and adapter work, but preserves independent testing, migration discipline,
public/private separation, and durable governance.

## Rejected alternatives

- Unversioned shared dictionaries.
- Cross-module direct canonical writes.
- Public-kernel imports of private application code.
- Private callbacks discovered by public runtime reflection.

## Verification

Verify the module registry, interface catalog, dependency graph, contract fixtures, repository boundary scans,
and cross-repository conformance tests.
