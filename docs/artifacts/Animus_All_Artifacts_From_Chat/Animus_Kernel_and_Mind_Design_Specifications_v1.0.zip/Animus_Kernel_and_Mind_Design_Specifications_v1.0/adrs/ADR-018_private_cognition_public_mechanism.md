# ADR-018: Private Cognition, Public Mechanism

**Status:** Accepted  
**Date:** June 17, 2026

## Context

Animus needs reusable governance mechanisms and deeply owner-specific cognition. Publishing too much would expose
prompts, owner models, intelligence priorities, workflow graphs, product behavior, and sensitive topology.
Publishing too little would leave no reusable governed kernel.

## Decision

The public kernel contains application-neutral mechanisms: contracts, semantic validation, durable state,
identity and capabilities, policy hooks, source registration, governed retrieval, memory admission, agent-runtime
controls, typed intelligence stages, tool safety, tracing, evaluation, promotion, export, deletion, and recovery.

The private application contains prompts, workflow graphs, owner models, faculty orchestration, personal memory
policy, world-model priorities, provider strategy beyond public hooks, private evaluation assets, notifications,
and product behavior.

Private code depends only on documented public contracts. Public code never imports, identifies, requires, or
infers private implementation.

## Placement test

A component is public only when it is application-neutral, independently usable, documentable without private
data or prompts, conformance-tested, and safe to publish. Otherwise it remains private.

## Consequences

The kernel remains reusable while the Mind can evolve privately. Composition and anti-corruption layers become
mandatory, and premature public extraction is avoided.

## Verification

Use repository dependency scans, publication review, interface conformance, package inspection, and adversarial
public-to-private import tests.
