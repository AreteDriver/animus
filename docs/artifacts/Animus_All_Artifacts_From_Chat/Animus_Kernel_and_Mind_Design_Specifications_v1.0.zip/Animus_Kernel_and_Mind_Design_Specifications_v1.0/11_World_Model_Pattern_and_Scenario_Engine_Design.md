# World Model, Pattern Detection, and Scenario Engine Design

**Repository:** Private application for models, priorities, and analysis; public kernel for typed intelligence objects and evidence contracts  
**Status:** Proprietary system design

## 1. Purpose

This subsystem enables Animus to analyze the physical, institutional, economic, technological, and personal world as changing state rather than as a stream of disconnected documents. It supports the intelligence-swarm goal: detect meaningful patterns, explain competing causes, generate scenarios, score forecasts, and connect outcomes to decisions.

## 2. World model layers

### 2.1 Entity layer

People, organizations, governments, markets, technologies, places, assets, projects, policies, and concepts. Entities have stable identity, aliases, provenance, validity intervals, and confidence.

### 2.2 State layer

Time-indexed properties and relationships: office-holder, ownership, price, capacity, location, health/status, policy state, supply, demand, sentiment, risk, and constraints. State is bitemporal.

### 2.3 Event layer

Observed changes with actors, action, target, time, location, source, and consequence. Events may be disputed or partially observed.

### 2.4 Mechanism layer

Candidate causal structures: incentives, feedback loops, bottlenecks, institutional rules, network effects, resource constraints, strategic behavior, and physical dependencies.

### 2.5 Scenario layer

Alternative coherent future states with assumptions, branching events, indicators, probabilities/ranges, impacts, and resolution rules.

## 3. Data flow

```text
sources -> observations -> normalized events/state updates
-> signals -> candidate patterns -> competing hypotheses
-> assessed mechanisms -> forecasts/scenarios
-> decisions/watchlists -> outcomes -> calibration/lessons
```

No stage is promoted solely because multiple agents repeat it. Evidence independence is computed from origin and derivation graphs.

## 4. Signal detection

Signals are bounded observations that may indicate change. Detection methods may include:

- threshold and rate-of-change rules;
- anomaly detection;
- cross-source corroboration;
- topic/entity emergence;
- relationship or network change;
- temporal sequence detection;
- regime-change models;
- model-assisted semantic extraction.

Each signal records baseline, deviation, time window, source dependencies, sensitivity to missing data, and false-positive risks.

## 5. Pattern formation

A pattern requires repeated, related, or structurally coherent signals. Pattern objects include:

- definition and scope;
- supporting and contradicting signals;
- start/time window;
- recurrence or persistence;
- proposed mechanism(s);
- confidence dimensions;
- alternative interpretations;
- leading/lagging indicators;
- invalidation conditions.

Pattern confidence must fall when supporting observations share a hidden common source or extraction path.

## 6. Hypothesis competition

The engine should maintain multiple explanations until evidence differentiates them. Each hypothesis declares predictions, required evidence, disconfirming evidence, assumptions, and dependency graph. Critic agents actively search for rival explanations, base-rate neglect, selection bias, and temporal confusion.

## 7. Scenario generation

Scenarios are not predictions dressed as stories. A scenario contains:

- baseline/current state;
- driving forces;
- critical uncertainties;
- branch points;
- actor incentives and constraints;
- path-dependent events;
- time horizon;
- probability or plausibility range;
- impact by owner-relevant domain;
- leading indicators and tripwires;
- owner options and reversible preparations;
- resolution/scoring rule.

The engine should produce at least a base case, meaningful upside, meaningful downside, and a structurally different alternative when uncertainty is material.

## 8. Forecast calibration

Forecasts become first-class records. At resolution, the system records outcome, scoring method such as Brier/log score where suitable, timing error, assumption failures, source performance, and analyst/agent calibration. Lessons update model selection and workflows through governed change—not by rewriting old forecasts.

## 9. Owner relevance

Private priorities map world state to owner goals, projects, risks, and opportunities. This layer is explicitly separate from factual assessment. The system should be able to say:

- what appears to be happening;
- why it might be happening;
- what could happen next;
- what evidence would change the view;
- why it matters to the owner;
- which actions are available and reversible.

## 10. Swarm architecture

Suggested private roles:

- source scouts by domain;
- entity/event normalizer;
- data-quality critic;
- pattern detector;
- causal-hypothesis analyst;
- adversarial/red-team analyst;
- scenario generator;
- forecaster/calibrator;
- owner-relevance analyst;
- synthesizer.

All roles operate through the public agent/runtime, retrieval, evidence, and trace contracts.

## 11. Guardrails

- Preserve political and analytical pluralism where evidence permits.
- Separate facts from forecasts and values.
- Avoid treating social-media volume as population truth.
- Record data gaps and collection bias.
- Do not infer sensitive personal attributes without purpose and policy.
- Do not convert scenario fear into coercive recommendation.
- Do not automate financial, legal, medical, or civic action without applicable high-risk controls.

## 12. Evaluation

Evaluate event extraction accuracy, entity resolution, temporal correctness, signal precision/recall, pattern usefulness, contradiction capture, hypothesis diversity, evidence independence, forecast calibration, scenario distinctness, indicator timeliness, and owner relevance.

Backtesting must avoid look-ahead leakage. Historical evaluation freezes the information available at each transaction time.

## 13. Operational products

- evolving world-state briefs;
- pattern dossiers;
- hypothesis boards;
- scenario sets;
- forecast register and calibration dashboard;
- owner watchlists and tripwires;
- decision/outcome/lesson reviews.

These are generated views over canonical intelligence objects and are never silently written back as truth.
