# Animus v2.2 Complete Package Index

**Updated:** 2026-06-18T04:33:28.864073+00:00

## Individual packages

| Order | Package | Purpose | Files | Bytes | SHA-256 |
|---:|---|---|---:|---:|---|
| 1 | `Animus_Repository_Split_Documentation_Pack_v1.0.zip` | Repository boundary and public/private separation | 15 | 30992 | `1f873b9ddd8654ef33afd0c231871056d1872057470a7598c90d6679532c6ffe` |
| 2 | `Animus_Kernel_and_Mind_Design_Specifications_v1.0.zip` | Kernel modules, private Mind composition, and design authority | 24 | 53720 | `f4ff425e7cc8cdf349dacceff6dc9569a1d4c04c8f3634b32195189cc4072f25` |
| 3 | `Animus_Executable_Contracts_and_Protocol_Pack_v1.0.zip` | OpenAPI, AsyncAPI, schemas, state machines, and validators | 56 | 56436 | `a54d6fcf33d23d186d0005e43483b2ebb0aafe2a7fe7e214fcfa383073cf6ce3` |
| 4 | `Animus_Operational_Implementation_and_Production_Readiness_Pack_v1.0.zip` | Topology, SLOs, observability, incidents, recovery, and PRR | 43 | 42110 | `b9c1de34c3032ab00d2de4166c3e1d511dee20e881abc3549990afae049dd196` |
| 5 | `Animus_Developer_Implementation_and_Contribution_Pack_v1.0.zip` | Repository layout, coding standards, CI/CD, and contribution process | 56 | 42981 | `a264fdc08be7568c0ebf11a9f31d667a503dadafab670056b9ed12cb8367aa16` |
| 6 | `Animus_Human_Facing_Mind_Operating_Model_v1.0.zip` | Relationship charter, trust, autonomy, disagreement, and owner controls | 58 | 55516 | `b211b36cbac8460fb014915be334fbd15b77cd572ee31b72ac4d81ff0fa9a716` |
| 7 | `Animus_Product_Experience_and_Control_Surface_Specification_v1.0.zip` | Owner-facing product, memory, delegation, trust, and audit experiences | 73 | 54754 | `b113c750a9d35cbaf98fde595b05a2006550947f9b061e5c7c56c7d04c59608f` |
| 8 | `Animus_Frontend_Implementation_Architecture_and_Prototype_v1.0.zip` | Frontend application architecture and executable prototype | 81 | 64680 | `78a68634673c45286d43097eed7673d25a82fb56bf353f1b24e858ca1dbfb2f9` |
| 9 | `Animus_Kernel_to_Product_Integration_and_Vertical_Slice_v1.0.zip` | BFF, integration contracts, and reference vertical slice | 105 | 101590 | `8d9a5eb1b747cb27d1f780af66b12e59914fa15a7b5934039c553f4894227853` |
| 10 | `Animus_Private_Mind_Cognition_Runtime_and_Intelligence_Swarm_v1.0.zip` | Private cognition, faculties, swarm orchestration, and provider routing | 116 | 108809 | `c207746002b72a2614981b70e687c781041f14a7a80146fd196f29339bf9b363` |
| 11 | `Animus_World_Intelligence_Data_Plane_and_Temporal_Knowledge_Graph_v1.0.zip` | Source ingestion, lineage, temporal graph, signals, patterns, and scenarios | 154 | 136055 | `7455cee3b6ca822a4c6e440ff916df930a482471a67973e47d5221931246bea8` |
| 12 | `Animus_Personal_Context_and_Life_Operations_Plane_v1.0.zip` | Commitments, projects, relationships, health, finance, and life decisions | 165 | 126097 | `112e20f992d8b7f379c502898e9d5c8e83a5a5b6c3a79b9f7f07aab6e794179e` |
| 13 | `Animus_Personal_Integration_and_Automation_Adapter_Plane_v1.0.zip` | Personal-service adapters, credentials, sync, writes, and reconciliation | 172 | 137973 | `4175528b28f15520e0e57c09c51fab3b0fc5b50e700e1040621d56e02a6cf653` |
| 14 | `Animus_Whole_System_Security_Privacy_and_Adversarial_Assurance_Plane_v1.0.zip` | Zero trust, privacy, prompt injection, DLP, red team, and containment | 171 | 154731 | `cc761ddb50fa1e66d76df9581d8a639f6e005cd5352b885077be4ce25f94ca28` |
| 15 | `Animus_Whole_System_Integration_Acceptance_and_Release_Plane_v1.0.zip` | Whole-system integration, acceptance, commissioning, and release | 118 | 106283 | `46f6e50fa8f64be5722c3c529a13db1e4dd01ecc7517c5422c50caefc3991976` |

## P02 repair

P02 was repaired from an empty 22-byte archive. The repaired package contains 24 files, including the fourteen design specifications, two ADRs, three registries, two templates, a validator, and a manifest.

## Qualification

This package set is an architecture, contract, design, prototype, and implementation baseline. It is not a claim that the complete production system has been implemented or independently audited.
